package com.ebankunion.invoice;

import java.util.Comparator;
import java.util.Map;
import java.util.TreeMap;

import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

class MapKeyComparator implements Comparator<String>{

    @Override
    public int compare(String str1, String str2) {
        
        return str1.compareTo(str2);
    }
}

public class MapTest {
	private static final Logger log = LoggerFactory.getLogger(MapTest.class);
	
	@Test
    public void mapKeySortTest() throws Exception {
		Map<String, Object> map = new TreeMap<String, Object>();

        map.put("KFC", "kfc");
        map.put("WNBA", "wnba");
        map.put("NBA", "nba");
        map.put("CBA", "cba");

        Map<String, Object> resultMap = sortMapByKey(map);    //按Key进行排序

        for (Map.Entry<String, Object> entry : resultMap.entrySet()) {
            log.info(entry.getKey() + " " + entry.getValue().toString());
        }
		
	}
	
	public static Map<String, Object> sortMapByKey(Map<String, Object> map) {
        if (map == null || map.isEmpty()) {
            return null;
        }

        Map<String, Object> sortMap = new TreeMap<String, Object>(
                new MapKeyComparator());

        sortMap.putAll(map);

        return sortMap;
    }
}
