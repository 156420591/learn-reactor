package com.ebankunion.invoice;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;


import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.UUID;

import static org.junit.Assert.assertEquals;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class IpsApplicationTests {
	private static final Logger log = LoggerFactory.getLogger(IpsApplicationTests.class);
	
	private String merchantId = "898000000000099";
	private String terminalId = "00000002";
	private String buyerName = "深港出租车公司";
	private String merOrderId = new SimpleDateFormat("00yyyyMMddhhmmss").format(new Date());
	
    @LocalServerPort
    private int port;

    @Autowired
    private TestRestTemplate template;

    @Test
    public void test1Pickup() throws Exception {
		MultiValueMap<String, String> params1 = new LinkedMultiValueMap<String, String>();

		UUID uuid1 = UUID.randomUUID();
		params1.add("msgId", uuid1.toString());
		params1.add("msgSrc", "ebankunion");

		Date dNow1 = new Date();
		SimpleDateFormat ft11 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		params1.add("requestTimestamp", ft11.format(dNow1));

		params1.add("invoiceMaterial", "ELECTRONIC");
		params1.add("invoiceType", "PLAIN");
		params1.add("merchantId", merchantId);
		params1.add("terminalId", terminalId);
		
		SimpleDateFormat ft12 = new SimpleDateFormat("yyyyMMdd");
		params1.add("merOrderDate", ft12.format(dNow1));
		
		params1.add("merOrderId", merOrderId);
		params1.add("buyerName", buyerName);
		params1.add("amount", "11");
		params1.add("notifyUrl", "http://127.0.0.1:9090");

		HttpHeaders headers1 = new HttpHeaders();
        headers1.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

        HttpEntity<MultiValueMap<String, String>> request1 = new HttpEntity<MultiValueMap<String, String>>(params1, headers1);
		
		URL base1 = new URL("http://localhost:" + port + "/ips/invoice/issue");
        ResponseEntity<Object> response1 = template.postForEntity(base1.toString(), request1, Object.class);
        log.info(response1.getBody().toString());
        assertEquals(response1.getStatusCodeValue(),200);
        
        MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();

		UUID uuid = UUID.randomUUID();
		params.add("msgId", uuid.toString());
		params.add("msgSrc", "ebankunion");

		Date dNow = new Date();
		SimpleDateFormat ft1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		params.add("requestTimestamp", ft1.format(dNow));

		params.add("merchantId", merchantId);
		params.add("terminalId", terminalId);
		
		SimpleDateFormat ft2 = new SimpleDateFormat("yyyyMMdd");
		params.add("merOrderDate", ft2.format(dNow));
		
		params.add("merOrderId", merOrderId);

		HttpHeaders headers = new HttpHeaders();
        headers1.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

        HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<MultiValueMap<String, String>>(params, headers);
		
		URL base = new URL("http://localhost:" + port + "/ips/invoice/pickup");
        ResponseEntity<Object> response = template.postForEntity(base.toString(), request, Object.class);
        log.info(response.getBody().toString());
        assertEquals(response.getStatusCodeValue(),200);
    }
    
    @Test
    public void test2Query() throws Exception {
		MultiValueMap<String, String> params1 = new LinkedMultiValueMap<String, String>();

		UUID uuid1 = UUID.randomUUID();
		params1.add("msgId", uuid1.toString());
		params1.add("msgSrc", "ebankunion");

		Date dNow1 = new Date();
		SimpleDateFormat ft11 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		params1.add("requestTimestamp", ft11.format(dNow1));

		params1.add("invoiceMaterial", "ELECTRONIC");
		params1.add("invoiceType", "PLAIN");
		params1.add("merchantId", merchantId);
		params1.add("terminalId", terminalId);
		
		SimpleDateFormat ft12 = new SimpleDateFormat("yyyyMMdd");
		params1.add("merOrderDate", ft12.format(dNow1));
		
		params1.add("merOrderId", merOrderId);
		params1.add("buyerName", buyerName);
		params1.add("amount", "11");
		params1.add("notifyUrl", "http://127.0.0.1:9090");

		HttpHeaders headers1 = new HttpHeaders();
        headers1.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

        HttpEntity<MultiValueMap<String, String>> request1 = new HttpEntity<MultiValueMap<String, String>>(params1, headers1);
		
		URL base1 = new URL("http://localhost:" + port + "/ips/invoice/issue");
        ResponseEntity<Object> response1 = template.postForEntity(base1.toString(), request1, Object.class);
        log.info(response1.getBody().toString());
        assertEquals(response1.getStatusCodeValue(),200);
		
		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();

		UUID uuid = UUID.randomUUID();
		params.add("msgId", uuid.toString());
		params.add("msgSrc", "ebankunion");

		Date dNow = new Date();
		SimpleDateFormat ft1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		params.add("requestTimestamp", ft1.format(dNow));

		params.add("merchantId", merchantId);
		params.add("terminalId", terminalId);
		
		SimpleDateFormat ft2 = new SimpleDateFormat("yyyyMMdd");
		params.add("merOrderDate", ft2.format(dNow));
		
		params.add("merOrderId", merOrderId);


        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

        HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<MultiValueMap<String, String>>(params, headers);

        URL base = new URL("http://localhost:" + port + "/ips/invoice/query");
        ResponseEntity<Object> response = template.postForEntity(base.toString(), request, Object.class);
        log.info(response.getBody().toString());
        assertEquals(response.getStatusCodeValue(),200);
	}
    
    @Test
    public void test3Reverse() throws Exception {
		MultiValueMap<String, String> params1 = new LinkedMultiValueMap<String, String>();

		UUID uuid1 = UUID.randomUUID();
		params1.add("msgId", uuid1.toString());
		params1.add("msgSrc", "ebankunion");

		Date dNow1 = new Date();
		SimpleDateFormat ft11 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		params1.add("requestTimestamp", ft11.format(dNow1));

		params1.add("invoiceMaterial", "ELECTRONIC");
		params1.add("invoiceType", "PLAIN");
		params1.add("merchantId", merchantId);
		params1.add("terminalId", terminalId);
		
		SimpleDateFormat ft12 = new SimpleDateFormat("yyyyMMdd");
		params1.add("merOrderDate", ft12.format(dNow1));
		
		params1.add("merOrderId", merOrderId);
		params1.add("buyerName", buyerName);
		params1.add("amount", "11");
		params1.add("notifyUrl", "http://127.0.0.1:9090");

		HttpHeaders headers1 = new HttpHeaders();
        headers1.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

        HttpEntity<MultiValueMap<String, String>> request1 = new HttpEntity<MultiValueMap<String, String>>(params1, headers1);
		
		URL base1 = new URL("http://localhost:" + port + "/ips/invoice/issue");
        ResponseEntity<Object> response1 = template.postForEntity(base1.toString(), request1, Object.class);
        log.info(response1.getBody().toString());
        assertEquals(response1.getStatusCodeValue(),200);
		
		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();

		UUID uuid = UUID.randomUUID();
		params.add("msgId", uuid.toString());
		params.add("msgSrc", "ebankunion");
		
		Date dNow = new Date();
		SimpleDateFormat ft1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		params.add("requestTimestamp", ft1.format(dNow));

		params.add("merchantId", merchantId);
		params.add("terminalId", terminalId);
		
		SimpleDateFormat ft2 = new SimpleDateFormat("yyyyMMdd");
		params.add("merOrderDate", ft2.format(dNow));
		
		params.add("merOrderId", merOrderId);


        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

        HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<MultiValueMap<String, String>>(params, headers);

        URL base = new URL("http://localhost:" + port + "/ips/invoice/reverse");
        ResponseEntity<Object> response = template.postForEntity(base.toString(), request, Object.class);
        log.info(response.getBody().toString());
        assertEquals(response.getStatusCodeValue(),200);
	}
}
