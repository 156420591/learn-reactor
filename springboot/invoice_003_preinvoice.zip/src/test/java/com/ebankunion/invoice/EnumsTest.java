package com.ebankunion.invoice;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.junit.Test;

import com.ebankunion.invoice.exception.ResultEnum;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class EnumsTest {
	
	@Test
	 public void testGetEnums() {
		log.info(Enum.valueOf(ResultEnum.class, "UNKONW_ERROR").getMsg());
	}
	
	@Test
	 public void testDateFormat() {
		LocalDateTime payTime = LocalDateTime.now();
		log.info(payTime.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
	}
}
