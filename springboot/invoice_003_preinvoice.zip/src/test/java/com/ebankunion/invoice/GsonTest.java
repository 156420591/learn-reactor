package com.ebankunion.invoice;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import com.ebankunion.invoice.bean.Goods;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.annotations.Expose;
import com.google.gson.reflect.TypeToken;

import lombok.extern.slf4j.Slf4j;

class ToIssue {
	@Expose(serialize = false, deserialize = false)
	private String msgId;
	@Expose(serialize = true, deserialize = true)
	private String remark;
	@Expose(serialize = true, deserialize = true)
	private List<Goods> goodsDetail;
	public String getMsgId() {
		return msgId;
	}
	public void setMsgId(String msgId) {
		this.msgId = msgId;
	}
	public List<Goods> getGoodsDetail() {
		return goodsDetail;
	}
	public void setGoodsDetail(List<Goods> goodsDetail) {
		this.goodsDetail = goodsDetail;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	
	
}

@Slf4j
public class GsonTest {

	@Test
    public void jsonTest() throws Exception {
        Gson gson = new Gson();
    	List<Goods> goodsList = new ArrayList<Goods>();
    	
    	Goods goods1 = new Goods();
    	goods1.setIndex(1);
    	goods1.setAttribute("0");
    	goods1.setName("车费");
    	goods1.setSn("3010101020203000000");
    	goods1.setTaxRate(6);
    	goods1.setPriceIncludingTax(93.12);
    	goodsList.add(goods1);
    	
    	Goods goods2 = new Goods();
    	goods2.setIndex(2);
    	goods2.setAttribute("0");
    	goods2.setName("燃油附加费");
    	goods2.setSn("3010101020203000000");
    	goods2.setTaxRate(6);
    	goods2.setPriceIncludingTax(3);
    	goodsList.add(goods2);
    	
    	String str=gson.toJson(goodsList).toString();
        log.info("---->list convert jsonStr:" + str);
        
        ToIssue toIssue = new ToIssue();
        toIssue.setMsgId("1111");
        toIssue.setGoodsDetail(goodsList);
        
        Gson gson2 = new GsonBuilder()
        .excludeFieldsWithoutExposeAnnotation()
        .create();
        String str2=gson2.toJson(toIssue).toString();
        log.info("---->list convert jsonStr:" + str2);
        
        
        Type type = new TypeToken<ArrayList<Goods>>() { }.getType();
        ArrayList<Goods> sList=gson.fromJson(str, type);
        log.info("------->json convert List:"+sList);

    }
}
