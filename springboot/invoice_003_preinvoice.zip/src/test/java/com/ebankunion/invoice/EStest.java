package com.ebankunion.invoice;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.elasticsearch.action.get.GetRequest;
import org.elasticsearch.action.get.GetResponse;
import org.elasticsearch.ElasticsearchException;
import org.elasticsearch.action.DocWriteRequest;
import org.elasticsearch.action.DocWriteResponse;
import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.action.index.IndexResponse;
import org.elasticsearch.action.support.WriteRequest;
import org.elasticsearch.action.update.UpdateRequest;
import org.elasticsearch.action.update.UpdateResponse;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestClientBuilder;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.rest.RestStatus;
import org.elasticsearch.search.fetch.subphase.FetchSourceContext;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import lombok.extern.slf4j.Slf4j;

/**
* @author 林创标  linchuangbiao@ebankunion.com
* @version 创建时间：2019年2月25日 下午3:45:08
* 类说明
*/
@Slf4j
@RunWith(SpringRunner.class)
@SpringBootTest
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class EStest {
	@Autowired
	RestClientBuilder eslClient;
	@Autowired
	RestHighLevelClient highLevelClient;
	
	@Test
	public void indexAddQuery() throws IOException, InterruptedException {
		LocalDateTime payTime = LocalDateTime.now();
		String idString = "test"+payTime.format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"));
		
		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
		params.add("msgId","01aafbcb-2854-406b-a78c-8e2066bcb1d3");
		params.add("msgSrc","ebankunion");
		params.add("requestTimestamp","2019-02-26 16:31:19");
		params.add("invoiceMaterial","ELECTRONIC");
		params.add("invoiceType","PLAIN");
		params.add("merchantId","898000000000099");
		params.add("terminalId","00000002");
		params.add("merOrderDate","20190226");
		params.add("merOrderId","0120190223043116");
		params.add("buyerName","深港出租车公司");
		params.add("amount","9612");
		params.add("goodsDetail","[{\"index\":1,\"attribute\":\"0\",\"discountIndex\":0,\"name\":\"车费\",\"sn\":\"3010101020203000000\",\"taxRate\":6,\"priceIncludingTax\":93.12,\"quantity\":1.0},{\"index\":2,\"attribute\":\"0\",\"discountIndex\":0,\"name\":\"燃油附加费\",\"sn\":\"3010101020203000000\",\"taxRate\":6,\"priceIncludingTax\":3.0,\"quantity\":1.0}]");
		params.add("storeId","");
		params.add("status","ISSUED");
		params.add("responseTimestamp","2019-02-26 18:26:06");
		params.add("invoiceNo","00323401");
		params.add("invoiceCode","945031909110");
		params.add("checkCode","e13d0");
		params.add("cipherCode","002f7cdc8d72fd8f911d080eb4e47d011676c2d961187ad8bec1118d9e46de13d0");
		params.add("issueDate","2019-02-26 18:26:05");
		params.add("deviceNo","");
		params.add("qrCodeId","https://mobl-test.chinaums.com/fapiao-portal/app_pickup.do?id=20190226486562b8803a423d9ab0e090fa55f807&checkCode=43479F19");
		params.add("storeName","");
		params.add("merchantName","区块链测试");
		params.add("sellerName","银联测试");
		params.add("sellerTaxCode","500102000000888");
		params.add("sellerAddress","广东深圳");
		params.add("sellerTelephone","0755-12345678");
		params.add("sellerBank","上海浦东发展银行深圳分行");
		params.add("sellerAccount","79080154800000782");
		params.add("payee","测试");
		params.add("checker","测试");
		params.add("drawer","测试");
		params.add("taxMethod","NORMAL");
		params.add("totalPriceIncludingTax","96.12");
		params.add("totalTax","5.440754716981132");
		params.add("totalPrice","90.67924528301887");
		params.add("notifyMerEmail","");
		params.add("qrCode","https://mobl-test.chinaums.com/fapiao-portal/app_pickup.do?id=20190226486562b8803a423d9ab0e090fa55f807&checkCode=43479F19");
		params.add("pdfUrl","https://mobl-test.chinaums.com/p/20190226486562b8803a423d9ab0e090fa55f807");
		params.add("pdfPreviewUrl","https://mobl-test.chinaums.com/fapiao-portal/consumer/invoice/pdfPreview.do?qrCodeId=20190226486562b8803a423d9ab0e090fa55f807");
		
		IndexRequest indexRequest = new IndexRequest("lincb", "test", idString) .source(params).opType(DocWriteRequest.OpType.CREATE); //version(1);
		//IndexRequest indexRequest = new IndexRequest(ToEsFlowData.doIvcEsDbName(), ToEsFlowData.doIvcEsTableName(), idString) .source(params);
		
		try {
			indexRequest.setRefreshPolicy(WriteRequest.RefreshPolicy.IMMEDIATE); 
			IndexResponse response = highLevelClient.index(indexRequest, RequestOptions.DEFAULT);
			log.info(response.toString());
			
			log.info(response.status().toString());
			if(response.status()==RestStatus.CREATED) {
				
			}
			
			log.info(response.getResult().toString());
			if(response.getResult()==DocWriteResponse.Result.CREATED) {
				
			}
		} catch(ElasticsearchException e) {
			log.info(e.status().toString());
		    if (e.status() == RestStatus.CONFLICT) {
		        log.info("记录已存在");
		    }
		}
		
		GetRequest request = new GetRequest("lincb", "test", idString);
		try {
		    GetResponse getResponse = highLevelClient.get(request, RequestOptions.DEFAULT);
		    log.info("{}",getResponse);
		} catch (ElasticsearchException e) {
		    if (e.status() == RestStatus.NOT_FOUND) {
		    	log.info("记录不存在");
		    }
		}
		
		GetRequest getRequest = new GetRequest("lincb", "test", idString);    
		getRequest.fetchSourceContext(new FetchSourceContext(false)); 
		getRequest.storedFields("_none_");
		boolean exists = highLevelClient.exists(getRequest, RequestOptions.DEFAULT);
		log.info("{}",exists);
		
		UpdateRequest request1 = new UpdateRequest("lincb", "test", idString)
				.doc(params)
				.version(1);
		try {
			request1.setRefreshPolicy(WriteRequest.RefreshPolicy.IMMEDIATE);
			UpdateResponse response = highLevelClient.update(request1, RequestOptions.DEFAULT);
		    log.info("更新结果{}",response);
		} catch (ElasticsearchException e) {
		    if (e.status() == RestStatus.NOT_FOUND) {
		    	log.info("记录不存在");
		    }
		}
	}
	
}
