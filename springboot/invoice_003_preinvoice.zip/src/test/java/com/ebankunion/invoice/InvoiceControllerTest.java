package com.ebankunion.invoice;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;

import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import com.ebankunion.invoice.bean.Goods;
import com.google.gson.Gson;

@RunWith(SpringRunner.class)
@SpringBootTest
@AutoConfigureMockMvc
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class InvoiceControllerTest {
	private String merchantId = "898000000000099";
	private String terminalId = "00000002";
	private String buyerName = "深港出租车公司";
	private String merOrderId = new SimpleDateFormat("00yyyyMMddhhmmss").format(new Date());
	
	@Autowired
	private MockMvc mockMvc;

	@Test
	public void test1Queryfuzzytitle() throws Exception {
		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();

		UUID uuid = UUID.randomUUID();
		params.add("msgId", uuid.toString());
		params.add("msgSrc", "ebankunion");

		Date dNow = new Date();
		SimpleDateFormat ft1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		params.add("requestTimestamp", ft1.format(dNow));

		params.add("name", "易办事");

		this.mockMvc.perform(post("/invoice/queryfuzzytitle").params(params)).andDo(print()).andExpect(status().isOk())
				.andExpect(jsonPath("$.retcode").value("0000"));
	}

	@Test
	public void testGetGoodsDetails() throws Exception {

		Gson gson = new Gson();
		List<Goods> goodsList = new ArrayList<Goods>();

		Goods goods1 = new Goods();
		goods1.setIndex(1);
		goods1.setAttribute("0");
		goods1.setName("车费");
		goods1.setSn("3010101020203000000");
		goods1.setQuantity(1.0);
		goods1.setTaxRate(6);
		goods1.setPriceIncludingTax(93.12);
		goodsList.add(goods1);

		Goods goods2 = new Goods();
		goods2.setIndex(2);
		goods2.setAttribute("0");
		goods2.setName("燃油附加费");
		goods2.setSn("3010101020203000000");
		goods2.setQuantity(1.0);
		goods2.setTaxRate(6);
		goods2.setPriceIncludingTax(3);
		goodsList.add(goods2);

		String str=gson.toJson(goodsList);
		System.out.println(str);
	}

	@Test
	public void test2Issue() throws Exception {
		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();

		UUID uuid = UUID.randomUUID();
		params.add("msgId", uuid.toString());
		params.add("msgSrc", "ebankunion");

		Date dNow = new Date();
		SimpleDateFormat ft1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		params.add("requestTimestamp", ft1.format(dNow));

		params.add("invoiceMaterial", "ELECTRONIC");
		params.add("invoiceType", "PLAIN");
		params.add("merchantId", merchantId);
		params.add("terminalId", terminalId);
		
		SimpleDateFormat ft2 = new SimpleDateFormat("yyyyMMdd");
		params.add("merOrderDate", ft2.format(dNow));
		
		params.add("merOrderId", merOrderId);
		params.add("buyerName", buyerName);
		params.add("amount", "9612");
		params.add("notifyUrl", "http://127.0.0.1:9090");

		Gson gson = new Gson();
    	List<Goods> goodsList = new ArrayList<Goods>();
    	
    	Goods goods1 = new Goods();
    	goods1.setIndex(1);
    	goods1.setAttribute("0");
    	goods1.setName("车费");
    	goods1.setSn("3010101020203000000");
    	goods1.setQuantity(1.0);
    	goods1.setTaxRate(6);
    	goods1.setPriceIncludingTax(93.12);
    	goodsList.add(goods1);
    	
    	Goods goods2 = new Goods();
    	goods2.setIndex(2);
    	goods2.setAttribute("0");
    	goods2.setName("燃油附加费");
    	goods2.setSn("3010101020203000000");
    	goods2.setQuantity(1.0);
    	goods2.setTaxRate(6);
    	goods2.setPriceIncludingTax(3);
    	goodsList.add(goods2);
    	
    	String str=gson.toJson(goodsList).toString();
    	params.add("goodsDetail",str);
    	
		this.mockMvc.perform(post("/invoice/issue").params(params)).andDo(print()).andExpect(status().isOk())
				.andExpect(jsonPath("$.retcode").value("0000"));

	}
	
	@Test
    public void test3Query() throws Exception {
		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();

		UUID uuid = UUID.randomUUID();
		params.add("msgId", uuid.toString());
		params.add("msgSrc", "ebankunion");

		Date dNow = new Date();
		SimpleDateFormat ft1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		params.add("requestTimestamp", ft1.format(dNow));

		params.add("merchantId", merchantId);
		params.add("terminalId", terminalId);
		
		params.add("merOrderDate", "20190226");
		
		params.add("merOrderId", "0020190226030040");

		this.mockMvc.perform(post("/invoice/query").params(params)).andDo(print()).andExpect(status().isOk())
		.andExpect(jsonPath("$.retcode").value("0000"));
	}
	
	@Test
	public void test4Pickup() throws Exception {
		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();

		UUID uuid = UUID.randomUUID();
		params.add("msgId", uuid.toString());
		params.add("msgSrc", "ebankunion");

		Date dNow = new Date();
		SimpleDateFormat ft1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		params.add("requestTimestamp", ft1.format(dNow));

		params.add("merchantId", merchantId);
		params.add("terminalId", terminalId);
		
		SimpleDateFormat ft2 = new SimpleDateFormat("yyyyMMdd");
		params.add("merOrderDate", ft2.format(dNow));
		
		params.add("merOrderId", merOrderId);

		this.mockMvc.perform(post("/invoice/pickup").params(params)).andDo(print()).andExpect(status().isOk())
				.andExpect(jsonPath("$.retcode").value("0000"));

	}
	
	@Test
	public void test5Reverse() throws Exception {
		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();

		UUID uuid = UUID.randomUUID();
		params.add("msgId", uuid.toString());
		params.add("msgSrc", "ebankunion");

		Date dNow = new Date();
		SimpleDateFormat ft1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		params.add("requestTimestamp", ft1.format(dNow));

		params.add("merchantId", merchantId);
		params.add("terminalId", terminalId);
		
		SimpleDateFormat ft2 = new SimpleDateFormat("yyyyMMdd");
		params.add("merOrderDate", ft2.format(dNow));
		
		params.add("merOrderId", merOrderId);

		this.mockMvc.perform(post("/invoice/reverse").params(params)).andDo(print()).andExpect(status().isOk())
				.andExpect(jsonPath("$.retcode").value("0000"));

	}
	
	@Test
	public void test6CallStatus() throws Exception {
		String ssString = "{\"buyerAccount\":\"\",\"buyerAddress\":\"\",\"buyerBank\":\"\",\"buyerName\":\"深港出租车公司\",\"buyerTaxCode\":\"\",\"buyerTelephone\":\"\",\"checkCode\":\"a0876\",\"checker\":\"测试\",\"cipherCode\":\"00135962bbcc359d017f1260ab154ac7d96b4ec606298897cc4c3156f10eca0876\",\"createTime\":\"2019-02-26 11:28:34\",\"deductionAmount\":0.0,\"deviceNo\":\"\",\"drawer\":\"测试\",\"errMsg\":\"SUCCESS\",\"extend1\":\"\",\"extend2\":\"\",\"goodsDetail\":\"[{\\\"attribute\\\":\\\"0\\\",\\\"discountIndex\\\":0,\\\"freeTaxType\\\":\\\"\\\",\\\"index\\\":1,\\\"name\\\":\\\"车费\\\",\\\"preferPolicyFlag\\\":\\\"0\\\",\\\"price\\\":87.84905660377359,\\\"priceIncludingTax\\\":93.12,\\\"quantity\\\":1.0,\\\"simpleName\\\":\\\"出租汽车客运服务\\\",\\\"sn\\\":\\\"3010101020203000000\\\",\\\"tax\\\":5.270943396226415,\\\"taxRate\\\":6,\\\"unitPrice\\\":87.84905660377359,\\\"unitPriceIncludingTax\\\":93.12,\\\"vatSpecial\\\":\\\"\\\"},{\\\"attribute\\\":\\\"0\\\",\\\"discountIndex\\\":0,\\\"freeTaxType\\\":\\\"\\\",\\\"index\\\":2,\\\"name\\\":\\\"燃油附加费\\\",\\\"preferPolicyFlag\\\":\\\"0\\\",\\\"price\\\":2.830188679245283,\\\"priceIncludingTax\\\":3.0,\\\"quantity\\\":1.0,\\\"simpleName\\\":\\\"出租汽车客运服务\\\",\\\"sn\\\":\\\"3010101020203000000\\\",\\\"tax\\\":0.16981132075471697,\\\"taxRate\\\":6,\\\"unitPrice\\\":2.830188679245283,\\\"unitPriceIncludingTax\\\":3.0,\\\"vatSpecial\\\":\\\"\\\"}]\",\"invalidDate\":null,\"invalidInvoiceCode\":\"\",\"invalidInvoiceNo\":\"\",\"invoiceCode\":\"945031909110\",\"invoiceMaterial\":\"ELECTRONIC\",\"invoiceNo\":\"00323141\",\"invoiceType\":\"PLAIN\",\"issueDate\":\"2019-02-26 11:28:34\",\"merOrderDate\":\"20190226\",\"merOrderId\":\"0020190226024240\",\"merWxAppId\":\"\",\"merWxOrderId\":\"\",\"merchantId\":\"898000000000099\",\"merchantName\":\"区块链测试\",\"notifyEmail\":\"\",\"notifyMerEmail\":\"\",\"notifyMobileNo\":\"\",\"notifyUrl\":\"https://lhtestpos.ebankunion.com:8444/ips/invoice/callstatus\",\"payee\":\"测试\",\"pdf\":\"\",\"pdfPreviewUrl\":\"https://mobl-test.chinaums.com/fapiao-portal/consumer/invoice/pdfPreview.do?qrCodeId=2019022621d63a1160174f0a97b094692dddc152\",\"pdfUrl\":\"https://mobl-test.chinaums.com/p/2019022621d63a1160174f0a97b094692dddc152\",\"qrCode\":\"https://mobl-test.chinaums.com/fapiao-portal/app_pickup.do?id=2019022621d63a1160174f0a97b094692dddc152&checkCode=B233500F\",\"qrCodeId\":\"2019022621d63a1160174f0a97b094692dddc152\",\"remark\":\"开票订单号:0020190226112831\",\"responseTimestamp\":\"2019-02-26 11:28:34\",\"resultCode\":\"SUCCESS\",\"resultMsg\":\"SUCCESS\",\"reverseCheckCode\":\"\",\"reverseCipherCode\":\"\",\"reverseDate\":null,\"reverseInvoiceCode\":\"\",\"reverseInvoiceNo\":\"\",\"sellerAccount\":\"79080154800000782\",\"sellerAddress\":\"广东深圳\",\"sellerBank\":\"上海浦东发展银行深圳分行\",\"sellerName\":\"银联测试\",\"sellerTaxCode\":\"500102000000888\",\"sellerTelephone\":\"0755-12345678\",\"status\":\"ISSUED\",\"storeId\":\"\",\"storeName\":\"\",\"taxMethod\":\"NORMAL\",\"terminalId\":\"00000002\",\"totalPrice\":90.67924528301887,\"totalPriceIncludingTax\":96.12,\"totalTax\":5.440754716981132,\"updateTime\":\"2019-02-26 11:28:34\"}";
		this.mockMvc.perform(post("/invoice/callstatus").content(ssString).contentType(MediaType.APPLICATION_JSON)).andDo(print()).andExpect(status().isOk())
		.andExpect(jsonPath("$.resultCode").value("SUCCESS"));
	}
	
	@Test
	public void test7Notify() throws Exception {
		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();

		UUID uuid = UUID.randomUUID();
		params.add("msgId", uuid.toString());
		params.add("msgSrc", "ebankunion");

		Date dNow = new Date();
		SimpleDateFormat ft1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		params.add("requestTimestamp", ft1.format(dNow));

		params.add("merchantId", merchantId);
		params.add("terminalId", terminalId);
		
		params.add("merOrderDate","20190214");
		params.add("merOrderId", "0020190214041702");
		params.add("notifyMobileNo", "13670029521");

		this.mockMvc.perform(post("/invoice/notify").params(params)).andDo(print()).andExpect(status().isOk())
				.andExpect(jsonPath("$.retcode").value("0000"));

	}
	
	@Test
	public void test8WeixinCard() throws Exception {
		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();

		UUID uuid = UUID.randomUUID();
		params.add("msgId", uuid.toString());
		params.add("msgSrc", "ebankunion");

		Date dNow = new Date();
		SimpleDateFormat ft1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		params.add("requestTimestamp", ft1.format(dNow));

		params.add("merchantId", merchantId);
		params.add("terminalId", terminalId);
		
		params.add("merOrderDate","20190222");
		params.add("merOrderId", "0020190222065045");
		params.add("source","wxa");
		params.add("invoiceNo", "00322630");
		params.add("invoiceCode", "945031909110");

		this.mockMvc.perform(post("/invoice/weixincard").params(params)).andDo(print()).andExpect(status().isOk())
				.andExpect(jsonPath("$.retcode").value("0000"));

	}
}
