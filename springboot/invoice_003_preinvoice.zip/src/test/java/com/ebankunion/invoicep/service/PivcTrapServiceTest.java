package com.ebankunion.invoicep.service;

import com.ebankunion.invoicep.exception.PivcArgumentCheckException;
import com.ebankunion.invoicep.exception.PivcException;
import com.ebankunion.invoicep.exception.PivcExceptionConst;
import org.junit.After;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

import static org.junit.Assert.*;

/**
 * ██╗  ██╗██╗    ██╗ ██████╗
 * ██║  ██║██║    ██║██╔════╝
 * ███████║██║ █╗ ██║██║  ███╗
 * ██╔══██║██║███╗██║██║   ██║
 * ██║  ██║╚███╔███╔╝╚██████╔╝
 * ╚═╝  ╚═╝ ╚══╝╚══╝  ╚═════╝
 * Created by huwenguang on 2019/3/7.
 */






public class PivcTrapServiceTest {

    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }

    @FixMethodOrder
    public static class forwardException{

        @Test
        public void testIsPivcSubException() throws Exception{
            PivcTrapService sut = new PivcTrapService();
            PivcArgumentCheckException exception = new PivcArgumentCheckException();
            try{
                sut.forwardException(exception);
            }catch (Exception e){
                assertTrue(e instanceof PivcArgumentCheckException);

                assertTrue(e instanceof PivcArgumentCheckException);

                PivcArgumentCheckException newex = (PivcArgumentCheckException)e;
                assertEquals(PivcExceptionConst.ARGERROR_Retcode, newex.getRetcode());
                assertEquals(PivcExceptionConst.ARGERROR_Retmsg, newex.getRetmsg());
            }

        }

        @Test
        public void testIsPivcException() throws Exception{
            PivcTrapService sut = new PivcTrapService();
            PivcException exception = new PivcException();
            try{
                sut.forwardException(exception);
            }catch (Exception e){
                assertTrue(e instanceof PivcException);

                assertFalse(e instanceof PivcArgumentCheckException);

            }

        }


        @Test
        public void testIsException() throws Exception{
            PivcTrapService sut = new PivcTrapService();
            Exception exception = new Exception();
            try{
                sut.forwardException(exception);
            }catch (Exception e){
                assertTrue(e instanceof PivcException);

                assertFalse(e instanceof PivcArgumentCheckException);


                PivcException newex = (PivcException)e;
                assertEquals(PivcExceptionConst.UNKNOWN_Retcode, newex.getRetcode());
                assertEquals(PivcExceptionConst.UNKNOWN_Retmsg, newex.getRetmsg());

            }

        }
    }

}