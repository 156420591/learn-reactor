package com.ebankunion.invoicep.bean;

import com.ebankunion.invoicep.validator.PivcFenMoney;
import org.hibernate.validator.constraints.Length;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import javax.validation.*;
import javax.validation.constraints.NotEmpty;

import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;
import java.util.Set;

import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.RetentionPolicy.RUNTIME;
import static org.junit.Assert.*;

/**
 * ██╗  ██╗██╗    ██╗ ██████╗
 * ██║  ██║██║    ██║██╔════╝
 * ███████║██║ █╗ ██║██║  ███╗
 * ██╔══██║██║███╗██║██║   ██║
 * ██║  ██║╚███╔███╔╝╚██████╔╝
 * ╚═╝  ╚═╝ ╚══╝╚══╝  ╚═════╝
 * Created by huwenguang on 2019/3/6.
 */





public class PivcIssueRequestTest {
    public static class testValidateInvoiceMaterial{

        private static ValidatorFactory validatorFactory;
        private static Validator validator;

        @BeforeClass
        public static void createValidator() {
            validatorFactory = Validation.buildDefaultValidatorFactory();
            validator = validatorFactory.getValidator();
        }

        @AfterClass
        public static void close() {
            validatorFactory.close();
        }

        @Test
        public void ivcTypeNotOk() throws Exception{
            PivcIssueRequest sut = new PivcIssueRequest();
            sut.setMsgId("test");
            sut.setMsgSrc("test");
            sut.setRequestTimestamp("test");
            sut.setInvoiceType("test");
            sut.setInvoiceMaterial("test");
            sut.setMerOrderDate("test");
            sut.setAmount("999998888822");

            Set<ConstraintViolation<PivcIssueRequest>> violations = validator.validate(sut);
            assertEquals(1, violations.size());
            for(ConstraintViolation<PivcIssueRequest> item : violations){
                assertEquals("only PAPER or ELECTRONIC is valid case sensitive", item.getMessage());
                System.out.println(item);
            }
        }


        @Test
        public void ivcTypeOk() throws Exception{
            PivcIssueRequest sut = new PivcIssueRequest();
            sut.setMsgId("test");
            sut.setMsgSrc("test");
            sut.setRequestTimestamp("test");
            sut.setInvoiceType("test");
            sut.setInvoiceMaterial("PAPER");
            sut.setMerOrderDate("test");
            sut.setAmount("999998888822");

            Set<ConstraintViolation<PivcIssueRequest>> violations = validator.validate(sut);
            assertEquals(0, violations.size());
        }


    }

    public static class testdeductionAmount{

        private static ValidatorFactory validatorFactory;
        private static Validator validator;

        @BeforeClass
        public static void createValidator() {
            validatorFactory = Validation.buildDefaultValidatorFactory();
            validator = validatorFactory.getValidator();
        }

        @AfterClass
        public static void close() {
            validatorFactory.close();
        }

        @Test
        public void setDeductionAmountEmptyOk() throws Exception{
            PivcIssueRequest sut = new PivcIssueRequest();
            sut.setMsgId("test");
            sut.setMsgSrc("test");
            sut.setRequestTimestamp("test");
            sut.setInvoiceType("test");
            sut.setInvoiceMaterial("PAPER");
            sut.setMerOrderDate("test");
            sut.setAmount("999998888822");
            sut.setDeductionAmount("");

            Set<ConstraintViolation<PivcIssueRequest>> violations = validator.validate(sut);
            assertEquals(0, violations.size());
            for(ConstraintViolation<PivcIssueRequest> item : violations){
                System.out.println(item);
            }
        }


        @Test
        public void setDeductionAmountFmtNotOk() throws Exception{
            PivcIssueRequest sut = new PivcIssueRequest();
            sut.setMsgId("test");
            sut.setMsgSrc("test");
            sut.setRequestTimestamp("test");
            sut.setInvoiceType("test");
            sut.setInvoiceMaterial("PAPER");
            sut.setMerOrderDate("test");
            sut.setAmount("999998888822");
            sut.setDeductionAmount("22.33");

            Set<ConstraintViolation<PivcIssueRequest>> violations = validator.validate(sut);
            assertEquals(1, violations.size());
            for(ConstraintViolation<PivcIssueRequest> item : violations){
                System.out.println(item);
                assertEquals("deductionAmount", item.getPropertyPath().toString());
            }
        }
    }

    public static class testValidateFenMoneyAmount{

        private static ValidatorFactory validatorFactory;
        private static Validator validator;

        @BeforeClass
        public static void createValidator() {
            validatorFactory = Validation.buildDefaultValidatorFactory();
            validator = validatorFactory.getValidator();
        }

        @AfterClass
        public static void close() {
            validatorFactory.close();
        }

        @Test
        public void amountFmtNotOk() throws Exception{
            PivcIssueRequest sut = new PivcIssueRequest();
            sut.setMsgId("test");
            sut.setMsgSrc("test");
            sut.setRequestTimestamp("test");
            sut.setInvoiceType("test");
            sut.setInvoiceMaterial("PAPER");
            sut.setMerOrderDate("test");
            sut.setAmount("test");

            Set<ConstraintViolation<PivcIssueRequest>> violations = validator.validate(sut);
            assertEquals(1, violations.size());
            for(ConstraintViolation<PivcIssueRequest> item : violations){
                System.out.println(item);
                assertEquals("amount", item.getPropertyPath().toString());
            }
        }


        @Test
        public void amountEmpty() throws Exception{
            PivcIssueRequest sut = new PivcIssueRequest();
            sut.setMsgId("test");
            sut.setMsgSrc("test");
            sut.setRequestTimestamp("test");
            sut.setInvoiceType("test");
            sut.setInvoiceMaterial("PAPER");
            sut.setMerOrderDate("test");
            sut.setAmount("");

            Set<ConstraintViolation<PivcIssueRequest>> violations = validator.validate(sut);
            assertEquals(1, violations.size());
            for(ConstraintViolation<PivcIssueRequest> item : violations){
                System.out.println(item);
            }
        }

        @Test
        public void amountFmtOk() throws Exception{
            PivcIssueRequest sut = new PivcIssueRequest();
            sut.setMsgId("test");
            sut.setMsgSrc("test");
            sut.setRequestTimestamp("test");
            sut.setInvoiceType("test");
            sut.setInvoiceMaterial("PAPER");
            sut.setMerOrderDate("test");
            sut.setAmount("999998888822");

            Set<ConstraintViolation<PivcIssueRequest>> violations = validator.validate(sut);
            assertEquals(0, violations.size());
        }


    }

}