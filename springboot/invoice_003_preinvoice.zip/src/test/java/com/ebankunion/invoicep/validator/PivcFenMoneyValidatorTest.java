package com.ebankunion.invoicep.validator;

import org.junit.Test;

import static org.junit.Assert.*;

/**
 * ██╗  ██╗██╗    ██╗ ██████╗
 * ██║  ██║██║    ██║██╔════╝
 * ███████║██║ █╗ ██║██║  ███╗
 * ██╔══██║██║███╗██║██║   ██║
 * ██║  ██║╚███╔███╔╝╚██████╔╝
 * ╚═╝  ╚═╝ ╚══╝╚══╝  ╚═════╝
 * Created by huwenguang on 2019/3/6.
 */
public class PivcFenMoneyValidatorTest {
    @Test
    public void testNull() throws Exception {
        PivcFenMoneyValidator sut = new PivcFenMoneyValidator();
        String input = null;
        assertTrue(sut.validateFenMoney(input));
    }

    @Test
    public void testEmptyString() throws Exception {
        PivcFenMoneyValidator sut = new PivcFenMoneyValidator();
        String input = "";
        assertTrue(sut.validateFenMoney(input));
    }

    @Test
    public void testNot12LenNumber() throws Exception {
        PivcFenMoneyValidator sut = new PivcFenMoneyValidator();
        String input = "2000";
        assertFalse(sut.validateFenMoney(input));
    }

    @Test
    public void testNotNumber() throws Exception {
        PivcFenMoneyValidator sut = new PivcFenMoneyValidator();
        String input = "1111155555ab";
        assertFalse(sut.validateFenMoney(input));
    }

    @Test
    public void is12Number() throws Exception {
        PivcFenMoneyValidator sut = new PivcFenMoneyValidator();
        String input = "111115555500";
        assertTrue(sut.validateFenMoney(input));
    }
}