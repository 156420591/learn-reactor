package com.ebankunion.invoicep.service;

import com.ebankunion.invoicep.bean.PivcConf;
import com.google.gson.JsonObject;
import com.xebialabs.restito.server.StubServer;
import org.glassfish.grizzly.http.util.HttpStatus;
import org.junit.Test;
import org.junit.experimental.runners.Enclosed;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Spy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;

import static com.xebialabs.restito.builder.stub.StubHttp.whenHttp;
import static com.xebialabs.restito.semantics.Action.status;
import static com.xebialabs.restito.semantics.Action.stringContent;
import static com.xebialabs.restito.semantics.Condition.post;
import static org.junit.Assert.*;

/**
 * ██╗  ██╗██╗    ██╗ ██████╗
 * ██║  ██║██║    ██║██╔════╝
 * ███████║██║ █╗ ██║██║  ███╗
 * ██╔══██║██║███╗██║██║   ██║
 * ██║  ██║╚███╔███╔╝╚██████╔╝
 * ╚═╝  ╚═╝ ╚══╝╚══╝  ╚═════╝
 * Created by huwenguang on 2019/3/8.
 */
public class PivcCommonServiceTest {

    @Test
    public void test() throws Exception {
    }


    @RunWith(SpringRunner.class)
    @TestPropertySource(locations = {"classpath:mypivc.properties"}, properties = {"invoicep.pivcIpsErrorcodeIntype=intype", "a.b.c=test"})
    @SpringBootTest(classes = {PivcUtilService.class, PivcConf.class, PivcCommonService.class })
    public static class fmtPostdata{
        @Autowired
        protected PivcCommonService sut;

        @Test
        public void test() throws Exception {
            JsonObject joInput = new JsonObject();
            joInput.addProperty("retcode", "8888");
            joInput.addProperty("retmsg", "8888");
            String result = sut.fmtPostdata(joInput);

            String expected = "errorcode=8888&frommodule=invoicep&intype=intype";
            assertEquals(expected, result);

        }
    }


    @RunWith(SpringRunner.class)
    @TestPropertySource(locations = {"classpath:mypivc.properties"}, properties = {"invoicep.pivcIpsErrorcodeIntype=intype", "a.b.c=test"})
    @SpringBootTest(classes = {PivcUtilService.class, PivcConf.class, PivcCommonService.class })
    public static class send2IpsAndMap_butUsingFakePost{
        @Spy
        protected PivcUtilService utilService;

        @Spy
        protected PivcConf conf;

        @InjectMocks
        protected PivcCommonService sut;


        @Test
        public void testFakePostFailure() throws Exception {
            JsonObject joIpsReturn = new JsonObject();
            joIpsReturn.addProperty("retcode", "3220");
            org.mockito.Mockito.doReturn(joIpsReturn).when(utilService)
                    .httpPost(org.mockito.Mockito.anyString(), org.mockito.Mockito.anyInt(), org.mockito.Mockito.anyString());


            JsonObject joInput = new JsonObject();
            joInput.addProperty("retcode", "8888");
            joInput.addProperty("retmsg", "8888");
            String url = "fakeurl";
            int timeout= 1000;
            sut.send2IpsAndMap(url, timeout, joInput);


            assertEquals("8888", joInput.get("retcode").getAsString());
            assertEquals("8888", joInput.get("retmsg").getAsString());
        }


        @Test
        public void testFakePostSuccessful() throws Exception {
            JsonObject joIpsReturn = new JsonObject();
            joIpsReturn.addProperty("retcode", "0000");
            joIpsReturn.addProperty("errcode", "9999");
            joIpsReturn.addProperty("errmsg", "errmsg");
            org.mockito.Mockito.doReturn(joIpsReturn).when(utilService)
                    .httpPost(org.mockito.Mockito.anyString(), org.mockito.Mockito.anyInt(), org.mockito.Mockito.anyString());


            JsonObject joInput = new JsonObject();
            joInput.addProperty("retcode", "8888");
            joInput.addProperty("retmsg", "8888");
            String url = "fakeurl";
            int timeout= 1000;
            sut.send2IpsAndMap(url, timeout, joInput);


            assertEquals("errmsg", joInput.get("retmsg").getAsString());
            assertEquals("9999", joInput.get("retcode").getAsString());
        }







    }

    @RunWith(SpringRunner.class)
    @TestPropertySource(locations = {"classpath:mypivc.properties"}, properties = {"invoicep.pivcIpsErrorcodeIntype=intype", "a.b.c=test"})
    @SpringBootTest(classes = {PivcUtilService.class, PivcConf.class, PivcCommonService.class })
    public static class send2IpsAndMap{
        @Autowired
        protected PivcCommonService sut;

        @Test
        public void testReplaceWithIpsErrorcode() throws Exception {
            JsonObject joInput = new JsonObject();
            joInput.addProperty("retcode", "8888");
            joInput.addProperty("retmsg", "8888");


            String ipsReturn = "{\"retcode\":\"0000\", \"retmsg\":\"test\", \"errcode\":\"4444\", \"errmsg\":\"errmsg\"}";
            StubServer server;
            int port;
            server = new StubServer().run();
            port   = server.getPort();
            whenHttp(server)
                    .match(post("/ips/errorcode"))
                    .then(status(HttpStatus.OK_200), stringContent(ipsReturn));

            String url = String.format("http://localhost:%s/ips/errorcode", port);
            int timeout= 1000;
            sut.send2IpsAndMap(url, timeout, joInput);

            assertEquals("4444", joInput.get("retcode").getAsString());
            assertEquals("errmsg", joInput.get("retmsg").getAsString());

        }

        @Test
        public void testIpsReturnFailureNotReplaceRetcode() throws Exception {
            JsonObject joInput = new JsonObject();
            joInput.addProperty("retcode", "8888");
            joInput.addProperty("retmsg", "8888");


            String ipsReturn = "{\"retcode\":\"8610\", \"retmsg\":\"test\", \"errcode\":\"4444\", \"errmsg\":\"errmsg\"}";
            StubServer server;
            int port;
            server = new StubServer().run();
            port   = server.getPort();
            whenHttp(server)
                    .match(post("/ips/errorcode"))
                    .then(status(HttpStatus.BAD_GATEWAY_502), stringContent(ipsReturn));

            String url = String.format("http://localhost:%s/ips/errorcode", port);
            int timeout= 1000;
            sut.send2IpsAndMap(url, timeout, joInput);

            assertEquals("8888", joInput.get("retcode").getAsString());
            assertEquals("8888", joInput.get("retmsg").getAsString());

        }

    }




}