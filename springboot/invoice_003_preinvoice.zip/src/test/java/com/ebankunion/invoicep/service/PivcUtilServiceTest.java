package com.ebankunion.invoicep.service;

import com.ebankunion.invoice.util.Sign;
import com.ebankunion.invoicep.bean.PivcQueryfuzzytitleRequest;
import com.google.gson.JsonObject;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.runners.Enclosed;
import org.junit.runner.RunWith;

import java.math.BigInteger;
import java.util.Comparator;
import java.util.Map;
import java.util.TreeMap;

import static org.junit.Assert.*;

/**
 * ██╗  ██╗██╗    ██╗ ██████╗
 * ██║  ██║██║    ██║██╔════╝
 * ███████║██║ █╗ ██║██║  ███╗
 * ██╔══██║██║███╗██║██║   ██║
 * ██║  ██║╚███╔███╔╝╚██████╔╝
 * ╚═╝  ╚═╝ ╚══╝╚══╝  ╚═════╝
 * Created by huwenguang on 2019/3/6.
 */
@RunWith(Enclosed.class)
public class PivcUtilServiceTest {

    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void test() throws Exception {
    }

    public static class capitalize{
        PivcUtilService sut = new PivcUtilService();

        @Test
        public void testNull() throws Exception {
            String input = null;
            String result = sut.capitalize(input);
            assertEquals("", result);
        }


        @Test
        public void testEmpty() throws Exception {
            String input = "";
            String result = sut.capitalize(input);
            assertEquals("", result);
        }


        @Test
        public void testSingle() throws Exception {
            String input = "a";
            String result = sut.capitalize(input);
            assertEquals("A", result);
        }
    }

    public static class getStringWithOrderedKey{
        PivcUtilService sut = new PivcUtilService();

        @Test
        public void testNormal() throws Exception {
            JsonObject jo = new JsonObject();
            jo.addProperty("a", "test");
            jo.addProperty("b", "test");

            String result = sut.getStringWithOrderedKey(jo);
            String expected = "a=test&b=test";
            assertEquals(expected, result);
        }


        @Test
        public void test() throws Exception {
            JsonObject jo = new JsonObject();
            jo.addProperty("merchantId", "test");
            jo.addProperty("merOrderDate", "test");

            String result = sut.getStringWithOrderedKey(jo);
            String expected = "merOrderDate=test&merchantId=test";
            assertEquals(expected, result);
        }


        @Test
        public void sortUsingTreeMap() throws Exception {

            class MapKeyComparator implements Comparator<String> {
                @Override
                public int compare(String str1, String str2) {

                    return str1.compareTo(str2);
                }
            }

            Map<String, String> mapSort = new TreeMap<>(new MapKeyComparator());
            mapSort.put("merchantId", "test");
            mapSort.put("merOrderDate", "test");
            for(String key : mapSort.keySet()){
                System.out.println(key);
            }
        }
    }

    public static class doUmsSign{
        PivcUtilService sut = new PivcUtilService();

        protected JsonObject getJson(){
            JsonObject jo = new JsonObject();
            jo.addProperty("a", "test");
            jo.addProperty("b", "test");

            return jo;
        }

        @Test
        public void testSimple() throws Exception {
            JsonObject joOrgMsg = getJson();
            String key = "akey";

            String mysign = sut.doUmsSign(joOrgMsg, key);

            Map<String, Object> mymap = sut.fromObject2Map(joOrgMsg);
            String theirs = Sign.mapDoSign(mymap, key);

            assertEquals(mysign, theirs);
        }

        protected JsonObject getQueryFuzzyTitle(){
            PivcQueryfuzzytitleRequest request = new PivcQueryfuzzytitleRequest();
            request.setMsgId("setMsgId");
            request.setMsgSrc("setMsgSrc");
            request.setName("setName");
            request.setRequestTimestamp("setRequestTimestamp");
            request.setSign("setSign");
            request.setSrcReserve("setSrcReserve");
            request.setTaxCode("setTaxCode");

            JsonObject jsonObject = sut.fromObject2Json(request);
            return jsonObject;
        }


        @Test
        public void test_PivcQueryfuzzytitleRequest_doSign() throws Exception {
            JsonObject joOrgMsg = getQueryFuzzyTitle();
            String key = "akey";

            String mysign = sut.doUmsSign(joOrgMsg, key);

            Map<String, Object> mymap = sut.fromObject2Map(joOrgMsg);
            String theirs = Sign.mapDoSign(mymap, key);

            assertEquals(mysign, theirs);
        }

    }

    public static class getIntFromString{
        @Test
        public void testNull() throws Exception {
            String amount = null;
            PivcUtilService sut = new PivcUtilService();
            BigInteger result = sut.getIntFromString(amount);
            assertEquals(new BigInteger("0"), result);
        }


        @Test
        public void testEmptyString() throws Exception {
            String amount = "";
            PivcUtilService sut = new PivcUtilService();
            BigInteger result = sut.getIntFromString(amount);
            assertEquals(new BigInteger("0"), result);
        }

        @Test
        public void testStringNotNumber() throws Exception {
            String amount = "test";
            PivcUtilService sut = new PivcUtilService();
            BigInteger result = sut.getIntFromString(amount);
            assertEquals(new BigInteger("0"), result);
        }

        @Test
        public void test12StringNumber() throws Exception {
            String amount = "999999999999";
            PivcUtilService sut = new PivcUtilService();
            BigInteger result = sut.getIntFromString(amount);
            assertEquals(new BigInteger("999999999999"), result);
        }
    }

    public static class fromObject2Map{

        class JayceApple{
            public String name;
            public String color;
        }

        @Test
        public void testStringNotJson() throws Exception {
            String input = "{";
            PivcUtilService sut = new PivcUtilService();
            Map<String, Object> joResult = sut.fromObject2Map(input);

            assertEquals(0, joResult.keySet().size());
        }

        @Test
        public void testIntObjectNotJson() throws Exception {
            Integer input = new Integer(3);
            PivcUtilService sut = new PivcUtilService();
            Map<String, Object> joResult = sut.fromObject2Map(input);
            assertEquals(0, joResult.keySet().size());
        }

        @Test
        public void testStringIsJson() throws Exception {
            String input = "{\"retcode\":\"8999\", \"retmsg\":\"test\"}";
            PivcUtilService sut = new PivcUtilService();
            Map<String, Object> joResult = sut.fromObject2Map(input);

            assertEquals(2, joResult.keySet().size());
            assertEquals("8999", joResult.get("retcode") );
            assertEquals("test", joResult.get("retmsg") );
        }

        protected JayceApple getApple(){
            JayceApple myapple = new JayceApple();
            myapple.name = "test";
            myapple.color= "white";

            return myapple;
        }

        @Test
        public void testObject2Json() throws Exception {
            JayceApple apple = getApple();
            PivcUtilService sut = new PivcUtilService();
            Map<String, Object> joResult = sut.fromObject2Map(apple);

            assertEquals(2, joResult.keySet().size());
            assertEquals("white", joResult.get("color") );
            assertEquals("test", joResult.get("name") );
        }
    }

    public static class fromObject2Json{

        class JayceApple{
            public String name;
            public String color;
        }

        @Test
        public void testStringNotJson() throws Exception {
            String input = "{";
            PivcUtilService sut = new PivcUtilService();
            JsonObject joResult = sut.fromObject2Json(input);
            assertEquals(0, joResult.keySet().size());
        }

        @Test
        public void testIntObjectNotJson() throws Exception {
            Integer input = new Integer(3);
            PivcUtilService sut = new PivcUtilService();
            JsonObject joResult = sut.fromObject2Json(input);
            assertEquals(0, joResult.keySet().size());
        }

        @Test
        public void testStringIsJson() throws Exception {
            String input = "{\"retcode\":\"8999\", \"retmsg\":\"test\"}";
            PivcUtilService sut = new PivcUtilService();
            JsonObject joResult = sut.fromObject2Json(input);

            assertEquals(2, joResult.keySet().size());
            assertEquals("8999", joResult.get("retcode").getAsString());
            assertEquals("test", joResult.get("retmsg").getAsString());
        }

        protected JayceApple getApple(){
            JayceApple myapple = new JayceApple();
            myapple.name = "test";
            myapple.color= "white";

            return myapple;
        }

        @Test
        public void testObject2Json() throws Exception {
            JayceApple apple = getApple();
            PivcUtilService sut = new PivcUtilService();
            JsonObject joResult = sut.fromObject2Json(apple);

            assertEquals(2, joResult.keySet().size());
            assertEquals("white", joResult.get("color").getAsString());
            assertEquals("test", joResult.get("name").getAsString());
        }

    }

    public static class safeGetStringFrom{

        @Test
        public void testNotStringIsNumberFloat() throws Exception{
            PivcUtilService sut = new PivcUtilService();

            JsonObject jo = new JsonObject();
            jo.addProperty("retcode", 20.00);

            String strResult = sut.getStringFromJson(jo, "retcode");

            assertEquals("20.0",  strResult);
        }

        @Test
        public void testNotStringIsNumberInt() throws Exception{
            PivcUtilService sut = new PivcUtilService();

            JsonObject jo = new JsonObject();
            jo.addProperty("retcode",  20);

            String strResult = sut.getStringFromJson(jo, "retcode");

            assertEquals("20",  strResult);
        }


        @Test
        public void testNotStringIsJsonObject() throws Exception{
            PivcUtilService sut = new PivcUtilService();

            JsonObject jo = new JsonObject(); JsonObject sub = new JsonObject();
            jo.add("retcode", sub);


            String strResult = sut.getStringFromJson(jo, "retcode");

            assertEquals("",  strResult);
        }


        @Test
        public void testNotStringNoKey() throws Exception{
            PivcUtilService sut = new PivcUtilService();

            JsonObject jo = new JsonObject(); JsonObject sub = new JsonObject();

            jo.addProperty("retcode", "20");

            String strResult = sut.getStringFromJson(jo, "retcode1");

            assertEquals("",  strResult);
        }

        @Test
        public void testIsString() throws Exception{
            PivcUtilService sut = new PivcUtilService();

            JsonObject jo = new JsonObject();
            jo.addProperty("retcode", "20");

            String strResult = sut.getStringFromJson(jo, "retcode");

            assertEquals("20",  strResult);
        }
    }

    public static class isJsonKeyStringType{
        @Test
        public void testNotStringIsNumber() throws Exception{
            PivcUtilService sut = new PivcUtilService();

            JsonObject jo = new JsonObject();
            jo.addProperty("retcode", 20);

            assertFalse(sut.isJsonKeyStringType(jo, "retcode"));
        }


        @Test
        public void testNotStringIsJsonObject() throws Exception{
            PivcUtilService sut = new PivcUtilService();

            JsonObject jo = new JsonObject(); JsonObject sub = new JsonObject();
            jo.add("retcode", sub);

            assertFalse(sut.isJsonKeyStringType(jo, "retcode"));
        }


        @Test
        public void testNotStringNoKey() throws Exception{
            PivcUtilService sut = new PivcUtilService();

            JsonObject jo = new JsonObject(); JsonObject sub = new JsonObject();

            jo.addProperty("retcode", "20");

            assertFalse(sut.isJsonKeyStringType(jo, "retcode1"));
        }

        @Test
        public void testIsString() throws Exception{
            PivcUtilService sut = new PivcUtilService();

            JsonObject jo = new JsonObject();
            jo.addProperty("retcode", "20");

            assertTrue(sut.isJsonKeyStringType(jo, "retcode"));
        }
    }
}