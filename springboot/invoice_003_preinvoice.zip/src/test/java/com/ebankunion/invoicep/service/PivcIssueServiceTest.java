package com.ebankunion.invoicep.service;

import com.ebankunion.invoicep.backendbean.PivcIssueEndpointBean;
import com.ebankunion.invoicep.bean.PivcConf;
import com.ebankunion.invoicep.bean.PivcEsFlow;
import com.ebankunion.invoicep.bean.PivcIssueRequest;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;


import java.util.HashSet;
import java.util.Set;

import static org.junit.Assert.*;

/**
 * ██╗  ██╗██╗    ██╗ ██████╗
 * ██║  ██║██║    ██║██╔════╝
 * ███████║██║ █╗ ██║██║  ███╗
 * ██╔══██║██║███╗██║██║   ██║
 * ██║  ██║╚███╔███╔╝╚██████╔╝
 * ╚═╝  ╚═╝ ╚══╝╚══╝  ╚═════╝
 * Created by huwenguang on 2019/3/8.
 */
public class PivcIssueServiceTest {

    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void test() throws Exception {
    }


    @RunWith(SpringRunner.class)
    @SpringBootTest(classes = {PivcUtilService.class, PivcConf.class, PivcCommonService.class, PivcIssueService.class,
            PivcEsService.class, PivcEsRestClient.class })
    public static class setEsFlowFromRequest2{

        @Autowired
        PivcIssueService sut;

        //region create test requests
        protected PivcIssueRequest getWholeIssueRequest() {
            PivcIssueRequest obj = new PivcIssueRequest();
            obj.setMsgId("setMsgId");
            obj.setMsgSrc("setMsgSrc");
            obj.setRequestTimestamp("setRequestTimestamp");
            obj.setSrcReserve("setSrcReserve");
            obj.setInvoiceMaterial("setInvoiceMaterial");
            obj.setInvoiceType("setInvoiceType");
            obj.setMerOrderDate("setMerOrderDate");
            obj.setMerOrderId("setMerOrderId");
            obj.setBuyerName("setBuyerName");
            obj.setBuyerTaxCode("setBuyerTaxCode");
            obj.setBuyerAddress("setBuyerAddress");
            obj.setBuyerTelephone("setBuyerTelephone");
            obj.setBuyerBank("setBuyerBank");
            obj.setBuyerAccount("setBuyerAccount");
            obj.setAmount("setAmount");
            obj.setDeductionAmount("setDeductionAmount");

            String goods = "[{\"index\":1,\"attribute\":\"0\",\"discountIndex\":0,\"name\":\"车费\",\"sn\":\"3010101020203000000\",\"taxRate\":6,\"priceIncludingTax\":93.12,\"quantity\":1.0},{\"index\":2,\"attribute\":\"0\",\"discountIndex\":0,\"name\":\"燃油附加费\",\"sn\":\"3010101020203000000\",\"taxRate\":6,\"priceIncludingTax\":3.0,\"quantity\":1.0}]";
            obj.setGoodsDetail(goods);
            obj.setRemark("setRemark");
            obj.setNotifyMobileNo("setNotifyMobileNo");
            obj.setNotifyEMail("setNotifyEMail");
            obj.setNotifyUrl("setNotifyUrl");
            obj.setMerWxAppId("setMerWxAppId");
            obj.setMerWxOrderId("setMerWxOrderId");
            obj.setStoreId("setStoreId");

            return obj;
        }
        //endregion

        @Test
        public void testWholeRequest() throws Exception {
            PivcEsFlow flow = new PivcEsFlow();
            PivcIssueRequest request = getWholeIssueRequest();
            sut.setEsFlowFromRequest2(flow, request);

            PivcUtilService utilService = new PivcUtilService();
            JsonObject joRequest = utilService.fromObject2Json(request);

            JsonObject joFlow = utilService.fromObject2Json(flow);

            Set<String> keyRequest = joRequest.keySet();
            Set<String> keyFlow = joFlow.keySet();

            Set<String> keyCommon = new HashSet<>(keyRequest);
            keyCommon.retainAll(keyFlow);

            System.out.println(keyCommon);

            for(String key : keyCommon){
                String valueOfRequest = utilService.getStringFromJson(joRequest, key);

                String valueOfFlow = utilService.getStringFromJson(joFlow, key);

                assertEquals(valueOfRequest, valueOfFlow);
            }


        }
    }


    @RunWith(SpringRunner.class)
    @TestPropertySource(locations = {"classpath:mypivc.properties"}, properties = {"invoicep.pivcIpsErrorcodeIntype=intype", "a.b.c=test"} )
    @SpringBootTest(classes = {PivcUtilService.class, PivcConf.class, PivcCommonService.class, PivcIssueService.class,
            PivcEsService.class, PivcEsRestClient.class })
    public static class initIssueSend{
        @Autowired
        protected PivcIssueService sut;

        //region create test requests
        protected PivcIssueRequest getWholeIssueRequest() {
            PivcIssueRequest obj = new PivcIssueRequest();
            obj.setMsgId("setMsgId");
            obj.setMsgSrc("setMsgSrc");
            obj.setRequestTimestamp("setRequestTimestamp");
            obj.setSrcReserve("setSrcReserve");
            obj.setInvoiceMaterial("setInvoiceMaterial");
            obj.setInvoiceType("setInvoiceType");
            obj.setMerOrderDate("setMerOrderDate");
            obj.setMerOrderId("setMerOrderId");
            obj.setBuyerName("setBuyerName");
            obj.setBuyerTaxCode("setBuyerTaxCode");
            obj.setBuyerAddress("setBuyerAddress");
            obj.setBuyerTelephone("setBuyerTelephone");
            obj.setBuyerBank("setBuyerBank");
            obj.setBuyerAccount("setBuyerAccount");
            obj.setAmount("setAmount");
            obj.setDeductionAmount("setDeductionAmount");

            String goods = "[{\"index\":1,\"attribute\":\"0\",\"discountIndex\":0,\"name\":\"车费\",\"sn\":\"3010101020203000000\",\"taxRate\":6,\"priceIncludingTax\":93.12,\"quantity\":1.0},{\"index\":2,\"attribute\":\"0\",\"discountIndex\":0,\"name\":\"燃油附加费\",\"sn\":\"3010101020203000000\",\"taxRate\":6,\"priceIncludingTax\":3.0,\"quantity\":1.0}]";
            obj.setGoodsDetail(goods);
            obj.setRemark("setRemark");
            obj.setNotifyMobileNo("setNotifyMobileNo");
            obj.setNotifyEMail("setNotifyEMail");
            obj.setNotifyUrl("setNotifyUrl");
            obj.setMerWxAppId("setMerWxAppId");
            obj.setMerWxOrderId("setMerWxOrderId");
            obj.setStoreId("setStoreId");

            return obj;
        }

        protected PivcIssueRequest getPartialMustRequest(){
            PivcIssueRequest obj = new PivcIssueRequest();
            obj.setMsgId("setMsgId");
            obj.setMsgSrc("setMsgSrc");
            obj.setRequestTimestamp("setRequestTimestamp");
            obj.setSrcReserve("");
            obj.setInvoiceMaterial("setInvoiceMaterial");
            obj.setInvoiceType("setInvoiceType");
            obj.setMerOrderDate("setMerOrderDate");
            obj.setMerOrderId("setMerOrderId");
            obj.setBuyerName("setBuyerName");
            obj.setBuyerTaxCode("");
            obj.setBuyerAddress("");
            obj.setBuyerTelephone("");
            obj.setBuyerBank("");
            obj.setBuyerAccount("");
            obj.setAmount("setAmount");
            obj.setDeductionAmount("");

            String goods = "[{\"index\":1,\"attribute\":\"0\",\"discountIndex\":0,\"name\":\"车费\",\"sn\":\"3010101020203000000\",\"taxRate\":6,\"priceIncludingTax\":93.12,\"quantity\":1.0},{\"index\":2,\"attribute\":\"0\",\"discountIndex\":0,\"name\":\"燃油附加费\",\"sn\":\"3010101020203000000\",\"taxRate\":6,\"priceIncludingTax\":3.0,\"quantity\":1.0}]";
            obj.setGoodsDetail("");
            obj.setRemark("");
            obj.setNotifyMobileNo("");
            obj.setNotifyEMail("");
            obj.setNotifyUrl("");
            obj.setMerWxAppId("");
            obj.setMerWxOrderId("");
            obj.setStoreId("");

            return obj;
        }

        //endregion



        @Test
        public void initIssueSendFullRequest() throws Exception {
            PivcIssueRequest fullIssue = getWholeIssueRequest();
            PivcIssueEndpointBean endissue = sut.initSendObject(fullIssue);

            System.out.println("===============================1");
            System.out.println(endissue);
            System.out.println("===============================1");
            JsonObject joTransfer = sut.utilService.fromObject2Json(endissue);
            assertEquals(26, joTransfer.size());

        }

        @Test
        public void initIssueSendPartialMustRequest() throws Exception {
            PivcIssueRequest fullIssue = getPartialMustRequest();
            PivcIssueEndpointBean endissue = sut.initSendObject(fullIssue);

            System.out.println("===============================1");
            System.out.println(endissue);
            System.out.println("===============================1");
            JsonObject joTransfer = sut.utilService.fromObject2Json(endissue);
            assertEquals(11, joTransfer.size());

        }
    }


    @RunWith(SpringRunner.class)
    @TestPropertySource(locations = {"classpath:mypivc.properties"}, properties = {"invoicep.pivcIpsErrorcodeIntype=intype", "a.b.c=test"})
    @SpringBootTest(classes = {PivcUtilService.class, PivcConf.class, PivcCommonService.class, PivcIssueService.class })
    public static class fmtRequest2InvoiceSendString{

        @Autowired
        protected PivcIssueService sut;

        //region create test requests
        protected PivcIssueRequest getWholeIssueRequest() {
            PivcIssueRequest obj = new PivcIssueRequest();
            obj.setMsgId("setMsgId");
            obj.setMsgSrc("setMsgSrc");
            obj.setRequestTimestamp("setRequestTimestamp");
            obj.setSrcReserve("setSrcReserve");
            obj.setInvoiceMaterial("setInvoiceMaterial");
            obj.setInvoiceType("setInvoiceType");
            obj.setMerOrderDate("setMerOrderDate");
            obj.setMerOrderId("setMerOrderId");
            obj.setBuyerName("setBuyerName");
            obj.setBuyerTaxCode("setBuyerTaxCode");
            obj.setBuyerAddress("setBuyerAddress");
            obj.setBuyerTelephone("setBuyerTelephone");
            obj.setBuyerBank("setBuyerBank");
            obj.setBuyerAccount("setBuyerAccount");
            obj.setAmount("setAmount");
            obj.setDeductionAmount("setDeductionAmount");

            String goods = "[{\"index\":1,\"attribute\":\"0\",\"discountIndex\":0,\"name\":\"车费\",\"sn\":\"3010101020203000000\",\"taxRate\":6,\"priceIncludingTax\":93.12,\"quantity\":1.0},{\"index\":2,\"attribute\":\"0\",\"discountIndex\":0,\"name\":\"燃油附加费\",\"sn\":\"3010101020203000000\",\"taxRate\":6,\"priceIncludingTax\":3.0,\"quantity\":1.0}]";
            obj.setGoodsDetail(goods);
            obj.setRemark("setRemark");
            obj.setNotifyMobileNo("setNotifyMobileNo");
            obj.setNotifyEMail("setNotifyEMail");
            obj.setNotifyUrl("setNotifyUrl");
            obj.setMerWxAppId("setMerWxAppId");
            obj.setMerWxOrderId("setMerWxOrderId");
            obj.setStoreId("setStoreId");

            return obj;
        }

        protected PivcIssueRequest getPartialMustRequest(){
            PivcIssueRequest obj = new PivcIssueRequest();
            obj.setMsgId("setMsgId");
            obj.setMsgSrc("setMsgSrc");
            obj.setRequestTimestamp("setRequestTimestamp");
            obj.setSrcReserve("");
            obj.setInvoiceMaterial("setInvoiceMaterial");
            obj.setInvoiceType("setInvoiceType");
            obj.setMerOrderDate("setMerOrderDate");
            obj.setMerOrderId("setMerOrderId");
            obj.setBuyerName("setBuyerName");
            obj.setBuyerTaxCode("");
            obj.setBuyerAddress("");
            obj.setBuyerTelephone("");
            obj.setBuyerBank("");
            obj.setBuyerAccount("");
            obj.setAmount("setAmount");
            obj.setDeductionAmount("");

            String goods = "[{\"index\":1,\"attribute\":\"0\",\"discountIndex\":0,\"name\":\"车费\",\"sn\":\"3010101020203000000\",\"taxRate\":6,\"priceIncludingTax\":93.12,\"quantity\":1.0},{\"index\":2,\"attribute\":\"0\",\"discountIndex\":0,\"name\":\"燃油附加费\",\"sn\":\"3010101020203000000\",\"taxRate\":6,\"priceIncludingTax\":3.0,\"quantity\":1.0}]";
            obj.setGoodsDetail("");
            obj.setRemark("");
            obj.setNotifyMobileNo("");
            obj.setNotifyEMail("");
            obj.setNotifyUrl("");
            obj.setMerWxAppId("");
            obj.setMerWxOrderId("");
            obj.setStoreId("");

            return obj;
        }

        //endregion

        @Test
        public void compareString() throws Exception{
            String left = "merchantId";
            String right = "merOrderDate";
            System.out.println( left.compareTo(right) );
        }

        @Test
        public void testPartialMustRequest() throws Exception {
            PivcIssueRequest request = getPartialMustRequest();
            String postdata = sut.fmtRequest2InvoiceSendString(request);
            String expected = "amount=setAmount&buyerName=setBuyerName&invoiceMaterial=setInvoiceMaterial&invoiceType=setInvoiceType&merOrderDate=setMerOrderDate&merOrderId=setMerOrderId&merchantId=&msgId=setMsgId&msgSrc=&requestTimestamp=setRequestTimestamp&terminalId=";
            assertEquals(expected, postdata);
        }
    }

    public static class testPivcIssueRequest2JsonObject{
        protected PivcIssueRequest getWholeIssueRequest() {
            PivcIssueRequest obj = new PivcIssueRequest();
            obj.setMsgId("setMsgId");
            obj.setMsgSrc("setMsgSrc");
            obj.setRequestTimestamp("setRequestTimestamp");
            obj.setSrcReserve("setSrcReserve");
            obj.setInvoiceMaterial("setInvoiceMaterial");
            obj.setInvoiceType("setInvoiceType");
            obj.setMerOrderDate("setMerOrderDate");
            obj.setMerOrderId("setMerOrderId");
            obj.setBuyerName("setBuyerName");
            obj.setBuyerTaxCode("setBuyerTaxCode");
            obj.setBuyerAddress("setBuyerAddress");
            obj.setBuyerTelephone("setBuyerTelephone");
            obj.setBuyerBank("setBuyerBank");
            obj.setBuyerAccount("setBuyerAccount");
            obj.setAmount("setAmount");
            obj.setDeductionAmount("setDeductionAmount");

            String goods = "[{\"index\":1,\"attribute\":\"0\",\"discountIndex\":0,\"name\":\"车费\",\"sn\":\"3010101020203000000\",\"taxRate\":6,\"priceIncludingTax\":93.12,\"quantity\":1.0},{\"index\":2,\"attribute\":\"0\",\"discountIndex\":0,\"name\":\"燃油附加费\",\"sn\":\"3010101020203000000\",\"taxRate\":6,\"priceIncludingTax\":3.0,\"quantity\":1.0}]";
            obj.setGoodsDetail(goods);
            obj.setRemark("setRemark");
            obj.setNotifyMobileNo("setNotifyMobileNo");
            obj.setNotifyEMail("setNotifyEMail");
            obj.setNotifyUrl("setNotifyUrl");
            obj.setMerWxAppId("setMerWxAppId");
            obj.setMerWxOrderId("setMerWxOrderId");
            obj.setStoreId("setStoreId");

            return obj;
        }
        @Test
        public void test() throws Exception {
            PivcUtilService utilService = new PivcUtilService();

            PivcIssueRequest whole = getWholeIssueRequest();
            JsonObject joIssue = utilService.fromObject2Json(whole);

            JsonElement gdetail = joIssue.get("goodsDetail");
            System.out.println(gdetail);
            assertTrue(gdetail.isJsonPrimitive());

            String goods = "[{\"index\":1,\"attribute\":\"0\",\"discountIndex\":0,\"name\":\"车费\",\"sn\":\"3010101020203000000\",\"taxRate\":6,\"priceIncludingTax\":93.12,\"quantity\":1.0},{\"index\":2,\"attribute\":\"0\",\"discountIndex\":0,\"name\":\"燃油附加费\",\"sn\":\"3010101020203000000\",\"taxRate\":6,\"priceIncludingTax\":3.0,\"quantity\":1.0}]";
            assertEquals(goods, gdetail.getAsString());
        }
    }












}