package com.ebankunion.invoicep.bean;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * ██╗  ██╗██╗    ██╗ ██████╗
 * ██║  ██║██║    ██║██╔════╝
 * ███████║██║ █╗ ██║██║  ███╗
 * ██╔══██║██║███╗██║██║   ██║
 * ██║  ██║╚███╔███╔╝╚██████╔╝
 * ╚═╝  ╚═╝ ╚══╝╚══╝  ╚═════╝
 * Created by huwenguang on 2019/3/26.
 */
@DisplayName("test1")
public class PivcEsFlowTest {

    @org.junit.jupiter.api.BeforeEach
    void setUp() {
    }

    @org.junit.jupiter.api.AfterEach
    void tearDown() {
    }

    @Test
    void test() {
    }

    @Nested
    @DisplayName("test2")
    class ConstructorTest{
        @Test
        void test() {
            assertTrue(true);
        }
    }

    @Nested
    @DisplayName("test3")
    class DestructionTest{
        @Test
        void test() {
            assertFalse(false);
        }
    }
}