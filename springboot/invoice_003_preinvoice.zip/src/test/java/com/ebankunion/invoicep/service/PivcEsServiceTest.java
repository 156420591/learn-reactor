package com.ebankunion.invoicep.service;

import com.ebankunion.invoicep.bean.PivcConf;
import com.google.gson.JsonObject;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.configurationprocessor.json.JSONObject;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;

import static org.junit.Assert.*;

/**
 * ██╗  ██╗██╗    ██╗ ██████╗
 * ██║  ██║██║    ██║██╔════╝
 * ███████║██║ █╗ ██║██║  ███╗
 * ██╔══██║██║███╗██║██║   ██║
 * ██║  ██║╚███╔███╔╝╚██████╔╝
 * ╚═╝  ╚═╝ ╚══╝╚══╝  ╚═════╝
 * Created by huwenguang on 2019/3/20.
 */
public class PivcEsServiceTest {

    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void test() throws Exception {
    }


    @RunWith(SpringRunner.class)
    @TestPropertySource(properties = {"invoicep.pivcESIndex=mkyong","invoicep.pivcESType=posts","invoice.esUrl=http://127.0.0.1:9200"})
    @SpringBootTest(classes = {PivcUtilService.class, PivcConf.class, PivcEsRestClient.class, PivcEsService.class })
    public static class JaycePivcEsService{

        @Autowired
        protected PivcEsService sut;

        @Test
        public void testUpdate() throws Exception {
            JsonObject joDoc = new JsonObject();
            joDoc.addProperty("title", "newtitle");
            joDoc.addProperty("name", "newtitlexxx111");

            sut.updateEs("1004", joDoc.toString());

        }


        @Test
        public void testInsert() throws Exception {
            JsonObject joDoc = new JsonObject();
            joDoc.addProperty("title", "newtitle");
            joDoc.addProperty("name", "newtitle");

            sut.insertEs("1006", joDoc.toString());

        }
    }
}