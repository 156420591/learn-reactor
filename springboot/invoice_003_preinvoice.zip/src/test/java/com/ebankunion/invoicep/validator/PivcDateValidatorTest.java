package com.ebankunion.invoicep.validator;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

/**
 * ██╗  ██╗██╗    ██╗ ██████╗
 * ██║  ██║██║    ██║██╔════╝
 * ███████║██║ █╗ ██║██║  ███╗
 * ██╔══██║██║███╗██║██║   ██║
 * ██║  ██║╚███╔███╔╝╚██████╔╝
 * ╚═╝  ╚═╝ ╚══╝╚══╝  ╚═════╝
 * Created by huwenguang on 2019/3/18.
 */
public class PivcDateValidatorTest {

    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }

    public static class validateDate{
        PivcDateValidator sut = new PivcDateValidator();

        @Test
        public void dateNotNumber() throws Exception{
            String input = "2019031x";
            boolean result = sut.validateDate(input);
            assertFalse(result);
        }


        @Test
        public void dateContainsWhite() throws Exception{
            String input = "2019031 ";
            boolean result = sut.validateDate(input);
            assertFalse(result);
        }


        @Test
        public void dateNotValid() throws Exception{
            String input = "20190332";
            boolean result = sut.validateDate(input);
            assertFalse(result);
        }


        @Test
        public void dateValid() throws Exception{
            String input = "20190330";
            boolean result = sut.validateDate(input);
            assertTrue(result);
        }
    }
}