package com.ebankunion.invoicep.service;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.logging.Level;

import static org.junit.Assert.*;

/**
 * ██╗  ██╗██╗    ██╗ ██████╗
 * ██║  ██║██║    ██║██╔════╝
 * ███████║██║ █╗ ██║██║  ███╗
 * ██╔══██║██║███╗██║██║   ██║
 * ██║  ██║╚███╔███╔╝╚██████╔╝
 * ╚═╝  ╚═╝ ╚══╝╚══╝  ╚═════╝
 * Created by huwenguang on 2019/3/12.
 */
public class PivcMonitorServiceTest {

    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void test() throws Exception {
    }

    public static class takeRight{
        Logger logger = LoggerFactory.getLogger(takeRight.class);

        PivcMonitorService sut;

        @Before
        public void setUp() throws Exception {
            sut = new PivcMonitorService();

        }

        @Test
        public void testHalfChs() throws Exception {
            String strSource = "胡";
            String result = sut.takeRight(strSource, 1);


            System.out.println(result);
        }

        @Test
        public void testHalfChs1() throws Exception {
            String strSource = "1胡";
            String result = sut.takeRight(strSource, 1);


            System.out.println(result);
        }
    }
}