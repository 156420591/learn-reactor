package com.ebankunion.invoicep.bean;

import com.ebankunion.invoicep.service.PivcUtilService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.Properties;

import static org.junit.Assert.*;

/**
 * ██╗  ██╗██╗    ██╗ ██████╗
 * ██║  ██║██║    ██║██╔════╝
 * ███████║██║ █╗ ██║██║  ███╗
 * ██╔══██║██║███╗██║██║   ██║
 * ██║  ██║╚███╔███╔╝╚██████╔╝
 * ╚═╝  ╚═╝ ╚══╝╚══╝  ╚═════╝
 * Created by huwenguang on 2019/3/8.
 */
public class PivcConfTest {
    @Test
    public void test() throws Exception {
    }

    @RunWith(SpringJUnit4ClassRunner.class)
    //@ContextConfiguration({ "classpath:mypivc.properties" })
    //@TestPropertySource(locations = {"classpath*:mypivc.properties"})
    @TestPropertySource(locations = {"classpath:mypivc.properties"})
    @SpringBootTest(classes = { PivcConf.class })
    public static class testTheRealFile{
        @Autowired
        PivcConf sut;

        @Test
        public void test() throws Exception {
            assertEquals(30, sut.getPivcHttpTimeout());
            assertEquals("mytoken", sut.getPivcMysqlUsertoken());
        }

    }



    @RunWith(SpringJUnit4ClassRunner.class)
    @TestPropertySource(locations = {"classpath:mypivc.properties"}, properties = {"invoicep.pivcHttpTimeout=40", "a.b.c=test"})
    @SpringBootTest(classes = { PivcConf.class })
    public static class halfRealHalfFake{

        @Autowired
        PivcConf sut;

        @Test
        public void test() throws Exception {
            assertEquals(40, sut.getPivcHttpTimeout());
            assertEquals("mytoken", sut.getPivcMysqlUsertoken());
        }

    }

}