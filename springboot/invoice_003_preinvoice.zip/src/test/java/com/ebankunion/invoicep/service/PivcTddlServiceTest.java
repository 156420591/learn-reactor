package com.ebankunion.invoicep.service;

import com.ebankunion.invoice.App;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.experimental.runners.Enclosed;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import static org.junit.Assert.*;

/**
 * ██╗  ██╗██╗    ██╗ ██████╗
 * ██║  ██║██║    ██║██╔════╝
 * ███████║██║ █╗ ██║██║  ███╗
 * ██╔══██║██║███╗██║██║   ██║
 * ██║  ██║╚███╔███╔╝╚██████╔╝
 * ╚═╝  ╚═╝ ╚══╝╚══╝  ╚═════╝
 * Created by huwenguang on 2019/3/5.
 */
@RunWith(Enclosed.class)
public class PivcTddlServiceTest {

    public static class mysqlQueryTimeout{
        @Test
        public void testNormalGood_hasResult() throws Exception{
            PivcTddlService sut = new PivcTddlService();
            PivcTddlService sut_spy = org.mockito.Mockito.spy(sut);
            String url = "http://test.com";
            int secTimeout = 10;
            String db = "mydb";
            String tablename = "mytable";
            String usertoken = "mytoken";
            JsonObject conditions = new JsonObject(); conditions.addProperty("name", "hwg");
            JsonObject retcols = new JsonObject(); retcols.addProperty("name", "1"); retcols.addProperty("age", "1");

            String strTddl = "{\"retcode\":\"0000\", \"res\":[{\"name\":\"hwg\",\"age\":\"100\"},{\"name\":\"hwg\",\"age\":\"100\"}]}";
            org.mockito.Mockito.doReturn(strTddl).when(sut_spy)
                    .httpPostGetString(org.mockito.Mockito.eq(url), org.mockito.Mockito.eq(secTimeout), org.mockito.Mockito.anyString());

            // *NOTICE*
//            org.mockito.Mockito.when(sut_spy.httpPostGetString(org.mockito.Mockito.eq(url), org.mockito.Mockito.eq(secTimeout), org.mockito.Mockito.anyString()))
//                    .thenReturn(strTddl);

            JsonArray result = sut_spy.mysqlQueryTimeout(url, secTimeout, db, tablename, usertoken, conditions, retcols);
            assertEquals(2, result.size());

        }


        @Test
        public void testNormalGood_noResult1() throws Exception{
            PivcTddlService sut = new PivcTddlService();
            PivcTddlService sut_spy = org.mockito.Mockito.spy(sut);
            String url = "http://test.com";
            int secTimeout = 10;
            String db = "mydb";
            String tablename = "mytable";
            String usertoken = "mytoken";
            JsonObject conditions = new JsonObject(); conditions.addProperty("name", "hwg");
            JsonObject retcols = new JsonObject(); retcols.addProperty("name", "1"); retcols.addProperty("age", "1");

            String strTddl = "{\"retcode\":\"0000\", \"res\":{} }";
            org.mockito.Mockito.doReturn(strTddl).when(sut_spy)
                    .httpPostGetString(org.mockito.Mockito.eq(url), org.mockito.Mockito.eq(secTimeout), org.mockito.Mockito.anyString());

            // *NOTICE*
//            org.mockito.Mockito.when(sut_spy.httpPostGetString(org.mockito.Mockito.eq(url), org.mockito.Mockito.eq(secTimeout), org.mockito.Mockito.anyString()))
//                    .thenReturn(strTddl);

            JsonArray result = sut_spy.mysqlQueryTimeout(url, secTimeout, db, tablename, usertoken, conditions, retcols);
            assertEquals(0, result.size());

        }


        @Test
        public void testNormalGood_noResult2() throws Exception{
            PivcTddlService sut = new PivcTddlService();
            PivcTddlService sut_spy = org.mockito.Mockito.spy(sut);
            String url = "http://test.com";
            int secTimeout = 10;
            String db = "mydb";
            String tablename = "mytable";
            String usertoken = "mytoken";
            JsonObject conditions = new JsonObject(); conditions.addProperty("name", "hwg");
            JsonObject retcols = new JsonObject(); retcols.addProperty("name", "1"); retcols.addProperty("age", "1");

            String strTddl = "{\"retcode\":\"0000\", \"res\":[] }";
            org.mockito.Mockito.doReturn(strTddl).when(sut_spy)
                    .httpPostGetString(org.mockito.Mockito.eq(url), org.mockito.Mockito.eq(secTimeout), org.mockito.Mockito.anyString());

            // *NOTICE*
//            org.mockito.Mockito.when(sut_spy.httpPostGetString(org.mockito.Mockito.eq(url), org.mockito.Mockito.eq(secTimeout), org.mockito.Mockito.anyString()))
//                    .thenReturn(strTddl);

            JsonArray result = sut_spy.mysqlQueryTimeout(url, secTimeout, db, tablename, usertoken, conditions, retcols);
            assertEquals(0, result.size());

        }


        @Ignore
        @Test
        public void testNormalGood_1() throws Exception{
            PivcTddlService sut = org.mockito.Mockito.mock(PivcTddlService.class);
            String url = "http://test.com";
            int secTimeout = 10;
            String db = "mydb";
            String tablename = "mytable";
            String usertoken = "mytoken";
            JsonObject conditions = new JsonObject(); conditions.addProperty("name", "hwg");
            JsonObject retcols = new JsonObject(); retcols.addProperty("name", "1"); retcols.addProperty("age", "1");

            String strTddl = "{\"retcode\":\"0000\", \"res\":[{\"name\":\"hwg\",\"age\":\"100\"},{\"name\":\"hwg\",\"age\":\"100\"}]}";
            org.mockito.Mockito.when(sut.httpPostGetString(org.mockito.Mockito.eq(url), org.mockito.Mockito.eq(secTimeout), org.mockito.Mockito.anyString()))
                    .thenReturn(strTddl);
            org.mockito.Mockito.doCallRealMethod().when(sut).mysqlQueryTimeout(url, secTimeout, db, tablename, usertoken, conditions, retcols);
            org.mockito.Mockito.doCallRealMethod().when(sut).genMysqlQueryPostdata(db, tablename, usertoken, conditions, retcols);
            org.mockito.Mockito.doCallRealMethod().when(sut).httpPost(org.mockito.Mockito.eq(url), org.mockito.Mockito.eq(secTimeout), org.mockito.Mockito.anyString());
            org.mockito.Mockito.doCallRealMethod().when(sut).parseTddlMysqlQuery(org.mockito.Mockito.any(JsonObject.class) );
            org.mockito.Mockito.doCallRealMethod().when(sut).parseJsonFromString(org.mockito.Mockito.any(String.class) );
            org.mockito.Mockito.doCallRealMethod().when(sut).getStringFromJson(org.mockito.Mockito.any(JsonObject.class), org.mockito.Mockito.anyString() );
            org.mockito.Mockito.doCallRealMethod().when(sut).mylog(org.mockito.Mockito.any(Object.class)  );


            JsonArray result = sut.mysqlQueryTimeout(url, secTimeout, db, tablename, usertoken, conditions, retcols);
            assertEquals(2, result.size());

        }

        @Test
        public void testTimeout() throws Exception{

        }


        @Test
        public void testFailed() throws Exception{
            PivcTddlService sut = new PivcTddlService();
            PivcTddlService sut_spy = org.mockito.Mockito.spy(sut);
            String url = "http://test.com";
            int secTimeout = 10;
            String db = "mydb";
            String tablename = "mytable";
            String usertoken = "mytoken";
            JsonObject conditions = new JsonObject(); conditions.addProperty("name", "hwg");
            JsonObject retcols = new JsonObject(); retcols.addProperty("name", "1"); retcols.addProperty("age", "1");

            String strTddl = "{\"retcode\":\"8999\", \"res\":[{\"name\":\"hwg\",\"age\":\"100\"},{\"name\":\"hwg\",\"age\":\"100\"}]}";
            org.mockito.Mockito.doReturn(strTddl).when(sut_spy)
                    .httpPostGetString(org.mockito.Mockito.eq(url), org.mockito.Mockito.eq(secTimeout), org.mockito.Mockito.anyString());


            JsonArray result = sut_spy.mysqlQueryTimeout(url, secTimeout, db, tablename, usertoken, conditions, retcols);
            assertEquals(0, result.size());

        }


        @Test
        public void testFailed_returnHtml() throws Exception{
            PivcTddlService sut = new PivcTddlService();
            PivcTddlService sut_spy = org.mockito.Mockito.spy(sut);
            String url = "http://test.com";
            int secTimeout = 10;
            String db = "mydb";
            String tablename = "mytable";
            String usertoken = "mytoken";
            JsonObject conditions = new JsonObject(); conditions.addProperty("name", "hwg");
            JsonObject retcols = new JsonObject(); retcols.addProperty("name", "1"); retcols.addProperty("age", "1");

            String strTddl = "<html>failed</html>";
            org.mockito.Mockito.doReturn(strTddl).when(sut_spy)
                    .httpPostGetString(org.mockito.Mockito.eq(url), org.mockito.Mockito.eq(secTimeout), org.mockito.Mockito.anyString());


            JsonArray result = sut_spy.mysqlQueryTimeout(url, secTimeout, db, tablename, usertoken, conditions, retcols);
            assertEquals(0, result.size());

        }


        @Test
        public void testStatusCodeNot2xx() throws Exception{

        }
    }

    @RunWith(SpringRunner.class)
    @SpringBootTest(classes={App.class})
    public static class isTddlSuccess_startTheServer{
//        @Configuration
//        class TddlServiceConf{
//            @Bean
//            public PivcTddlService getTddl(){
//                return new PivcTddlService();
//            }
//        }

        @Autowired
        PivcTddlService pivcTddlService;

        @Test
        public void noRetcode() throws Exception{
            JsonObject joTddl = new JsonObject();
            assertFalse( pivcTddlService.isTddlSuccess(joTddl) );
        }
    }


    public static class isTddlSuccessNoServer{
        @Test
        public void noRetcode() throws Exception{
            PivcTddlService pivcTddlService = new PivcTddlService();
            JsonObject joTddl = new JsonObject();
            assertFalse( pivcTddlService.isTddlSuccess(joTddl) );
        }


        @Test
        public void retcodeIsJsonObject() throws Exception{
            PivcTddlService pivcTddlService = new PivcTddlService();
            JsonObject joTddl = new JsonObject(); JsonObject jotest = new JsonObject();
            joTddl.add("retcode", jotest);
            assertFalse( pivcTddlService.isTddlSuccess(joTddl) );
        }
    }



    public static class getStringFromJson{
        @Test
        public void testStringFromInt() throws Exception{
            JsonObject jo = new JsonObject();
            jo.addProperty("age", 100);

            PivcTddlService sut = new PivcTddlService();
            String value = sut.getStringFromJson(jo, "age");
            assertEquals("100", value);
        }


        @Test
        public void testStringFromObject() throws Exception{
            JsonObject jo = new JsonObject();
            jo.addProperty("age", 100);
            JsonObject joSub = new JsonObject();
            joSub.addProperty("name", "hwg");
            jo.add("subitem", joSub);

            PivcTddlService sut = new PivcTddlService();
            String value = sut.getStringFromJson(jo, "subitem");
            System.out.println(value);
            assertEquals("", value);
        }


        @Test
        public void keyNotExist() throws Exception{
            JsonObject jo = new JsonObject();
            jo.addProperty("age", 100);

            PivcTddlService sut = new PivcTddlService();
            String value = sut.getStringFromJson(jo, "age11");
            assertEquals("", value);
        }

    }
    public static class myTestJson{
        @Test
        public void printArray() throws Exception{
            JsonObject jo = new JsonObject();
            jo.addProperty("name", "hwg");
            jo.addProperty("age", "100");
            JsonArray jsonArray = new JsonArray();
            jsonArray.add(jo);
            jsonArray.add(jo);

            JsonObject joAll = new JsonObject();
            joAll.add("res", jsonArray);

            System.out.println(joAll.toString());
        }

        @Test
        public void test() throws Exception{
            JsonObject jo = new JsonObject();
            jo.addProperty("name", "apple");
            jo.addProperty("color", "black");

            System.out.println(jo.toString());
        }
        @Test
        public void test1() throws Exception{
            JsonObject jo = new JsonObject();
            jo.addProperty("name", "apple");
            jo.addProperty("color", "black");

            assertNull(jo.get("not"));
//            assertNull(jo.get("notexist").getAsString() );
        }

        @Test(expected = JsonSyntaxException.class)
        public void test2() throws Exception{
            JsonObject jo = new Gson().fromJson("{test", JsonObject.class);
        }
    }

    public static class getBase64{
        @Test
        public void test() throws Exception{
            PivcTddlService sut = new PivcTddlService();
            String mybase64 = sut.getBase64("test");
            assertEquals("dGVzdA==", mybase64);
        }
    }


    public static class genPostdata{
        @Test
        public void template() throws Exception{
        }


        @Test
        public void print1() throws Exception{
            PivcTddlService sut = new PivcTddlService();
            JsonObject jocondition = new JsonObject();
            jocondition.addProperty("user", "hwg");
            jocondition.addProperty("color", "black");

            JsonObject joretcol = new JsonObject();
            joretcol.addProperty("user", "1");
            joretcol.addProperty("color", "1");
            String postdata = sut.genMysqlQueryPostdata("db", "tablename", "usertoken", jocondition, joretcol);
            System.out.println(postdata);
        }
    }


}