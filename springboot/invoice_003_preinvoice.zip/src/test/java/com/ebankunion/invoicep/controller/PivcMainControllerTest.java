package com.ebankunion.invoicep.controller;

import com.ebankunion.invoice.App;
import com.ebankunion.invoicep.bean.PivcIssueRequest;
import com.ebankunion.invoicep.exception.PivcArgumentCheckException;
import com.ebankunion.invoicep.exception.PivcException;
import com.ebankunion.invoicep.service.PivcUtilService;
import com.google.gson.JsonObject;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.experimental.runners.Enclosed;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.mock.mockito.SpyBean;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.validation.BindingResult;

import static org.hamcrest.core.IsEqual.equalTo;
import static org.junit.Assert.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * ██╗  ██╗██╗    ██╗ ██████╗
 * ██║  ██║██║    ██║██╔════╝
 * ███████║██║ █╗ ██║██║  ███╗
 * ██╔══██║██║███╗██║██║   ██║
 * ██║  ██║╚███╔███╔╝╚██████╔╝
 * ╚═╝  ╚═╝ ╚══╝╚══╝  ╚═════╝
 * Created by huwenguang on 2019/3/5.
 */
public class PivcMainControllerTest {


    @RunWith(Enclosed.class)
    public static class issueControllerTest{


        @RunWith(SpringRunner.class)
        @SpringBootTest( webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT, classes = App.class)
        @AutoConfigureMockMvc
        public static class issueRequestParamException_mvc{
            @Autowired
            private MockMvc mockMvc;


            @Test
            public void test1() throws Exception {

                MultiValueMap<String, String> myparam = new LinkedMultiValueMap<>();
                PivcArgumentCheckException exExpected = new PivcArgumentCheckException();

                mockMvc.perform(
                        post("/ips/invoicep/issue").params(myparam)
                )
                        .andDo(print())
                        .andExpect(status().isOk())
                        .andExpect(  jsonPath("$.retcode").value(exExpected.getRetcode())  )
                ;
            }
        }


        @RunWith(SpringRunner.class)
        @SpringBootTest( webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT, classes = App.class)
        @AutoConfigureMockMvc
        public static class issueRequestParamException_mvc_throwException{
            @Autowired
            private MockMvc mockMvc;

            @MockBean
            private PivcUtilService utilService;

            @InjectMocks
            private PivcMainController controller;

            protected MultiValueMap<String, String> getIssueWholeParam(){
                MultiValueMap<String, String> myparam = new LinkedMultiValueMap<>();
                myparam.add("msgId", "msgId");
                myparam.add("msgSrc", "msgSrc");
                myparam.add("requestTimestamp", "2019-03-18 14:00:00");
                myparam.add("srcReserve", "srcReserve");
                myparam.add("invoiceMaterial", "PAPER");
                myparam.add("invoiceType", "PLAIN");
                myparam.add("merOrderDate", "20190318");
                myparam.add("merOrderId", "merOrderId");
                myparam.add("buyerName", "buyerName");
                myparam.add("buyerTaxCode", "buyerTaxCode");
                myparam.add("buyerAddress", "buyerAddress");
                myparam.add("buyerTelephone", "buyerTelephone");
                myparam.add("buyerBank", "buyerBank");
                myparam.add("buyerAccount", "buyerAccount");
                myparam.add("amount", "111112222233");
                myparam.add("deductionAmount", "111112222233");
                myparam.add("goodsDetail", "goodsDetail");
                myparam.add("remark", "remark");
                myparam.add("notifyMobileNo", "notifyMobileNo");
                myparam.add("notifyEMail", "notifyEMail");
                myparam.add("notifyUrl", "notifyUrl");
                myparam.add("merWxAppId", "merWxAppId");
                myparam.add("merWxOrderId", "merWxOrderId");
                myparam.add("storeId", "storeId");
                myparam.add("sign", "sign");

                return myparam;
            }

            @Test
            public void mercServiceThrowException() throws Exception {
                org.mockito.Mockito.doThrow(RuntimeException.class).when(utilService).fromObject2Json(org.mockito.Mockito.any(Object.class));

                MultiValueMap<String, String> myparam = getIssueWholeParam();

                PivcException exExpected = new PivcException();

                mockMvc.perform(
                        post("/ips/invoicep/issue").params(myparam)
                )
                        .andDo(print())
                        .andExpect(status().isOk())
                        .andExpect(  jsonPath("$.retcode").value(exExpected.getRetcode())  )
                ;
            }
        }




        @RunWith(SpringRunner.class)
        @SpringBootTest( webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT, classes = App.class)
        public static class issueRequestParamException_RestTemplate{
            @LocalServerPort
            private int port;

            @Autowired
            private TestRestTemplate restTemplate;


            @Ignore
            @Test
            public void test1() throws Exception {
                MultiValueMap<String, String> myparam = new LinkedMultiValueMap<>();
                String myurl = String.format("http://localhost:%s/ips/invoicep/issue", port);
                Object result = restTemplate.getForObject(myurl, PivcIssueRequest.class, myparam);

                System.out.println(result);
            }

            @Ignore
            @Test
            public void test2() throws Exception{
                String myurl = String.format("http://localhost:%s/ips/invoicep/issue", port);

                TestRestTemplate testRestTemplate = new TestRestTemplate();
                ResponseEntity<Object> response = testRestTemplate.getForEntity(myurl, Object.class);

                assertThat(response.getStatusCode(), equalTo(HttpStatus.OK));
            }
        }

    }



}