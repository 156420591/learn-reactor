package com.ebankunion.invoicep.validator;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

/**
 * ██╗  ██╗██╗    ██╗ ██████╗
 * ██║  ██║██║    ██║██╔════╝
 * ███████║██║ █╗ ██║██║  ███╗
 * ██╔══██║██║███╗██║██║   ██║
 * ██║  ██║╚███╔███╔╝╚██████╔╝
 * ╚═╝  ╚═╝ ╚══╝╚══╝  ╚═════╝
 * Created by huwenguang on 2019/3/18.
 */
public class PivcRequestDatetimeValidatorTest {

    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }

    public static class validateDatetime{
        protected PivcRequestDatetimeValidator sut = new PivcRequestDatetimeValidator();

        @Test
        public void testNullEmpty() throws Exception{
            String input = null;
            boolean result;
            result = sut.validateDatetime(input);
            assertFalse(result);

            input = "";
            result = sut.validateDatetime(input);
            assertFalse(result);
        }


        @Test
        public void testLengthNotOk() throws Exception{
            String input = "2019-03-01 14:00:00 ";
            boolean result;
            result = sut.validateDatetime(input);
            assertFalse(result);

        }


        @Test
        public void dateTimeNotOk() throws Exception{
            String input = "2019-03-41 14:00:00";
            boolean result;
            result = sut.validateDatetime(input);
            assertFalse(result);

        }


        @Test
        public void dateTimeContainsNoNumber() throws Exception{
            String input = "2019-rt-41 14:00:00";
            boolean result;
            result = sut.validateDatetime(input);
            assertFalse(result);

        }


        @Test
        public void timeIsNotOk() throws Exception{
            String input = "2019-02-01 30:00:00";
            boolean result;
            result = sut.validateDatetime(input);
            assertFalse(result);

        }


        @Test
        public void okDatetime() throws Exception{
            String input = "2019-02-01 01:00:00";
            boolean result;
            result = sut.validateDatetime(input);
            assertTrue(result);

        }
    }

    public static class jayceValidate{

        protected PivcRequestDatetimeValidator sut = new PivcRequestDatetimeValidator();

        @Test
        public void dateTimeNotOk() throws Exception{
            String input = "2019-03-41 14:00:00";
            boolean result;
            result = sut.jayceValidate(input, "yyyy-MM-dd HH:mm:ss");
            assertFalse(result);

        }
    }
}