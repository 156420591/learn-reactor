package com.ebankunion.invoicep.service;

import com.ebankunion.invoice.util.Sign;
import com.ebankunion.invoicep.bean.PivcQueryfuzzytitleRequest;
import com.ebankunion.invoicep.exception.PivcLogicCheckException;
import com.google.gson.JsonObject;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Map;

import static org.junit.Assert.*;

/**
 * ██╗  ██╗██╗    ██╗ ██████╗
 * ██║  ██║██║    ██║██╔════╝
 * ███████║██║ █╗ ██║██║  ███╗
 * ██╔══██║██║███╗██║██║   ██║
 * ██║  ██║╚███╔███╔╝╚██████╔╝
 * ╚═╝  ╚═╝ ╚══╝╚══╝  ╚═════╝
 * Created by huwenguang on 2019/3/7.
 */
public class PivcMercServiceTest {

    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void test() throws Exception {
    }

    @RunWith(SpringRunner.class)
    @SpringBootTest(classes = {PivcMercService.class, PivcTddlService.class, PivcUtilService.class})
    public static class checkMsgSign{
        @Autowired
        PivcMercService sut;
        @Autowired
        PivcUtilService utilService;
        protected JsonObject getQueryFuzzyTitle(){
            PivcQueryfuzzytitleRequest request = new PivcQueryfuzzytitleRequest();
            request.setMsgId("setMsgId");
            request.setMsgSrc("setMsgSrc");
            request.setName("setName");
            request.setRequestTimestamp("setRequestTimestamp");
            request.setSign("setSign");
            request.setSrcReserve("setSrcReserve");
            request.setTaxCode("setTaxCode");

            JsonObject jsonObject = utilService.fromObject2Json(request);
            return jsonObject;
        }

        @Test
        public void testSignEqual() throws Exception {
            JsonObject joOrgMsg = getQueryFuzzyTitle();
            String key = "akey";

            Map<String, Object> mymap = utilService.fromObject2Map(joOrgMsg);
            String theirs = Sign.mapDoSign(mymap, key);

            joOrgMsg.addProperty("sign", theirs);

            sut.checkMsgSign(joOrgMsg, key);

        }
    }

    @RunWith(SpringRunner.class)
    @SpringBootTest(classes = {PivcMercService.class, PivcTddlService.class, PivcUtilService.class})
    public static class checkSingleMaxAmount{
        @Autowired
        protected PivcMercService sut;

        @Test
        public void dbAmountEmpty() throws Exception {
            String amount = "";
            String dbMaxAmount = "";
            sut.checkSingleMaxAmount(amount, dbMaxAmount);
        }

        @Test
        public void dbAmountNull() throws Exception {
            String amount = "";
            String dbMaxAmount = null;
            sut.checkSingleMaxAmount(amount, dbMaxAmount);
        }


        @Test
        public void dbAmountZero() throws Exception {
            String amount = "";
            String dbMaxAmount = "0";
            sut.checkSingleMaxAmount(amount, dbMaxAmount);
        }


        @Test
        public void dbAmountSmall() throws Exception {
            String amount = "999999999990";
            String dbMaxAmount = "999999999999";
            sut.checkSingleMaxAmount(amount, dbMaxAmount);
        }

        @Test
        public void dbAmountEqual() throws Exception {
            String amount = "999999999999";
            String dbMaxAmount = "999999999999";
            sut.checkSingleMaxAmount(amount, dbMaxAmount);
        }

        @Test
        public void dbAmountBigger() throws Exception {
            String amount = "999999999999";
            String dbMaxAmount = "999999999998";
            try{
                sut.checkSingleMaxAmount(amount, dbMaxAmount);
                fail();
            }catch (PivcLogicCheckException e){
                System.out.println(e);
            }
        }
    }
}