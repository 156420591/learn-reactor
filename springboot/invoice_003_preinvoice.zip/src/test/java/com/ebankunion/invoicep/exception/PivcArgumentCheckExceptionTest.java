package com.ebankunion.invoicep.exception;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

/**
 * ██╗  ██╗██╗    ██╗ ██████╗
 * ██║  ██║██║    ██║██╔════╝
 * ███████║██║ █╗ ██║██║  ███╗
 * ██╔══██║██║███╗██║██║   ██║
 * ██║  ██║╚███╔███╔╝╚██████╔╝
 * ╚═╝  ╚═╝ ╚══╝╚══╝  ╚═════╝
 * Created by huwenguang on 2019/3/6.
 */
public class PivcArgumentCheckExceptionTest {

    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void testDefaultConstruction() throws Exception {
        PivcArgumentCheckException sut = new PivcArgumentCheckException();
        assertEquals(PivcExceptionConst.ARGERROR_Retcode, sut.getRetcode());
        assertEquals(PivcExceptionConst.ARGERROR_Retmsg, sut.getRetmsg());
    }

    @Test
    public void testSetAdditionMsg() throws Exception {
        PivcArgumentCheckException sut = new PivcArgumentCheckException();
        sut.setAdditionmsg("名字不能为空");
        String expected = String.format("%s[%s]",  PivcExceptionConst.ARGERROR_Retmsg, "名字不能为空" );

        assertEquals(PivcExceptionConst.ARGERROR_Retcode, sut.getRetcode());
        assertEquals(expected, sut.getRetmsg());
        System.out.println(sut);
    }

    @Test
    public void testSetAdditionMsg_setTwice() throws Exception {
        PivcArgumentCheckException sut = new PivcArgumentCheckException();
        String myadd = "";
        myadd = "名字不能为空";
        sut.setAdditionmsg(myadd);
        String expected = String.format("%s[%s]",  PivcExceptionConst.ARGERROR_Retmsg,  myadd);

        assertEquals(PivcExceptionConst.ARGERROR_Retcode, sut.getRetcode());
        assertEquals(expected, sut.getRetmsg());
        System.out.println(sut);


        myadd = "姓名不合法";
        sut.setAdditionmsg(myadd);
        expected = String.format("%s[%s]",  PivcExceptionConst.ARGERROR_Retmsg,  myadd);

        assertEquals(PivcExceptionConst.ARGERROR_Retcode, sut.getRetcode());
        assertEquals(expected, sut.getRetmsg());
        System.out.println(sut);
    }
}