package com.ebankunion.invoicep.exception;

/**
 * ██╗  ██╗██╗    ██╗ ██████╗
 * ██║  ██║██║    ██║██╔════╝
 * ███████║██║ █╗ ██║██║  ███╗
 * ██╔══██║██║███╗██║██║   ██║
 * ██║  ██║╚███╔███╔╝╚██████╔╝
 * ╚═╝  ╚═╝ ╚══╝╚══╝  ╚═════╝
 * Created by huwenguang on 2019/3/6.
 */
public class PivcException extends RuntimeException {
    private String retcode;
    private String retmsg;
    private String additionmsg;

    public PivcException() {
        retcode     = PivcExceptionConst.UNKNOWN_Retcode;
        retmsg      = PivcExceptionConst.UNKNOWN_Retmsg;
        additionmsg = "";
    }

    public void setRetmsg(String retmsg) {
        this.retmsg = retmsg;
    }

    public String getRetmsg() {
        StringBuilder sb = new StringBuilder();

        try{
            sb.append(retmsg);

            if(! isEmptyString(additionmsg)){
                String newAdditional = String.format("[%s]", String.valueOf(additionmsg));
                sb.append(newAdditional);
            }

//            retmsg = sb.toString();
        }catch (Exception e){}


        return sb.toString();
    }

    @Override
    public String toString() {
        String msg = String.format("PivcException retcode[%s], retmsg[%s]", getRetcode(), getRetmsg());
        return msg;
    }

    protected boolean isEmptyString(String msg){
        if(null == msg || msg.isEmpty()){
            return true;
        }
        return false;
    }

    public String getRetcode() {
        return retcode;
    }

    public void setRetcode(String retcode) {
        this.retcode = retcode;
    }


    public void setAdditionmsg(String additionmsg) {
        this.additionmsg = additionmsg;
    }
}
