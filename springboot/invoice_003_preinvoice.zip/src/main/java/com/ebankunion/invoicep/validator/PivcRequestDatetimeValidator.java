package com.ebankunion.invoicep.validator;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * ██╗  ██╗██╗    ██╗ ██████╗
 * ██║  ██║██║    ██║██╔════╝
 * ███████║██║ █╗ ██║██║  ███╗
 * ██╔══██║██║███╗██║██║   ██║
 * ██║  ██║╚███╔███╔╝╚██████╔╝
 * ╚═╝  ╚═╝ ╚══╝╚══╝  ╚═════╝
 * Created by huwenguang on 2019/3/18.
 */
public class PivcRequestDatetimeValidator implements ConstraintValidator<PivcInvoiceMaterial, String> {
    @Override
    public boolean isValid(String input, ConstraintValidatorContext constraintValidatorContext) {
        return validateDatetime(input);
    }

    @Override
    public void initialize(PivcInvoiceMaterial constraintAnnotation) {

    }

    protected boolean validateDatetime(String input){
        final String fmt = "yyyy-MM-dd HH:mm:ss";

        if(null == input || input.isEmpty()){
            return false;
        }
        if(fmt.length() != input.length()){
            return false;
        }

        return jayceValidate(input, fmt);
    }

    protected boolean jayceValidate(String input, String fmt){
        boolean bValid = false;

        try{
            SimpleDateFormat sdf = new SimpleDateFormat(fmt);
            sdf.setLenient(false);
            sdf.parse(input);

            bValid = true;
        }catch (Exception e){
        }

        return bValid;
    }
}
