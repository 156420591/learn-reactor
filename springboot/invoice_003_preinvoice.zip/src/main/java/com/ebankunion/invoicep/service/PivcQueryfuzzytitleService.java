package com.ebankunion.invoicep.service;

import com.ebankunion.invoicep.backendbean.PivcQueryfuzzytitleEndpointBean;
import com.ebankunion.invoicep.backendbean.PivcWeixinCardEndpointBean;
import com.ebankunion.invoicep.bean.PivcQueryfuzzytitleRequest;
import com.ebankunion.invoicep.bean.PivcWeixinCardRequest;
import com.ebankunion.invoicep.exception.PivcBackendException;
import com.ebankunion.invoicep.exception.PivcException;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import org.springframework.stereotype.Service;

/**
 * ██╗  ██╗██╗    ██╗ ██████╗
 * ██║  ██║██║    ██║██╔════╝
 * ███████║██║ █╗ ██║██║  ███╗
 * ██╔══██║██║███╗██║██║   ██║
 * ██║  ██║╚███╔███╔╝╚██████╔╝
 * ╚═╝  ╚═╝ ╚══╝╚══╝  ╚═════╝
 * Created by huwenguang on 2019/3/12.
 */
@Service
public class PivcQueryfuzzytitleService extends PivcCommonService {

    public JsonObject process(PivcQueryfuzzytitleRequest request) throws PivcException {

        String postdata = fmtRequest2InvoiceSendString(request);

        String url = String.format("%s/weixincard", conf.getIpsInvoicePrefix());
        JsonObject joIvcReturn = utilService.httpPost(url, conf.getPivcHttpTimeout(), postdata);

        if( ! utilService.isRetcodeGood(joIvcReturn)){
            throw new PivcBackendException();
        }

        return joIvcReturn;
    }


    protected String fmtRequest2InvoiceSendString(PivcQueryfuzzytitleRequest request) {
        PivcQueryfuzzytitleEndpointBean issueEnd = initSendObject(request);

        JsonObject joIssueEndpoint = utilService.fromObject2Json(issueEnd);

        return utilService.getStringWithOrderedKey(joIssueEndpoint);
    }


    protected PivcQueryfuzzytitleEndpointBean initSendObject(PivcQueryfuzzytitleRequest request){
        JsonObject joRequest = normalizeRequest(request);

        Gson gson = new GsonBuilder().excludeFieldsWithoutExposeAnnotation().create();
        PivcQueryfuzzytitleEndpointBean issueEnd = gson.fromJson(joRequest, PivcQueryfuzzytitleEndpointBean.class);

        //TODO set msgSrc
        issueEnd.setMsgSrc("");

        return issueEnd;
    }
}
