package com.ebankunion.invoicep.exception;

/**
 * ██╗  ██╗██╗    ██╗ ██████╗
 * ██║  ██║██║    ██║██╔════╝
 * ███████║██║ █╗ ██║██║  ███╗
 * ██╔══██║██║███╗██║██║   ██║
 * ██║  ██║╚███╔███╔╝╚██████╔╝
 * ╚═╝  ╚═╝ ╚══╝╚══╝  ╚═════╝
 * Created by huwenguang on 2019/3/6.
 */
public class PivcArgumentCheckException extends PivcException {
    public PivcArgumentCheckException() {
        super();
        setRetcode(PivcExceptionConst.ARGERROR_Retcode);
        setRetmsg(PivcExceptionConst.ARGERROR_Retmsg);
    }
}
