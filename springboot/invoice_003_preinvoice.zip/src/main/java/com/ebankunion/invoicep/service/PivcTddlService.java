package com.ebankunion.invoicep.service;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import okhttp3.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.Base64;
import java.util.concurrent.TimeUnit;

/**
 * ██╗  ██╗██╗    ██╗ ██████╗
 * ██║  ██║██║    ██║██╔════╝
 * ███████║██║ █╗ ██║██║  ███╗
 * ██╔══██║██║███╗██║██║   ██║
 * ██║  ██║╚███╔███╔╝╚██████╔╝
 * ╚═╝  ╚═╝ ╚══╝╚══╝  ╚═════╝
 * Created by huwenguang on 2019/3/1.
 */
@Service
public class PivcTddlService {
    private final Logger logger = LoggerFactory.getLogger(getClass());


    public JsonArray mongoQuery(String url, String collection, JsonObject conditions, JsonObject retcols){
        int secTimeout    = 30;
        JsonArray jo = mongoQueryTimeout(url, secTimeout, collection, conditions, retcols);

        return jo;
    }


    public JsonArray mongoQueryTimeout(String url, int secTimeout, String collection, JsonObject conditions, JsonObject retcols){
        String postdata    = genMongoQueryPost(collection, conditions, retcols);
        JsonObject joTddl  = httpPost(url, secTimeout, postdata);
        JsonArray joResult = parseMongoQueryResult(joTddl);

        return joResult;
    }


    public boolean mongoInsert(String url, String collection, JsonObject joInsert){
        int secTimeout = 30;
        boolean bok = mongoInsertTimeout(url, secTimeout, collection, joInsert);

        return bok;
    }


    public boolean mongoInsertTimeout(String url, int secTimeout, String collection, JsonObject joInsert){
        String postdata = genMongoInsertPost(collection, joInsert);
        JsonObject joTddl = httpPost(url, secTimeout, postdata);

        boolean bok = isTddlSuccess(joTddl);
        return bok;
    }

    public JsonArray mysqlQuery(String url, String db, String tablename, String usertoken, JsonObject conditions, JsonObject retcols){
        int secTimeout = 30;
        JsonArray joRS = mysqlQueryTimeout(url, secTimeout, db, tablename, usertoken, conditions, retcols);

        return joRS;
    }


    public JsonArray mysqlQueryTimeout(String url, int secTimeout, String db, String tablename, String usertoken, JsonObject conditions, JsonObject retcols){
        String postdata = genMysqlQueryPostdata(db, tablename, usertoken, conditions, retcols);

        JsonObject joTddl = httpPost(url, secTimeout, postdata);

        JsonArray joRS = parseTddlMysqlQuery(joTddl);

        return joRS;
    }

    protected String getStringFromJson(JsonObject joTddl, String key){
        String value = "";

        try{
            if(null != joTddl && joTddl.size() > 0){
                JsonElement jovalue = joTddl.get(key);
                if(jovalue != null){
                    value = jovalue.getAsString();
                }
            }
        }catch (Exception e){}

        return value;
    }

    protected String genMongoInsertPost(String collection, JsonObject joInsert){
        JsonObject jo = new JsonObject();
        jo.addProperty("collection"   , collection);
        jo.add("insertcols", joInsert);

        return jo.toString();
    }

    protected boolean isTddlSuccess(JsonObject joTddl){
        boolean bok = false;
        String retcode = getStringFromJson(joTddl, "retcode");
        if("0000".equalsIgnoreCase(retcode)){
            bok = true;
        }

        return bok;
    }


    protected JsonArray parseMongoQueryResult(JsonObject joTddl){
        JsonArray joResult = new JsonArray();
        if(isTddlSuccess(joTddl)){
            try{
                JsonElement recordsets = joTddl.get("recordsets");
                JsonElement rows = recordsets.getAsJsonObject().get("rows");
                joResult = rows.getAsJsonArray();
            }catch (Exception e){}

        }

        return joResult;
    }

    protected String genMongoQueryPost(String collection, JsonObject conditions, JsonObject retcols){
        JsonObject jo = new JsonObject();
        jo.addProperty("collection"   , collection);
        jo.addProperty("conditioncols", conditions.toString());
        jo.addProperty("returncols"   , retcols.toString());

        return jo.toString();
    }

    protected JsonArray parseTddlMysqlQuery(JsonObject joTddl){
        JsonArray jo = new JsonArray();

        if(joTddl != null && joTddl.size()>0 && isTddlSuccess(joTddl)){
            try{

                JsonElement res = joTddl.get("res");
                jo = res.getAsJsonArray();
            }catch (Exception e){}
        }

        return jo;
    }

    protected JsonObject httpPost(String url, int secTimeout, String postdata){
        JsonObject joRS = new JsonObject();

        try{
            String strHttpReturn  = httpPostGetString(url, secTimeout, postdata);

            JsonObject joBody = parseJsonFromString(strHttpReturn);

            if(joBody.size() > 0){
                joRS = joBody;
            }

        }catch (Exception e){
            logger.error("httpPost exception:", e);
        }

        return joRS;
    }


    protected String httpPostGetString(String url, final int secTimeout, final String postdata){
        String strHttpReturn = "";


        OkHttpClient client = new OkHttpClient()
                .newBuilder()
                .connectTimeout(secTimeout, TimeUnit.SECONDS)
                .readTimeout(secTimeout, TimeUnit.SECONDS)
                .build()
                ;

        final MediaType mediaType = MediaType.get("application/json; charset=utf-8");
        RequestBody body = RequestBody.create(mediaType, postdata);
        Request request = new Request.Builder().url(url).post(body).build();

        String msgJayce = String.format("发送请求 url[%s], timeout[%s], 发送数据[%s]", String.valueOf(url), String.valueOf(secTimeout), String.valueOf(postdata) );
        mylog(msgJayce);
        logger.debug(msgJayce);

        try{
            Response response = client.newCall(request).execute();
            strHttpReturn  = response.body().string();
            int statusCode = response.code();

            msgJayce = String.format("接收响应 url[%s], 响应码[%s], 响应数据[%s]", String.valueOf(url), String.valueOf(statusCode),
                    String.valueOf(strHttpReturn));
            mylog(msgJayce);
            logger.debug(msgJayce);

        }catch (IOException e){
            logger.error("httpPostGetString exception:", e);
        }

        return strHttpReturn;
    }



    protected void mylog(Object msg){
        String newmsg = String.format("enc: %s", getBase64(msg) );
        logger.info(newmsg);
    }

    protected JsonObject parseJsonFromString(final String strJson){
        JsonObject jo = new JsonObject();
        try{
            jo = new Gson().fromJson(strJson, JsonObject.class);
        }catch (Exception e){}

        return jo;
    }

    protected String getBase64(Object msg){
        String msgDavid = String.valueOf(msg);
        byte[] encodedBytes = Base64.getEncoder().encode(msgDavid.getBytes());
        return new String(encodedBytes);
    }

    protected String genMysqlQueryPostdata(String db, String tablename, String usertoken, JsonObject conditions, JsonObject retcols){
        JsonObject jo = new JsonObject();
        jo.addProperty("database"      , db);
        jo.addProperty("collection"    , tablename);
        jo.addProperty("usertoken"     , usertoken);
        jo.addProperty("conditioncols" , conditions.toString());
        jo.addProperty("returncols"    , retcols.toString());

        return jo.toString();
    }
}
