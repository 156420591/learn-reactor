package com.ebankunion.invoicep.validator;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

/**
 * ██╗  ██╗██╗    ██╗ ██████╗
 * ██║  ██║██║    ██║██╔════╝
 * ███████║██║ █╗ ██║██║  ███╗
 * ██╔══██║██║███╗██║██║   ██║
 * ██║  ██║╚███╔███╔╝╚██████╔╝
 * ╚═╝  ╚═╝ ╚══╝╚══╝  ╚═════╝
 * Created by huwenguang on 2019/3/6.
 */
public class PivcInvoiceMaterialValidator implements ConstraintValidator<PivcInvoiceMaterial, String> {
    @Override
    public boolean isValid(String input, ConstraintValidatorContext constraintValidatorContext) {
        return checkInvoiceMaterial(input);
    }

    @Override
    public void initialize(PivcInvoiceMaterial constraintAnnotation) {

    }
    protected boolean checkInvoiceMaterial(String input){
        boolean bValid = false;
        if("PAPER".equals(input) || "ELECTRONIC".equals(input)){
            bValid = true;
        }

        return bValid;
    }
}
