package com.ebankunion.invoicep.service;

import com.ebankunion.invoicep.exception.PivcEsConflictException;
import com.ebankunion.invoicep.exception.PivcEsException;
import com.ebankunion.invoicep.exception.PivcException;
import com.google.gson.JsonObject;
import org.elasticsearch.ElasticsearchException;
import org.elasticsearch.action.DocWriteRequest;
import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.action.index.IndexResponse;
import org.elasticsearch.action.support.WriteRequest;
import org.elasticsearch.action.update.UpdateRequest;
import org.elasticsearch.action.update.UpdateResponse;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.common.xcontent.XContentType;
import org.elasticsearch.rest.RestStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;

import java.io.IOException;

/**
 * ██╗  ██╗██╗    ██╗ ██████╗
 * ██║  ██║██║    ██║██╔════╝
 * ███████║██║ █╗ ██║██║  ███╗
 * ██╔══██║██║███╗██║██║   ██║
 * ██║  ██║╚███╔███╔╝╚██████╔╝
 * ╚═╝  ╚═╝ ╚══╝╚══╝  ╚═════╝
 * Created by huwenguang on 2019/3/19.
 */
public class PivcEsService {
    private final RestHighLevelClient restHighLevelClient;
    private final String              pivcESIndex;
    private final String              pivcESType;


    private final Logger logger = LoggerFactory.getLogger(getClass());

    @Autowired
    public PivcEsService(@Qualifier("pivcHighLevelRestClient")      RestHighLevelClient restHighLevelClient,
                         @Value("${invoicep.pivcESIndex:invoicep}") String pivcESIndex,
                         @Value("${invoicep.pivcESType:invoicep}")    String pivcESType
                        ) {
        this.restHighLevelClient = restHighLevelClient;
        this.pivcESIndex         = pivcESIndex;
        this.pivcESType          = pivcESType;
    }

    public void updateEs(final String _id, final String strJsonDoc) throws PivcException{
        UpdateRequest request = new UpdateRequest(pivcESIndex, pivcESType, _id)
                .doc(strJsonDoc, XContentType.JSON)
                //.version(1)
                ;

        try{
            request.setRefreshPolicy(WriteRequest.RefreshPolicy.IMMEDIATE);
            UpdateResponse response = restHighLevelClient.update(request, RequestOptions.DEFAULT);
            logger.info("更新成功{}", response);
        }catch (Exception e){
            logger.info("invoicep更新index {}, type {}, _id {}失败", pivcESIndex, pivcESType, _id);
            logger.error("更新失败", e);
            throw new PivcEsException();
        }
    }

    public void updateEs(final String _id, JsonObject joDoc) throws PivcException{
        updateEs(_id, joDoc.toString());
    }

    public void insertEs(final String _id, final String strJsonDoc) throws PivcException {
        try{
            IndexRequest request = new IndexRequest(pivcESIndex, pivcESType, _id)
                    .source(strJsonDoc, XContentType.JSON)
                    .opType(DocWriteRequest.OpType.CREATE);

            request.setRefreshPolicy(WriteRequest.RefreshPolicy.IMMEDIATE);
            IndexResponse response = restHighLevelClient.index(request, RequestOptions.DEFAULT);
            logger.info("插入成功{}", response);
        }catch (ElasticsearchException e){
            if(e.status() == RestStatus.CONFLICT){
                String msg = String.format("invoicep插入index[%s], type[%s], _id[%s]冲突，rethrow PivcEsConflictException", pivcESIndex, pivcESType, _id);
                logger.info(msg);
                logger.error("RestStatus.CONFLICT", e);
                throw new PivcEsConflictException();
            }

            logEsException(_id, e);
            throw new PivcEsException();
        }catch (IOException e){

            logEsException(_id, e);
            throw new PivcEsException();
        }
    }

    public void insertEs(final String _id, JsonObject joDoc) throws PivcException{
        insertEs(_id, joDoc.toString());
    }



    protected void logEsException(String _id, Throwable e) {
        String msg = String.format("invoicep插入index[%s], type[%s], _id[%s]失败", pivcESIndex, pivcESType, _id);
        logger.info(msg);
        logger.error("插入失败", e);
    }

}
