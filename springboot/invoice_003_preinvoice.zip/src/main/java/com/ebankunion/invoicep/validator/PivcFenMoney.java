package com.ebankunion.invoicep.validator;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

/**
 * ██╗  ██╗██╗    ██╗ ██████╗
 * ██║  ██║██║    ██║██╔════╝
 * ███████║██║ █╗ ██║██║  ███╗
 * ██╔══██║██║███╗██║██║   ██║
 * ██║  ██║╚███╔███╔╝╚██████╔╝
 * ╚═╝  ╚═╝ ╚══╝╚══╝  ╚═════╝
 * Created by huwenguang on 2019/3/6.
 */


@Target({FIELD})
@Retention(RUNTIME)
@Constraint(validatedBy = PivcFenMoneyValidator.class)
@Documented
public @interface PivcFenMoney {

    String message() default "money format is 12 digital number fen";

    String format() default "";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};
}
