package com.ebankunion.invoicep.service;

import com.ebankunion.invoicep.exception.*;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigInteger;

/**
 * ██╗  ██╗██╗    ██╗ ██████╗
 * ██║  ██║██║    ██║██╔════╝
 * ███████║██║ █╗ ██║██║  ███╗
 * ██╔══██║██║███╗██║██║   ██║
 * ██║  ██║╚███╔███╔╝╚██████╔╝
 * ╚═╝  ╚═╝ ╚══╝╚══╝  ╚═════╝
 * Created by huwenguang on 2019/3/7.
 */
@Service
public class PivcMercService {
    @Autowired
    private PivcTddlService tddl;

    @Autowired
    private PivcUtilService utilService;

    private JsonObject joDBResultset = new JsonObject();

    public JsonObject getJoDBResultset() {
        return joDBResultset;
    }

    public void checkMercIssueConf(JsonObject joOrgMsg, String urlMysql, String dbPivcMysql, String tablename, String usertoken) throws PivcException{

        JsonObject dbResultset = checkMercCommonConf(joOrgMsg, urlMysql, dbPivcMysql, tablename, usertoken);

        checkMercSingleMaxAmount(joOrgMsg, dbResultset);
    }

    public JsonObject checkMercCommonConf(JsonObject joOrgMsg, String urlMysql, String dbPivcMysql, String tablename, String usertoken) {
        String mercno = utilService.getStringFromJson(joOrgMsg, "msgSrc");

        JsonObject retcols = new JsonObject();

        fmtMysqlRetcols(retcols);

        JsonObject dbResultset = getMercConf(tddl, mercno, urlMysql, dbPivcMysql, tablename, usertoken, retcols);

        checkMercExist(dbResultset);

        joDBResultset = dbResultset.deepCopy();

        checkMercOpen(dbResultset);

        String msgkey = dbGetMessageKey(dbResultset);
        checkMsgSign(joOrgMsg, msgkey);

        return dbResultset;
    }

    public JsonObject normalizeResultAndDoSign(JsonObject joIvcReturn) throws PivcException{
        if(utilService.isJsonObjectEmpty(joDBResultset)){
            throw new PivcMercNotExistException();
        }

        JsonObject joNewResult = utilService.excludeNullEmptyAndSign(joIvcReturn);
        String msgkey = dbGetMessageKey(joDBResultset);

        String resultSign = utilService.doUmsSign(joNewResult, msgkey);
        joNewResult.addProperty("sign", resultSign);

        return joNewResult;
    }


    protected String dbGetMessageKey(JsonObject dbResultset){
        String msgkey = utilService.getStringFromJson(dbResultset, "messagekey");

        return msgkey;
    }

    protected void checkMercSingleMaxAmount(JsonObject joOrgMsg, JsonObject rs) {
        String amount      = utilService.getStringFromJson(joOrgMsg, "amount");
        String dbMaxAmount = utilService.getStringFromJson(rs, "singleamountmax");
        checkSingleMaxAmount(amount, dbMaxAmount);
    }

    protected void checkSingleMaxAmount(String amount, String dbMaxAmount) throws PivcException{
        if( hasDBAmountConfigured(dbMaxAmount) ){
            BigInteger iAmount  = utilService.getIntFromString(amount);
            BigInteger iDBAmount= utilService.getIntFromString(dbMaxAmount);

            if(iAmount.compareTo(iDBAmount) > 0){
                PivcLogicCheckException ex = new PivcLogicCheckException();
                String moreinfo = String.format("当前金额[%s]超过允许最大金额[%s]", String.valueOf(amount), String.valueOf(dbMaxAmount) );
                ex.setAdditionmsg(moreinfo);

                throw ex;
            }
        }
    }

    protected void checkMsgSign(JsonObject joOrgMsg, String signKey) throws PivcException{
        String signCompute = utilService.doUmsSign(joOrgMsg, signKey);

        String signGot = utilService.getStringFromJson(joOrgMsg, "sign");
        
        if(!signGot.equalsIgnoreCase(signCompute)){
            throw new PivcSignCheckException();
        }

    }


    protected void checkMercExist(JsonObject jo) throws PivcException{
        if(utilService.isJsonObjectEmpty(jo)){
            throw new PivcMercNotExistException();
        }
    }

    protected void checkMercOpen(JsonObject jo) throws PivcException{
        String isOpen = utilService.getStringFromJson(jo, "isopen");
        if(! "1".equals(isOpen)){
            throw new PivcMercClosedException();
        }
    }

    protected boolean hasDBAmountConfigured(String dbAmount){
        boolean bConfigured = true;

        if(utilService.isEmptyString(dbAmount)){
            bConfigured = false;
        }
        if("0".equals(dbAmount)){
            bConfigured = false;
        }
        if(! StringUtils.isNumeric(dbAmount)){
            bConfigured = false;
        }

        return bConfigured;
    }

    protected void fmtMysqlRetcols(JsonObject jo){
        //TODO 定义mysql的返回字段
        jo.addProperty("merckey"           , "1");
        jo.addProperty("description"       , "1");
        jo.addProperty("mercno"            , "1");
        jo.addProperty("isopen"            , "1");
        jo.addProperty("singleamountmax"   , "1");
        jo.addProperty("messagekey"        , "1");

    }

    protected JsonObject getMercConf(PivcTddlService tddl, String mercno, String url, String db, String tablename, String usertoken, JsonObject retcols){
        JsonObject joResultSet = new JsonObject();

        JsonObject conditions = new JsonObject();
        conditions.addProperty("merckey", mercno);

        JsonArray arrResult = tddl.mysqlQuery(url, db, tablename, usertoken, conditions, retcols);
        if(arrResult.size() > 0){
            joResultSet = arrResult.get(0).getAsJsonObject();
        }

        return joResultSet;
    }
}
