package com.ebankunion.invoicep.service;

import com.ebankunion.invoicep.backendbean.PivcIssueEndpointBean;
import com.ebankunion.invoicep.bean.PivcConf;
import com.ebankunion.invoicep.bean.PivcIssueRequest;
import com.google.gson.JsonObject;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * ██╗  ██╗██╗    ██╗ ██████╗
 * ██║  ██║██║    ██║██╔════╝
 * ███████║██║ █╗ ██║██║  ███╗
 * ██╔══██║██║███╗██║██║   ██║
 * ██║  ██║╚███╔███╔╝╚██████╔╝
 * ╚═╝  ╚═╝ ╚══╝╚══╝  ╚═════╝
 * Created by huwenguang on 2019/3/8.
 */
@Service
public class PivcCommonService {

    @Autowired
    protected PivcUtilService utilService;

    @Autowired
    protected PivcConf conf;


    public void mappingErrorcode(JsonObject joIvcReturn){
        String orgRetcode = utilService.getStringFromJson(joIvcReturn, "retcode");
        String orgRetmsg  = utilService.getStringFromJson(joIvcReturn, "retmsg");

        //TODO log original retcode, retmsg

        String urlOfIpsErrorcode = conf.getPivcIpsErrorcodeUrl();
        int timeout              = conf.getPivcHttpTimeout();
        send2IpsAndMap(urlOfIpsErrorcode, timeout, joIvcReturn);
    }


    public JsonObject normalizeRequest(Object request){
        JsonObject joRequest = utilService.fromObject2Json(request);

        joRequest = utilService.excludeNullEmptyAndSign(joRequest);

        return joRequest;
    }


    protected void send2IpsAndMap(String url, int timeout, JsonObject joIvcReturn){
        String postdata          = fmtPostdata(joIvcReturn);
        JsonObject joIps = utilService.httpPost(url, timeout, postdata);

        if(utilService.isSuccessfulRetcode(joIps)){
            //TODO add more log
            String retcodeMapping = utilService.getStringFromJson(joIps, "errcode");
            String retmsgMapping  = utilService.getStringFromJson(joIps, "errmsg");

            joIvcReturn.addProperty("retcode", retcodeMapping);
            joIvcReturn.addProperty("retmsg" , retmsgMapping);
        }
    }

    protected String fmtPostdata(JsonObject joIvcReturn){
        JsonObject jo = new JsonObject();
        String intype = conf.getPivcIpsErrorcodeIntype();
        String ecode  = utilService.getStringFromJson(joIvcReturn, "retcode");
        jo.addProperty("frommodule"   , "invoicep");
        jo.addProperty("intype"       , intype);
        jo.addProperty("errorcode"    , ecode);

        String postdata = utilService.getStringWithOrderedKey(jo);

        return postdata;
    }
}
