package com.ebankunion.invoicep.backendbean;

import com.google.gson.annotations.Expose;
import lombok.Data;
import org.springframework.stereotype.Component;

/**
 * ██╗  ██╗██╗    ██╗ ██████╗
 * ██║  ██║██║    ██║██╔════╝
 * ███████║██║ █╗ ██║██║  ███╗
 * ██╔══██║██║███╗██║██║   ██║
 * ██║  ██║╚███╔███╔╝╚██████╔╝
 * ╚═╝  ╚═╝ ╚══╝╚══╝  ╚═════╝
 * Created by huwenguang on 2019/3/8.
 */
@Component @Data
public class PivcIssueEndpointBean {
    @Expose(serialize = true, deserialize = true)
    private String msgId;

    @Expose(serialize = true, deserialize = true)
    private String msgSrc;

    @Expose(serialize = true, deserialize = true)
    private String requestTimestamp;

    @Expose(serialize = true, deserialize = true)
    private String srcReserve;

    @Expose(serialize = true, deserialize = true)
    private String invoiceMaterial;

    @Expose(serialize = true, deserialize = true)
    private String invoiceType;

    @Expose(serialize = true, deserialize = true)
    private String merchantId;

    @Expose(serialize = true, deserialize = true)
    private String terminalId;

    @Expose(serialize = true, deserialize = true)
    private String merOrderDate;

    @Expose(serialize = true, deserialize = true)
    private String merOrderId;

    @Expose(serialize = true, deserialize = true)
    private String buyerName;

    @Expose(serialize = true, deserialize = true)
    private String buyerTaxCode;

    @Expose(serialize = true, deserialize = true)
    private String buyerAddress;

    @Expose(serialize = true, deserialize = true)
    private String buyerTelephone;

    @Expose(serialize = true, deserialize = true)
    private String buyerBank;

    @Expose(serialize = true, deserialize = true)
    private String buyerAccount;

    @Expose(serialize = true, deserialize = true)
    private String amount;

    @Expose(serialize = true, deserialize = true)
    private String deductionAmount;

    @Expose(serialize = true, deserialize = true)
    private String goodsDetail;

    @Expose(serialize = true, deserialize = true)
    private String remark;

    @Expose(serialize = true, deserialize = true)
    private String notifyMobileNo;

    @Expose(serialize = true, deserialize = true)
    private String notifyEMail;

    @Expose(serialize = true, deserialize = true)
    private String notifyUrl;

    @Expose(serialize = true, deserialize = true)
    private String merWxAppId;

    @Expose(serialize = true, deserialize = true)
    private String merWxOrderId;

    @Expose(serialize = true, deserialize = true)
    private String storeId;
}
