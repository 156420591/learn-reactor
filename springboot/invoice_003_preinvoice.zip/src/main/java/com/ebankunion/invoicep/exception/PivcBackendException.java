package com.ebankunion.invoicep.exception;

/**
 * ██╗  ██╗██╗    ██╗ ██████╗
 * ██║  ██║██║    ██║██╔════╝
 * ███████║██║ █╗ ██║██║  ███╗
 * ██╔══██║██║███╗██║██║   ██║
 * ██║  ██║╚███╔███╔╝╚██████╔╝
 * ╚═╝  ╚═╝ ╚══╝╚══╝  ╚═════╝
 * Created by huwenguang on 2019/3/8.
 */
public class PivcBackendException extends PivcException {
    public PivcBackendException() {
        super();
        setRetcode(PivcExceptionConst.BackendFailure_Retcode);
        setRetmsg(PivcExceptionConst.BackendFailure_Retmsg);
    }
}
