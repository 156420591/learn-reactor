package com.ebankunion.invoicep.exception;

/**
 * ██╗  ██╗██╗    ██╗ ██████╗
 * ██║  ██║██║    ██║██╔════╝
 * ███████║██║ █╗ ██║██║  ███╗
 * ██╔══██║██║███╗██║██║   ██║
 * ██║  ██║╚███╔███╔╝╚██████╔╝
 * ╚═╝  ╚═╝ ╚══╝╚══╝  ╚═════╝
 * Created by huwenguang on 2019/3/7.
 */
public class PivcSignCheckException extends PivcException {
    public PivcSignCheckException() {
        super();
        setRetcode(PivcExceptionConst.SignFailure_Retcode);
        setRetmsg(PivcExceptionConst.SignFailure_Retmsg);
    }
}
