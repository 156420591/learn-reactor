package com.ebankunion.invoicep.backendbean;

import com.google.gson.annotations.Expose;
import lombok.Data;
import org.springframework.stereotype.Component;

/**
 * ██╗  ██╗██╗    ██╗ ██████╗
 * ██║  ██║██║    ██║██╔════╝
 * ███████║██║ █╗ ██║██║  ███╗
 * ██╔══██║██║███╗██║██║   ██║
 * ██║  ██║╚███╔███╔╝╚██████╔╝
 * ╚═╝  ╚═╝ ╚══╝╚══╝  ╚═════╝
 * Created by huwenguang on 2019/3/12.
 */
@Data @Component
public class PivcWeixinCardEndpointBean {
    @Expose(serialize = true, deserialize = true)
    private String msgId;

    @Expose(serialize = true, deserialize = true)
    private String msgSrc;

    @Expose(serialize = true, deserialize = true)
    private String requestTimestamp;

    @Expose(serialize = true, deserialize = true)
    private String srcReserve;

    @Expose(serialize = true, deserialize = true)
    private String merchantId ;

    @Expose(serialize = true, deserialize = true)
    private String terminalId ;

    @Expose(serialize = true, deserialize = true)
    private String merOrderId;

    @Expose(serialize = true, deserialize = true)
    private String merOrderDate;

    @Expose(serialize = true, deserialize = true)
    private String source;

    @Expose(serialize = true, deserialize = true)
    private String invoiceNo;

    @Expose(serialize = true, deserialize = true)
    private String invoiceCode;
}
