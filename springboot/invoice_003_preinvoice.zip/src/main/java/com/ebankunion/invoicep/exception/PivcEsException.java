package com.ebankunion.invoicep.exception;

/**
 * ██╗  ██╗██╗    ██╗ ██████╗
 * ██║  ██║██║    ██║██╔════╝
 * ███████║██║ █╗ ██║██║  ███╗
 * ██╔══██║██║███╗██║██║   ██║
 * ██║  ██║╚███╔███╔╝╚██████╔╝
 * ╚═╝  ╚═╝ ╚══╝╚══╝  ╚═════╝
 * Created by huwenguang on 2019/3/19.
 */
public class PivcEsException extends PivcException {
    public PivcEsException() {
        super();
        setRetcode(PivcExceptionConst.EsFailure_Retcode);
        setRetmsg(PivcExceptionConst.EsFailure_Retmsg);
    }
}
