package com.ebankunion.invoicep.exception;

/**
 * ██╗  ██╗██╗    ██╗ ██████╗
 * ██║  ██║██║    ██║██╔════╝
 * ███████║██║ █╗ ██║██║  ███╗
 * ██╔══██║██║███╗██║██║   ██║
 * ██║  ██║╚███╔███╔╝╚██████╔╝
 * ╚═╝  ╚═╝ ╚══╝╚══╝  ╚═════╝
 * Created by huwenguang on 2019/3/7.
 */
public class PivcMercNotExistException extends PivcException {
    public PivcMercNotExistException() {
        super();
        setRetcode(PivcExceptionConst.MERCNOTEXIST_Retcode);
        setRetmsg(PivcExceptionConst.MERCNOTEXIST_Retmsg);
    }
}
