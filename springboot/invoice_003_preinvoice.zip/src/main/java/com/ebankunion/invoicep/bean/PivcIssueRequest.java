package com.ebankunion.invoicep.bean;

import com.ebankunion.invoicep.validator.PivcDate;
import com.ebankunion.invoicep.validator.PivcFenMoney;
import com.ebankunion.invoicep.validator.PivcInvoiceMaterial;
import com.ebankunion.invoicep.validator.PivcRequestDatetime;
import lombok.Data;
import org.springframework.stereotype.Component;

import javax.validation.constraints.NotEmpty;

/**
 * ██╗  ██╗██╗    ██╗ ██████╗
 * ██║  ██║██║    ██║██╔════╝
 * ███████║██║ █╗ ██║██║  ███╗
 * ██╔══██║██║███╗██║██║   ██║
 * ██║  ██║╚███╔███╔╝╚██████╔╝
 * ╚═╝  ╚═╝ ╚══╝╚══╝  ╚═════╝
 * Created by huwenguang on 2019/3/5.
 */

@Data @Component
public class PivcIssueRequest {
    @NotEmpty private String msgId;
    @NotEmpty private String msgSrc;

    //yyyy-MM-dd HH:mm:ss
    @NotEmpty @PivcRequestDatetime
    private String requestTimestamp;

    private String srcReserve;

    @NotEmpty @PivcInvoiceMaterial
    private String invoiceMaterial;

    @NotEmpty
    private String invoiceType;

    //格式 yyyyMMdd，建议使用原交易支付日期
    @NotEmpty @PivcDate
    private String merOrderDate;

    @NotEmpty private String merOrderId;

    @NotEmpty private String buyerName;

    private String buyerTaxCode;
    private String buyerAddress;
    private String buyerTelephone;
    private String buyerBank;
    private String buyerAccount;

    @PivcFenMoney @NotEmpty
    private String amount;

    @PivcFenMoney
    private String deductionAmount;

    private String goodsDetail;
    private String remark;
    private String notifyMobileNo;
    private String notifyEMail;
    private String notifyUrl;
    private String merWxAppId;
    private String merWxOrderId;

    private String storeId;

    @NotEmpty private String sign;
}
