package com.ebankunion.invoicep.backendbean;

import com.google.gson.annotations.Expose;
import lombok.Data;
import org.springframework.stereotype.Component;

/**
 * ██╗  ██╗██╗    ██╗ ██████╗
 * ██║  ██║██║    ██║██╔════╝
 * ███████║██║ █╗ ██║██║  ███╗
 * ██╔══██║██║███╗██║██║   ██║
 * ██║  ██║╚███╔███╔╝╚██████╔╝
 * ╚═╝  ╚═╝ ╚══╝╚══╝  ╚═════╝
 * Created by huwenguang on 2019/3/12.
 */
@Data @Component
public class PivcQueryfuzzytitleEndpointBean {
    @Expose(serialize = true, deserialize = true)
    private String msgId;

    @Expose(serialize = true, deserialize = true)
    private String msgSrc;

    @Expose(serialize = true, deserialize = true)
    private String requestTimestamp;

    @Expose(serialize = true, deserialize = true)
    private String srcReserve;

    @Expose(serialize = true, deserialize = true)
    private String name;

    @Expose(serialize = true, deserialize = true)
    private String taxCode;
}
