package com.ebankunion.invoicep.exception;

/**
 * ██╗  ██╗██╗    ██╗ ██████╗
 * ██║  ██║██║    ██║██╔════╝
 * ███████║██║ █╗ ██║██║  ███╗
 * ██╔══██║██║███╗██║██║   ██║
 * ██║  ██║╚███╔███╔╝╚██████╔╝
 * ╚═╝  ╚═╝ ╚══╝╚══╝  ╚═════╝
 * Created by huwenguang on 2019/3/19.
 */
public class PivcEsConflictException extends PivcException{
    public PivcEsConflictException() {
        super();
        setRetcode(PivcExceptionConst.EsConflict_Retcode);
        setRetmsg(PivcExceptionConst.EsConflict_Retmsg);
    }
}
