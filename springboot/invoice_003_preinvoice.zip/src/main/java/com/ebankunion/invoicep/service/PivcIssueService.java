package com.ebankunion.invoicep.service;

import com.ebankunion.invoicep.backendbean.PivcIssueEndpointBean;
import com.ebankunion.invoicep.bean.PivcEsFlow;
import com.ebankunion.invoicep.bean.PivcIssueRequest;
import com.ebankunion.invoicep.exception.PivcBackendException;
import com.ebankunion.invoicep.exception.PivcException;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * ██╗  ██╗██╗    ██╗ ██████╗
 * ██║  ██║██║    ██║██╔════╝
 * ███████║██║ █╗ ██║██║  ███╗
 * ██╔══██║██║███╗██║██║   ██║
 * ██║  ██║╚███╔███╔╝╚██████╔╝
 * ╚═╝  ╚═╝ ╚══╝╚══╝  ╚═════╝
 * Created by huwenguang on 2019/3/8.
 */
@Service
public class PivcIssueService extends PivcCommonService {

    @Autowired
    private PivcEsService esService;

    public JsonObject process(PivcIssueRequest request) throws PivcException{

        String postdata = fmtRequest2InvoiceSendString(request);

        String url = String.format("%s/issue", conf.getIpsInvoicePrefix());
        JsonObject joIvcReturn = utilService.httpPost(url, conf.getPivcHttpTimeout(), postdata);

        //TODO insert es
        PivcEsFlow flow = new PivcEsFlow();
        setEsFlowFromRequestAndResponse(flow, request, joIvcReturn);


        if( ! utilService.isRetcodeGood(joIvcReturn)){
            throw new PivcBackendException();
        }

        return joIvcReturn;
    }

    protected void setEsFlowFromRequestAndResponse(PivcEsFlow flow, PivcIssueRequest request, JsonObject joIvcReturn){
        setEsFlowFromRequest(flow, request);
        setEsFlowFromResponse(flow, joIvcReturn);
    }

    protected void setEsFlowFromResponse2(PivcEsFlow flow, JsonObject joIvcReturn){
        String retcode = utilService.getStringFromJsonDefault(joIvcReturn, "retcode", "8999");
        if(utilService.isRetcodeGood(joIvcReturn)){

            for(String key : joIvcReturn.keySet()){
                String value = utilService.getStringFromJson(joIvcReturn, key);

                String methodName = String.format("set%s", utilService.capitalize(key) );

                java.lang.reflect.Method mymethod;
                try{
                    mymethod = flow.getClass().getMethod(methodName, String.class);
                    mymethod.invoke(flow, value);
                }catch (Exception e){
                }
            }

        }

        flow.setRetcode(retcode);
    }

    protected void setEsFlowFromResponse(PivcEsFlow flow, JsonObject joIvcReturn){
        String retcode = utilService.getStringFromJsonDefault(joIvcReturn, "retcode", "8999");
        flow.setRetcode(retcode);
        if(utilService.isRetcodeGood(joIvcReturn)){
            flow.setRetmsg(utilService.getStringFromJson(joIvcReturn, "retmsg"));
            flow.setResponseTimestamp(utilService.getStringFromJson(joIvcReturn, "responseTimestamp"));
            flow.setInvoiceNo(utilService.getStringFromJson(joIvcReturn, "invoiceNo"));
            flow.setInvoiceCode(utilService.getStringFromJson(joIvcReturn, "invoiceCode"));
            flow.setCheckCode(utilService.getStringFromJson(joIvcReturn, "checkCode"));
            flow.setCipherCode(utilService.getStringFromJson(joIvcReturn, "cipherCode"));
            flow.setIssueDate(utilService.getStringFromJson(joIvcReturn, "issueDate"));
            flow.setDeviceNo(utilService.getStringFromJson(joIvcReturn, "deviceNo"));
            flow.setQrCodeId(utilService.getStringFromJson(joIvcReturn, "qrCodeId"));
            flow.setStoreName(utilService.getStringFromJson(joIvcReturn, "storeName"));
            flow.setMerchantName(utilService.getStringFromJson(joIvcReturn, "merchantName"));
            flow.setSellerName(utilService.getStringFromJson(joIvcReturn, "sellerName"));
            flow.setSellerTaxCode(utilService.getStringFromJson(joIvcReturn, "sellerTaxCode"));
            flow.setSellerAddress(utilService.getStringFromJson(joIvcReturn, "sellerAddress"));
            flow.setSellerTelephone(utilService.getStringFromJson(joIvcReturn, "sellerTelephone"));
            flow.setSellerBank(utilService.getStringFromJson(joIvcReturn, "sellerBank"));
            flow.setSellerAccount(utilService.getStringFromJson(joIvcReturn, "sellerAccount"));
            flow.setPayee(utilService.getStringFromJson(joIvcReturn, "payee"));
            flow.setChecker(utilService.getStringFromJson(joIvcReturn, "checker"));
            flow.setDrawer(utilService.getStringFromJson(joIvcReturn, "drawer"));
            flow.setTaxMethod(utilService.getStringFromJson(joIvcReturn, "taxMethod"));
            flow.setTotalPriceIncludingTax(utilService.getStringFromJson(joIvcReturn, "totalPriceIncludingTax"));
            flow.setTotalTax(utilService.getStringFromJson(joIvcReturn, "totalTax"));
            flow.setTotalPrice(utilService.getStringFromJson(joIvcReturn, "totalPrice"));
            flow.setNotifyMerEmail(utilService.getStringFromJson(joIvcReturn, "notifyMerEmail"));
            flow.setQrCode(utilService.getStringFromJson(joIvcReturn, "qrCode"));
            flow.setPdfUrl(utilService.getStringFromJson(joIvcReturn, "pdfUrl"));
            flow.setPdfPreviewUrl(utilService.getStringFromJson(joIvcReturn, "pdfPreviewUrl"));
        }
    }

    protected void setEsFlowFromRequest(PivcEsFlow flow, PivcIssueRequest request){
        //TODO set es flow完善es flow

        flow.setMsgId(request.getMsgId());
        flow.setRequestTimestamp(request.getRequestTimestamp());
        flow.setSrcReserve(request.getSrcReserve());
        flow.setInvoiceMaterial(request.getInvoiceMaterial());
        flow.setInvoiceType(request.getInvoiceType());
        flow.setMerOrderDate(request.getMerOrderDate());
        flow.setMerOrderId(request.getMerOrderId());
        flow.setBuyerName(request.getBuyerName());
        flow.setBuyerTaxCode(request.getBuyerTaxCode());
        flow.setBuyerAddress(request.getBuyerAddress());
        flow.setBuyerTelephone(request.getBuyerTelephone());
        flow.setBuyerBank(request.getBuyerBank());
        flow.setBuyerAccount(request.getBuyerAccount());
        flow.setAmount(request.getAmount());
        flow.setDeductionAmount(request.getDeductionAmount());
        flow.setGoodsDetail(request.getGoodsDetail());
        flow.setRemark(request.getRemark());
        flow.setNotifyMobileNo(request.getNotifyMobileNo());
        flow.setNotifyEMail(request.getNotifyEMail());
        flow.setNotifyUrl(request.getNotifyUrl());
        flow.setStoreId(request.getStoreId());
        flow.setStatus("ISSUING");
    }

    protected void setEsFlowFromRequest2(PivcEsFlow flow, PivcIssueRequest request){
        JsonObject joRequest = utilService.fromObject2Json(request);

        for(String key : joRequest.keySet()){
            String value = utilService.getStringFromJson(joRequest, key);

            String methodName = String.format("set%s", utilService.capitalize(key) );

            java.lang.reflect.Method mymethod;
            try{
                mymethod = flow.getClass().getMethod(methodName, String.class);
                mymethod.invoke(flow, value);
            }catch (Exception e){
            }
        }
        flow.setStatus("ISSUING");
    }


    protected String fmtRequest2InvoiceSendString(PivcIssueRequest request) {
        PivcIssueEndpointBean issueEnd = initSendObject(request);

        JsonObject joIssueEndpoint = utilService.fromObject2Json(issueEnd);

        return utilService.getStringWithOrderedKey(joIssueEndpoint);
    }

    protected PivcIssueEndpointBean initSendObject(PivcIssueRequest request){
        JsonObject joRequest = normalizeRequest(request);

        Gson gson = new GsonBuilder().excludeFieldsWithoutExposeAnnotation().create();
        PivcIssueEndpointBean issueEnd = gson.fromJson(joRequest, PivcIssueEndpointBean.class);

        //TODO set terminal and merchant id to invoice endpoint
        issueEnd.setMerchantId("");
        issueEnd.setTerminalId("");
        issueEnd.setMsgSrc("");

        return issueEnd;
    }



}






