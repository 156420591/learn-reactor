package com.ebankunion.invoicep.validator;

import org.apache.commons.lang3.StringUtils;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import java.math.BigInteger;

/**
 * ██╗  ██╗██╗    ██╗ ██████╗
 * ██║  ██║██║    ██║██╔════╝
 * ███████║██║ █╗ ██║██║  ███╗
 * ██╔══██║██║███╗██║██║   ██║
 * ██║  ██║╚███╔███╔╝╚██████╔╝
 * ╚═╝  ╚═╝ ╚══╝╚══╝  ╚═════╝
 * Created by huwenguang on 2019/3/6.
 */
public class PivcFenMoneyValidator implements ConstraintValidator<PivcFenMoney, String> {
    @Override
    public boolean isValid(String input, ConstraintValidatorContext constraintValidatorContext) {
        return validateFenMoney(input);
    }

    @Override
    public void initialize(PivcFenMoney constraintAnnotation) {

    }

    protected boolean validateFenMoney(String input){
        if(input == null || input.isEmpty()){
            return true;
        }

        boolean bValid = false;

        if(input.length() == 12){
            try{
                bValid = StringUtils.isNumeric(input);
            }catch (Exception e){ }
        }

        return bValid;
    }
}
