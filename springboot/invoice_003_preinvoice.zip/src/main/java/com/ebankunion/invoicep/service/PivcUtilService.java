package com.ebankunion.invoicep.service;

import com.google.common.hash.Hashing;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import okhttp3.*;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.math.BigInteger;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.TimeUnit;

/**
 * ██╗  ██╗██╗    ██╗ ██████╗
 * ██║  ██║██║    ██║██╔════╝
 * ███████║██║ █╗ ██║██║  ███╗
 * ██╔══██║██║███╗██║██║   ██║
 * ██║  ██║╚███╔███╔╝╚██████╔╝
 * ╚═╝  ╚═╝ ╚══╝╚══╝  ╚═════╝
 * Created by huwenguang on 2019/3/6.
 */
@Service
public class PivcUtilService {
    private final Logger logger = LoggerFactory.getLogger(getClass());

    public JsonObject httpPost(String url, int secTimeout, String postdata){
        JsonObject joRS = new JsonObject();

        try{
            String strHttpReturn  = httpPostGetString(url, secTimeout, postdata);

            JsonObject joBody = parseJsonFromString(strHttpReturn);

            if(joBody.size() > 0){
                joRS = joBody;
            }

        }catch (Exception e){
            logger.error("httpPost exception:", e);
        }

        return joRS;
    }


    public String httpPostGetString(String url, final int secTimeout, final String postdata){
        String strHttpReturn = "";

        OkHttpClient client = new OkHttpClient()
                .newBuilder()
                .connectTimeout(secTimeout, TimeUnit.SECONDS)
                .readTimeout(secTimeout, TimeUnit.SECONDS)
                .build()
                ;

        final MediaType mediaType = MediaType.get("application/json; charset=utf-8");
        RequestBody body = RequestBody.create(mediaType, postdata);
        Request request = new Request.Builder().url(url).post(body).build();

        String msgJayce = String.format("发送请求 url[%s], timeout[%s], 发送数据[%s]", String.valueOf(url), String.valueOf(secTimeout), String.valueOf(postdata) );
        mylog(msgJayce);
        logger.debug(msgJayce);

        try{
            Response response = client.newCall(request).execute();
            strHttpReturn  = response.body().string();
            int statusCode = response.code();

            msgJayce = String.format("接收响应 url[%s], 响应码[%s], 响应数据[%s]", String.valueOf(url), String.valueOf(statusCode),
                    String.valueOf(strHttpReturn));
            mylog(msgJayce);
            logger.debug(msgJayce);

        }catch (IOException e){
            logger.error("httpPostGetString exception:", e);
        }

        return strHttpReturn;
    }


    public void mylog(Object msg){
        String newmsg = String.format("enc: %s", getBase64(msg) );
        logger.info(newmsg);
    }

    public JsonObject parseJsonFromString(final String strJson){
        JsonObject jo = new JsonObject();
        try{
            jo = new Gson().fromJson(strJson, JsonObject.class);
        }catch (Exception e){}

        return jo;
    }

    public String capitalize(String input){
        String result = "";
        if(null != input && !input.isEmpty()){
            result = StringUtils.capitalize(input);
        }
        return result;
    }

    public boolean isRetcodeGood(JsonObject joIvcReturn){
        String retcode = getStringFromJson(joIvcReturn, "retcode");

        boolean bValid = false;
        if(! isEmptyString(retcode) && retcode.length() == 4){
            bValid = true;
        }

        return bValid;
    }

    public boolean isStringRetcodeSuccessful(String retcode){
        if("0000".equalsIgnoreCase(retcode)){
            return true;
        }
        return false;
    }

    public boolean isSuccessfulRetcode(JsonObject joIvcReturn){
        String retcode = getStringFromJson(joIvcReturn, "retcode");

        boolean bValid = false;
        if(! isEmptyString(retcode) && retcode.length() == 4 && "0000".equalsIgnoreCase(retcode)){
            bValid = true;
        }

        return bValid;
    }

    public JsonObject fromObject2Json(final Object obj){
        JsonObject jo = new JsonObject();
        try{
            String strJson = new Gson().toJson(obj);
            if(obj instanceof String){
                strJson = (String)obj;
            }

            jo = new JsonParser().parse(strJson).getAsJsonObject();
        }catch (Exception e){

        }

        return jo;
    }

    public Map<String, Object> fromObject2Map(Object obj){
        Map<String, Object> map = new HashMap<String, Object>();
        try{
            JsonObject jo = fromObject2Json(obj);
            for(String key : jo.keySet()){
                JsonElement value = jo.get(key);

                if(value.isJsonNull()){
                    map.put(key, "");
                }else{
                    String newvalue = getStringFromJson(jo, key);
                    map.put(key, newvalue);
                }

            }
        }catch (Exception e){
        }

        return map;
    }

    public boolean isJsonObjectEmpty(JsonObject jo){
        boolean bEmpty = false;
        if(null == jo || jo.keySet().isEmpty()){
            bEmpty = true;
        }

        return bEmpty;
    }

    public boolean jsonHasKey(JsonObject jo, String key){
        boolean bContains = false;
        if(jo.has(key)){
            bContains = true;
        }

        return bContains;
    }


    public JsonObject excludeNullEmptyAndSign(JsonObject joOrgMsg){
        JsonObject joNew = new JsonObject();
        try{
            for( String key : joOrgMsg.keySet() ){
                if(! "sign".equalsIgnoreCase(key)){
                    JsonElement value = joOrgMsg.get(key);

                    try{
                        if(! isJsonElementNullOrEmpty(value)){
                            joNew.add(key, value);
                        }
                    }catch (Exception e){}
                }
            }
        }catch (Exception e){}



        return joNew;
    }

    public String generateLogID(){
        int length = 8;
        String strId = RandomStringUtils.random(length, true, true);
        return strId;
    }

    public String doUmsSign(JsonObject joOrgMsg, String key){
        JsonObject joExcluded = excludeNullEmptyAndSign(joOrgMsg);

        String strOrdered = getStringWithOrderedKey(joExcluded);

        String str2sign = String.format("%s%s", strOrdered, String.valueOf(key));

        String sign = doUtf8Sha256(str2sign);

        return sign;
    }

    public String getStringWithOrderedKey(JsonObject joExcluded){
        List<String> keys = getOrderedKeys(joExcluded);

        StringJoiner sb = new StringJoiner("&");
        for(String akey : keys){
            String value = getStringFromJson(joExcluded, akey);

            String newpair = String.format("%s=%s", String.valueOf(akey), String.valueOf(value));
            sb.add(newpair);
        }


        return sb.toString();
    }

    public List<String> getOrderedKeys(JsonObject joOrgMsg){
        List<String> keys = new ArrayList<>();
        for(String itemkey : joOrgMsg.keySet()){
            keys.add(itemkey);
        }
        Collections.sort(keys);

        return keys;
    }

    public boolean isJsonElementNullOrEmpty(JsonElement jsonElement){
        boolean bEmpty = false;

        if(jsonElement.isJsonArray() && jsonElement.getAsJsonArray().size() <= 0){
            bEmpty = true;
        }
        if(jsonElement.isJsonObject() && jsonElement.getAsJsonObject().keySet().size() == 0){
            bEmpty = true;
        }

        if(jsonElement.isJsonNull()){

            bEmpty = true;

        }else if(jsonElement.isJsonPrimitive()){
            String strValue = jsonElement.getAsString();
            if(isEmptyString(strValue)){
                bEmpty = true;
            }
        }

        return bEmpty;
    }

    public boolean isJsonKeyStringType(JsonObject jo, String key){
        boolean bIsStringType = false;
        try{
            if(jo.has(key)){
                JsonElement element = jo.get(key);
                bIsStringType = element.getAsJsonPrimitive().isString();
            }
        }catch (Exception e){
        }

        return bIsStringType;
    }

    public String getStringFromJson(JsonObject jo, String key){
        String result = "";
        try{
            if(jo.has(key)){
                JsonElement joResult = jo.get(key);
                if(joResult.isJsonPrimitive()){
                    result = joResult.getAsString();
                }

            }
        }catch (Exception e){
        }

        return result;
    }

    public String getStringFromJsonDefault(JsonObject jo, String key, String strDefault){
        String result = getStringFromJson(jo, key);
        if(isEmptyString(result)){
            result = strDefault;
        }

        return result;
    }

    public String getBase64(Object msg){
        String msgDavid = String.valueOf(msg);
        byte[] encodedBytes = Base64.getEncoder().encode(msgDavid.getBytes());
        return new String(encodedBytes);
    }

    public boolean isEmptyString(String input){
        boolean bEmpty = false;

        if(input == null || input.isEmpty()){
            bEmpty = true;
        }

        return bEmpty;
    }

    public String doUtf8Sha256(String input){
        return getSha256(input, StandardCharsets.UTF_8);
    }

    public String getSha256(String input, Charset encoding){
        String result = Hashing.sha256().hashString(input, encoding).toString().toUpperCase();

        return result;
    }

    public BigInteger getIntFromString(String amount){
        BigInteger myint = new BigInteger("0");

        try{ myint = new BigInteger(amount); }catch (Exception e){}

        return myint;
    }
}
