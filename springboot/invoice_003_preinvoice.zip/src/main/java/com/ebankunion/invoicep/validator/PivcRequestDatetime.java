package com.ebankunion.invoicep.validator;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

/**
 * ██╗  ██╗██╗    ██╗ ██████╗
 * ██║  ██║██║    ██║██╔════╝
 * ███████║██║ █╗ ██║██║  ███╗
 * ██╔══██║██║███╗██║██║   ██║
 * ██║  ██║╚███╔███╔╝╚██████╔╝
 * ╚═╝  ╚═╝ ╚══╝╚══╝  ╚═════╝
 * Created by huwenguang on 2019/3/18.
 */

@Target({FIELD})
@Retention(RUNTIME)
@Constraint(validatedBy = PivcRequestDatetimeValidator.class)
public @interface PivcRequestDatetime {

    String message() default "datetime format is yyyy-MM-dd HH:mm:ss";

    String format() default "";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};
}
