package com.ebankunion.invoicep.controller;

import com.ebankunion.invoicep.bean.*;
import com.ebankunion.invoicep.exception.PivcArgumentCheckException;
import com.ebankunion.invoicep.exception.PivcException;
import com.ebankunion.invoicep.service.*;
import com.google.gson.JsonObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

/**
 * ██╗  ██╗██╗    ██╗ ██████╗
 * ██║  ██║██║    ██║██╔════╝
 * ███████║██║ █╗ ██║██║  ███╗
 * ██╔══██║██║███╗██║██║   ██║
 * ██║  ██║╚███╔███╔╝╚██████╔╝
 * ╚═╝  ╚═╝ ╚══╝╚══╝  ╚═════╝
 * Created by huwenguang on 2019/3/5.
 */
@RestController
public class PivcMainController {
    @Autowired
    private PivcConf conf;

    @Autowired
    private PivcUtilService myutil;

    @Autowired
    private PivcMercService mercService;

    @Autowired
    private PivcIssueService issueService;

    @Autowired
    private PivcQueryService queryService;

    @Autowired
    private PivcWeixinCardService weixinCardService;

    @Autowired
    private PivcQueryfuzzytitleService queryfuzzytitleService;

    @PostMapping(value = "/ips/invoicep/issue" )
    public JsonObject issue(@Valid PivcIssueRequest request, BindingResult bindingResult){
        doArgumentCheck(bindingResult);

        String urlMysql     = conf.getPivcMysqlTddlUrl();
        String pivcMysqlDb  = conf.getPivcMysqlDatabase();
        String tablename    = conf.getPivcMysqlTablename();
        String usertoken    = conf.getPivcMysqlUsertoken();

        JsonObject joOrgMsg = myutil.fromObject2Json(request);
        mercService.checkMercIssueConf(joOrgMsg, urlMysql, pivcMysqlDb, tablename, usertoken);

        JsonObject joResult = issueService.process(request);

        joResult = mercService.normalizeResultAndDoSign(joResult);

        return joResult;
    }


    @PostMapping(value = "/ips/invoicep/query" )
    public JsonObject query(@Valid PivcQueryRequest request, BindingResult bindingResult){
        doArgumentCheck(bindingResult);

        String urlMysql     = conf.getPivcMysqlTddlUrl();
        String pivcMysqlDb  = conf.getPivcMysqlDatabase();
        String tablename    = conf.getPivcMysqlTablename();
        String usertoken    = conf.getPivcMysqlUsertoken();

        JsonObject joOrgMsg = myutil.fromObject2Json(request);
        mercService.checkMercCommonConf(joOrgMsg, urlMysql, pivcMysqlDb, tablename, usertoken);

        JsonObject joResult = queryService.process(request);

        joResult = mercService.normalizeResultAndDoSign(joResult);

        return joResult;
    }


    @PostMapping(value = "/ips/invoicep/weixincard" )
    public JsonObject weixincard(@Valid PivcWeixinCardRequest request, BindingResult bindingResult){
        doArgumentCheck(bindingResult);

        String urlMysql     = conf.getPivcMysqlTddlUrl();
        String pivcMysqlDb  = conf.getPivcMysqlDatabase();
        String tablename    = conf.getPivcMysqlTablename();
        String usertoken    = conf.getPivcMysqlUsertoken();

        JsonObject joOrgMsg = myutil.fromObject2Json(request);
        mercService.checkMercCommonConf(joOrgMsg, urlMysql, pivcMysqlDb, tablename, usertoken);

        JsonObject joResult = weixinCardService.process(request);

        joResult = mercService.normalizeResultAndDoSign(joResult);

        return joResult;
    }


    @PostMapping(value = "/ips/invoicep/queryfuzzytitle" )
    public JsonObject queryfuzzytitle(@Valid PivcQueryfuzzytitleRequest request, BindingResult bindingResult){
        doArgumentCheck(bindingResult);

        String urlMysql     = conf.getPivcMysqlTddlUrl();
        String pivcMysqlDb  = conf.getPivcMysqlDatabase();
        String tablename    = conf.getPivcMysqlTablename();
        String usertoken    = conf.getPivcMysqlUsertoken();

        JsonObject joOrgMsg = myutil.fromObject2Json(request);
        mercService.checkMercCommonConf(joOrgMsg, urlMysql, pivcMysqlDb, tablename, usertoken);

        JsonObject joResult = queryfuzzytitleService.process(request);

        joResult = mercService.normalizeResultAndDoSign(joResult);

        return joResult;
    }


    protected void doArgumentCheck(BindingResult bindingResult) throws PivcException{
        if(bindingResult.hasErrors()){
            PivcArgumentCheckException ex = new PivcArgumentCheckException();

            FieldError fe = bindingResult.getFieldError();
            if(fe != null){
                String additional = String.format("%s:%s", String.valueOf(fe.getField()), String.valueOf(fe.getDefaultMessage()));
                ex.setAdditionmsg(additional);
            }

            throw ex;
        }
    }
}
