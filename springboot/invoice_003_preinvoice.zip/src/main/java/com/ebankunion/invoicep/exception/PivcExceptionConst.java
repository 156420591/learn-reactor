package com.ebankunion.invoicep.exception;

/**
 * ██╗  ██╗██╗    ██╗ ██████╗
 * ██║  ██║██║    ██║██╔════╝
 * ███████║██║ █╗ ██║██║  ███╗
 * ██╔══██║██║███╗██║██║   ██║
 * ██║  ██║╚███╔███╔╝╚██████╔╝
 * ╚═╝  ╚═╝ ╚══╝╚══╝  ╚═════╝
 * Created by huwenguang on 2019/3/6.
 */
public class PivcExceptionConst {
    public static final String ARGERROR_Retcode        = "5001";
    public static final String ARGERROR_Retmsg         = "参数校验错";

    public static final String MERCNOTEXIST_Retcode    = "5002";
    public static final String MERCNOTEXIST_Retmsg     = "商户未入网";


    public static final String MERCCLOSED_Retcode      = "5003";
    public static final String MERCCLOSED_Retmsg       = "商户已关闭";


    public static final String LogicFailure_Retcode    = "5004";
    public static final String LogicFailure_Retmsg     = "逻辑校验错";


    public static final String SignFailure_Retcode     = "5005";
    public static final String SignFailure_Retmsg      = "报文sign校验失败";


    public static final String BackendFailure_Retcode  = "5006";
    public static final String BackendFailure_Retmsg   = "后端服务异常";


    public static final String EsFailure_Retcode       = "5007";
    public static final String EsFailure_Retmsg        = "数据库错误es";

    public static final String EsConflict_Retcode      = "5008";
    public static final String EsConflict_Retmsg       = "订单号重复es";

    public static final String UNKNOWN_Retcode         = "5999";
    public static final String UNKNOWN_Retmsg          = "系统错误";
}
