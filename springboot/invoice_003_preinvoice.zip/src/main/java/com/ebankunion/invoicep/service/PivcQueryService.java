package com.ebankunion.invoicep.service;

import com.ebankunion.invoicep.backendbean.PivcIssueEndpointBean;
import com.ebankunion.invoicep.backendbean.PivcQueryInvoiceEndpointBean;
import com.ebankunion.invoicep.bean.PivcIssueRequest;
import com.ebankunion.invoicep.bean.PivcQueryRequest;
import com.ebankunion.invoicep.exception.PivcBackendException;
import com.ebankunion.invoicep.exception.PivcException;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import org.springframework.stereotype.Service;

/**
 * ██╗  ██╗██╗    ██╗ ██████╗
 * ██║  ██║██║    ██║██╔════╝
 * ███████║██║ █╗ ██║██║  ███╗
 * ██╔══██║██║███╗██║██║   ██║
 * ██║  ██║╚███╔███╔╝╚██████╔╝
 * ╚═╝  ╚═╝ ╚══╝╚══╝  ╚═════╝
 * Created by huwenguang on 2019/3/12.
 */
@Service
public class PivcQueryService extends PivcCommonService {

    public JsonObject process(PivcQueryRequest request) throws PivcException {

        String postdata = fmtRequest2InvoiceSendString(request);

        String url = String.format("%s/query", conf.getIpsInvoicePrefix());
        JsonObject joIvcReturn = utilService.httpPost(url, conf.getPivcHttpTimeout(), postdata);

        if( ! utilService.isRetcodeGood(joIvcReturn)){
            throw new PivcBackendException();
        }

        return joIvcReturn;
    }


    protected String fmtRequest2InvoiceSendString(PivcQueryRequest request) {
        PivcQueryInvoiceEndpointBean issueEnd = initSendObject(request);

        JsonObject joIssueEndpoint = utilService.fromObject2Json(issueEnd);

        return utilService.getStringWithOrderedKey(joIssueEndpoint);
    }

    protected PivcQueryInvoiceEndpointBean initSendObject(PivcQueryRequest request){
        JsonObject joRequest = normalizeRequest(request);

        Gson gson = new GsonBuilder().excludeFieldsWithoutExposeAnnotation().create();
        PivcQueryInvoiceEndpointBean issueEnd = gson.fromJson(joRequest, PivcQueryInvoiceEndpointBean.class);

        //TODO set terminal and merchant id to invoice endpoint
        issueEnd.setMerchantId("");
        issueEnd.setTerminalId("");
        issueEnd.setMsgSrc("");

        return issueEnd;
    }

}
