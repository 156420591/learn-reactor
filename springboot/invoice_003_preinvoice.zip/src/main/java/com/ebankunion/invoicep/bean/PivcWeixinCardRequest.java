package com.ebankunion.invoicep.bean;

import com.ebankunion.invoicep.validator.PivcDate;
import com.ebankunion.invoicep.validator.PivcRequestDatetime;
import com.google.gson.annotations.Expose;
import lombok.Data;
import org.springframework.stereotype.Component;

import javax.validation.constraints.NotEmpty;

/**
 * ██╗  ██╗██╗    ██╗ ██████╗
 * ██║  ██║██║    ██║██╔════╝
 * ███████║██║ █╗ ██║██║  ███╗
 * ██╔══██║██║███╗██║██║   ██║
 * ██║  ██║╚███╔███╔╝╚██████╔╝
 * ╚═╝  ╚═╝ ╚══╝╚══╝  ╚═════╝
 * Created by huwenguang on 2019/3/12.
 */
@Data @Component
public class PivcWeixinCardRequest {
    @NotEmpty
    private String msgId;

    @NotEmpty
    private String msgSrc;

    @NotEmpty @PivcRequestDatetime
    private String requestTimestamp;

    @NotEmpty
    private String srcReserve;

//    @NotEmpty
//    private String merchantId ;
//    @NotEmpty
//    private String terminalId ;

    @NotEmpty
    private String merOrderId;

    @NotEmpty @PivcDate
    private String merOrderDate;

    @NotEmpty
    private String source;

    private String invoiceNo;

    private String invoiceCode;

    @NotEmpty
    private String sign;
}
