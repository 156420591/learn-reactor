package com.ebankunion.invoicep.service;

import com.ebankunion.invoicep.exception.PivcException;
import com.ebankunion.invoicep.exception.PivcExceptionConst;
import com.google.gson.JsonObject;
import org.apache.commons.lang3.ObjectUtils;
import org.aspectj.lang.ProceedingJoinPoint;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.stereotype.Service;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.Map;

/**
 * ██╗  ██╗██╗    ██╗ ██████╗
 * ██║  ██║██║    ██║██╔════╝
 * ███████║██║ █╗ ██║██║  ███╗
 * ██╔══██║██║███╗██║██║   ██║
 * ██║  ██║╚███╔███╔╝╚██████╔╝
 * ╚═╝  ╚═╝ ╚══╝╚══╝  ╚═════╝
 * Created by huwenguang on 2019/3/5.
 */
@Service
public class PivcTrapService {
    private final Logger logger         = LoggerFactory.getLogger(getClass());

    private PivcUtilService utilService = new PivcUtilService();
    private PivcMonitorService monitor  = new PivcMonitorService();

    protected void forwardException(Throwable e) throws PivcException{
        PivcException exception = new PivcException();
        if(e instanceof PivcException){
            exception = (PivcException) e;
        }else {
        }

        //TODO log the original exception
        logger.error("code exception stack", e);


        feedMonitorRetcode(exception, monitor);
        logResponseResult(exception);
        monitor.log();


        throw exception;
    }

    protected void pushLogId(){
        String strLogid = utilService.generateLogID();
        MDC.put("LOG_ID", strLogid);
    }

    protected void logRequest(ServletRequestAttributes attributes){
        if(null == attributes){
            return;
        }
        HttpServletRequest request = attributes.getRequest();
        if(null == request){
            return;
        }
        StringBuffer sb = new StringBuffer();
        String urlRequest = request.getRequestURL().toString();

    }

    protected String getRequestUri(ServletRequestAttributes attributes){
        String uri = "";
        if(null != attributes && attributes.getRequest() != null){
            uri = attributes.getRequest().getRequestURI();
        }
        return uri;
    }

    protected void feedMonitorData_1(ServletRequestAttributes attributes){
        String uri = getRequestUri(attributes);
        monitor.setUri(uri);

    }

    protected void feedMonitorData_2(Object[] args){
        if(args.length <= 0){
            return;
        }

        Object obj1 = args[0];
        JsonObject joParam = utilService.fromObject2Json(obj1);
        String msgSrc      = utilService.getStringFromJson(joParam, "msgSrc");

        monitor.setMsgSrc(msgSrc);
    }

    protected void logRequestParam(ProceedingJoinPoint pjp){
        String msgJayce = "";

        String method = pjp.getSignature().getDeclaringTypeName() + "."
                + pjp.getSignature().getName();
        msgJayce = String.format("执行的方法[%s]", String.valueOf(method));
        logger.info(msgJayce);

        Object[] args = pjp.getArgs().clone();
        feedMonitorData_2(args);
        if(args.length > 0){
            String newparam = utilService.getBase64(args[0].toString());
            msgJayce = String.format("参数:[%s]", String.valueOf(newparam) );
            logger.info(msgJayce);
        }

    }

    protected void feedMonitorRetcode(Object result, PivcMonitorService monitor){
        JsonObject joResult = utilService.fromObject2Json(result);
        String retcode      = utilService.getStringFromJson(joResult, "retcode");
        String retmsg       = utilService.getStringFromJson(joResult, "retmsg");

        monitor.setRetcode(retcode);
        monitor.setRetmsg(retmsg);
    }

    protected void logTimeConsuming(long iStart, long iEnd){
        long iTimeSpend = iEnd - iStart;
        String msg = String.format("共花费时间[%s]毫秒", iTimeSpend );
        logger.info(msg);
        MDC.put("LOG_TC", String.valueOf(iTimeSpend));
        monitor.setTimeSpan(String.valueOf(iTimeSpend));
    }

    protected void logResponseResult(Object obj){
        String msg = String.format("返回结果[%s]", String.valueOf(obj));
        msg = utilService.getBase64(msg);
        logger.info(msg);
    }

    public Object process(ProceedingJoinPoint pjp){
        pushLogId();

        long iStartTime = System.currentTimeMillis();
        ThreadLocal<Long> startTime = new ThreadLocal<>();
        startTime.set(iStartTime);

        String msgJayce = "";
        ServletRequestAttributes attributes = (ServletRequestAttributes) RequestContextHolder.currentRequestAttributes();
        logRequest(attributes);
        logRequestParam(pjp);

        Object objResult = null;

        try {
            objResult = pjp.proceed();

            logTimeConsuming(iStartTime, System.currentTimeMillis());
            feedMonitorRetcode(objResult, monitor);
            monitor.log();
            logResponseResult(objResult);

        }catch (Throwable e){
            logTimeConsuming(iStartTime, System.currentTimeMillis());

            forwardException(e);
        }



        return objResult;
    }
}
