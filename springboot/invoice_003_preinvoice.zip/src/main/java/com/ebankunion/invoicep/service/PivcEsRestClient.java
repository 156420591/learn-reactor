package com.ebankunion.invoicep.service;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpHost;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.nio.client.HttpAsyncClientBuilder;
import org.apache.http.ssl.SSLContextBuilder;
import org.apache.http.ssl.TrustStrategy;
import org.elasticsearch.client.RestClient;
import org.elasticsearch.client.RestClientBuilder;
import org.elasticsearch.client.RestHighLevelClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import java.net.MalformedURLException;
import java.net.URL;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.Arrays;
import java.util.Objects;

/**
 * ██╗  ██╗██╗    ██╗ ██████╗
 * ██║  ██║██║    ██║██╔════╝
 * ███████║██║ █╗ ██║██║  ███╗
 * ██╔══██║██║███╗██║██║   ██║
 * ██║  ██║╚███╔███╔╝╚██████╔╝
 * ╚═╝  ╚═╝ ╚══╝╚══╝  ╚═════╝
 * Created by huwenguang on 2019/3/19.
 */


class FancyUrl {
    public String host    = "";
    public int    port    = 80;
    public String scheme  = "http";
    public String uri     = "/";

    public FancyUrl(String url){
        try{
            URL myurl = new URL(url);
            host      = myurl.getHost();
            scheme    = myurl.getProtocol();
            uri       = myurl.getPath();

            int tport = myurl.getPort();
            port      = tport;
            if(-1 == tport){
                port = 80;
            }
        }catch (MalformedURLException ex){}
    }


    @Override
    public String toString() {
        return "FancyUrl{" +
                "host='" + host + '\'' +
                ", port=" + port +
                ", scheme='" + scheme + '\'' +
                ", uri='" + uri + '\'' +
                '}';
    }
}

@Configuration
public class PivcEsRestClient {

    private final int    ADDRESS_LENGTH = 2;
    private final String HTTP_SCHEME    = "https";

    @Bean(name = "pivcRestClientBuilder")
    public RestClientBuilder getRestClientBuilder(@Value("${invoice.esUrl}")        String[] ipAddress,
                                                  @Value("${invoice.esUser:}")       String esUser,
                                                  @Value("${invoice.esUserPasswd:}") String esUserPasswd
                                                  ) throws KeyManagementException, NoSuchAlgorithmException, KeyStoreException {

        HttpHost[] hosts = strHost2HttpHost(ipAddress);

        // 支持单向认证，忽略证书

        CredentialsProvider cp = getCredential(esUser, esUserPasswd);

        SSLContext sslContext = new SSLContextBuilder().loadTrustMaterial(null, new TrustStrategy(){
            public boolean isTrusted(X509Certificate[] chain, String authType) throws CertificateException{
                return true;
            }
        }).build();


        return RestClient.builder(hosts)
                .setHttpClientConfigCallback(new RestClientBuilder.HttpClientConfigCallback() {
                    @Override
                    public HttpAsyncClientBuilder customizeHttpClient(HttpAsyncClientBuilder httpcb) {
                        return httpcb
                                .setDefaultCredentialsProvider(cp)
                                .setSSLContext(sslContext)
                                .setSSLHostnameVerifier(new HostnameVerifier() {
                                    @Override
                                    public boolean verify(String hostname, SSLSession session) {
                                        return true; // 不检查证书和域名是否匹配
                                    }
                                });
                    }
                });

    }


    @Bean(name = "pivcHighLevelRestClient")
    public RestHighLevelClient highLevelClient(@Autowired @Qualifier("pivcRestClientBuilder") RestClientBuilder restClientBuilder) {
        restClientBuilder.setMaxRetryTimeoutMillis(60000);
        return new RestHighLevelClient(restClientBuilder);
    }

    protected CredentialsProvider getCredential(String esUser, String esUserPasswd){
        CredentialsProvider cp = null;
        if( StringUtils.isNotEmpty(esUser) ){
            cp = new BasicCredentialsProvider();
            cp.setCredentials(AuthScope.ANY, new UsernamePasswordCredentials(esUser, esUserPasswd));
        }

        return cp;
    }


    protected HttpHost[] strHost2HttpHost(String[] ipAddress){
        HttpHost[] hosts = Arrays.stream(ipAddress)
                .map(this::makeHttpHost)
                .filter(Objects::nonNull)
                .toArray(HttpHost[]::new);
        return hosts;
    }

    protected HttpHost makeHttpHost(String input) {
        assert StringUtils.isNotEmpty(input);
        HttpHost hh = null;

        if(input.startsWith("http://") || input.startsWith("https://")){
            FancyUrl myurl = new FancyUrl(input);
            hh = new HttpHost(myurl.host, myurl.port, myurl.scheme);
        }else{
            String[] address = input.split(":");
            if (address.length == ADDRESS_LENGTH) {
                String ip = address[0];
                int port = Integer.parseInt(address[1]);
                hh = new HttpHost(ip, port, HTTP_SCHEME);
            }
        }


        return hh;
    }

}
