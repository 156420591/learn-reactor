package com.ebankunion.invoicep.bean;

import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

/**
 * ██╗  ██╗██╗    ██╗ ██████╗
 * ██║  ██║██║    ██║██╔════╝
 * ███████║██║ █╗ ██║██║  ███╗
 * ██╔══██║██║███╗██║██║   ██║
 * ██║  ██║╚███╔███╔╝╚██████╔╝
 * ╚═╝  ╚═╝ ╚══╝╚══╝  ╚═════╝
 * Created by huwenguang on 2019/3/8.
 */

@Data @Component
@PropertySource("classpath:application.properties")
public class PivcConf {
    @Value("${invoicep.ipsInvoicePrefix}")
    private String ipsInvoicePrefix;

    @Value("${invoicep.pivcMysqlTddlUrl}")
    private String pivcMysqlTddlUrl;

    @Value("${invoicep.pivcMysqlDatabase:ips}")
    private String pivcMysqlDatabase;

    @Value("${invoicep.pivcMysqlTablename}")
    private String pivcMysqlTablename;

    @Value("${invoicep.pivcMysqlUsertoken}")
    private String pivcMysqlUsertoken;

    @Value("${invoicep.pivcHttpTimeout:60}")
    private int    pivcHttpTimeout;

    @Value("${invoicep.pivcIpsErrorcodeUrl}")
    private String pivcIpsErrorcodeUrl;

    @Value("${invoicep.pivcIpsErrorcodeIntype}")
    private String pivcIpsErrorcodeIntype;

}
