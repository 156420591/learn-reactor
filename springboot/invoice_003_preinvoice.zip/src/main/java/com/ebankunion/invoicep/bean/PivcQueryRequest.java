package com.ebankunion.invoicep.bean;

import com.ebankunion.invoicep.validator.PivcDate;
import com.ebankunion.invoicep.validator.PivcRequestDatetime;
import lombok.Data;
import org.springframework.stereotype.Component;

import javax.validation.constraints.NotEmpty;

/**
 * ██╗  ██╗██╗    ██╗ ██████╗
 * ██║  ██║██║    ██║██╔════╝
 * ███████║██║ █╗ ██║██║  ███╗
 * ██╔══██║██║███╗██║██║   ██║
 * ██║  ██║╚███╔███╔╝╚██████╔╝
 * ╚═╝  ╚═╝ ╚══╝╚══╝  ╚═════╝
 * Created by huwenguang on 2019/3/12.
 */

@Data @Component
public class PivcQueryRequest {
    @NotEmpty
    private String msgId;

    @NotEmpty
    private String msgSrc;

    @NotEmpty @PivcRequestDatetime
    private String requestTimestamp;

    private String srcReserve;

    @NotEmpty
    private String merOrderId;

    @NotEmpty @PivcDate
    private String merOrderDate;

    @NotEmpty private String sign;
}
