package com.ebankunion.invoicep.exception;

/**
 * ██╗  ██╗██╗    ██╗ ██████╗
 * ██║  ██║██║    ██║██╔════╝
 * ███████║██║ █╗ ██║██║  ███╗
 * ██╔══██║██║███╗██║██║   ██║
 * ██║  ██║╚███╔███╔╝╚██████╔╝
 * ╚═╝  ╚═╝ ╚══╝╚══╝  ╚═════╝
 * Created by huwenguang on 2019/3/7.
 */
public class PivcMercClosedException extends PivcException {
    public PivcMercClosedException() {
        super();
        setRetcode(PivcExceptionConst.MERCCLOSED_Retcode);
        setRetmsg(PivcExceptionConst.MERCCLOSED_Retmsg);
    }
}
