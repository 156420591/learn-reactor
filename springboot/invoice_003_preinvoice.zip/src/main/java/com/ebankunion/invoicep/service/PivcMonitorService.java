package com.ebankunion.invoicep.service;

import lombok.Data;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

/**
 * ██╗  ██╗██╗    ██╗ ██████╗
 * ██║  ██║██║    ██║██╔════╝
 * ███████║██║ █╗ ██║██║  ███╗
 * ██╔══██║██║███╗██║██║   ██║
 * ██║  ██║╚███╔███╔╝╚██████╔╝
 * ╚═╝  ╚═╝ ╚══╝╚══╝  ╚═════╝
 * Created by huwenguang on 2019/3/11.
 */
@Service @Data
public class PivcMonitorService {
    private static final Logger logger = LoggerFactory.getLogger("invoicepMonitor");

    private String uri;
    private String msgSrc;
    private String retcode;
    private String retmsg;
    private String timeSpan;

    //TODO implement log
    public void log(){
        StringBuffer sb = fmtMonitorData();

        logger.info(sb.toString());

    }

    protected StringBuffer fmtMonitorData() {
        StringBuffer sb = new StringBuffer();
        String mysep    = " ";
        sb
                .append( normalizeField(timeSpan        , 6 , ' ') ).append(mysep)
                .append( normalizeField(uri             , 10, ' ') ).append(mysep)
                .append( normalizeField(msgSrc          , 32, ' ') ).append(mysep)
                .append( normalizeField(retcode         , 4 , ' ') ).append(mysep)
                .append( retmsg )
        ;
        return sb;
    }


    protected String normalizeField(String strInput, int maxlen, char chPadding){
        String strNew = strInput==null ? "" : strInput;
        maxlen = maxlen > 0 ? maxlen : 0;

        if(isEmptyString(strInput)){
            strNew = "_";
        }
        strNew = trimPaddingRight(strNew, maxlen, chPadding);

        return strNew;
    }

    protected boolean isEmptyString(String msg){
        if(null == msg){
            return true;
        }
        if(msg.isEmpty()){
            return true;
        }
        return false;
    }

    protected String trimPaddingRight(String strInput, int maxlen, char chPadding){
        String strNew = strInput==null ? "" : strInput;
        maxlen = maxlen > 0 ? maxlen : 0;

        if(strNew.length() < maxlen){
            int lenPad = maxlen - strNew.length();
            strNew = strNew + strRepeat(lenPad, chPadding);
        }else if(strNew.length() > maxlen){
            strNew = takeRight(strNew, maxlen);
        }
        return strNew;
    }

    protected String takeRight(String strSource, int right){
        String strTakeRight = strSource;
        if(strSource != null){
            if(strSource.length() >= right){
                strTakeRight = strSource.substring(strSource.length() - right);
            }
        }
        return strTakeRight;
    }


    protected String strRepeat(int len, char chPadding){
        int initlen = len > 0 ? len : 0;
        StringBuffer sb = new StringBuffer(initlen);
        for(int i=0; i < len; ++i){
            sb.append(chPadding);
        }
        return sb.toString();
    }

    protected String safeSubString(String strInput, int startindex, int length){
        length     = length > 0 ? length : 0;
        startindex = startindex > 0 ? startindex : 0;

        try {
            if(strInput == null){
                return "";
            }
            int lenofstr = strInput.length();
            int endindex = startindex + length;

            if(startindex >= lenofstr){
                return "";
            }
            if(endindex >= lenofstr){
                return strInput.substring(startindex);
            }

            return strInput.substring(startindex, endindex);
        } catch (Exception e) {
            return "";
        }
    }

}


