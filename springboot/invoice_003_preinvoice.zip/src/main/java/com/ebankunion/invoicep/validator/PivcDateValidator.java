package com.ebankunion.invoicep.validator;


import org.apache.commons.lang3.StringUtils;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import java.text.SimpleDateFormat;

/**
 * ██╗  ██╗██╗    ██╗ ██████╗
 * ██║  ██║██║    ██║██╔════╝
 * ███████║██║ █╗ ██║██║  ███╗
 * ██╔══██║██║███╗██║██║   ██║
 * ██║  ██║╚███╔███╔╝╚██████╔╝
 * ╚═╝  ╚═╝ ╚══╝╚══╝  ╚═════╝
 * Created by huwenguang on 2019/3/18.
 */
public class PivcDateValidator implements ConstraintValidator<PivcInvoiceMaterial, String> {
    @Override
    public boolean isValid(String s, ConstraintValidatorContext constraintValidatorContext) {
        return false;
    }

    @Override
    public void initialize(PivcInvoiceMaterial constraintAnnotation) {

    }

    protected boolean validateDate(String input){
        final String fmt = "yyyyMMdd";

        if(null == input || input.isEmpty()){
            return false;
        }
        if(fmt.length() != input.length()){
            return false;
        }
        if(!StringUtils.isNumeric(input)){
            return false;
        }

        return jayceValidate(input, fmt);
    }


    protected boolean jayceValidate(String input, String fmt){
        boolean bValid = false;

        try{
            SimpleDateFormat sdf = new SimpleDateFormat(fmt);
            sdf.setLenient(false);
            sdf.parse(input);

            bValid = true;
        }catch (Exception e){
        }

        return bValid;
    }
}
