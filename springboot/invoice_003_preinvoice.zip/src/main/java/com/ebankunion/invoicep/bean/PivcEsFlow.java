package com.ebankunion.invoicep.bean;

import com.google.gson.annotations.Expose;
import lombok.Data;

/**
 * ██╗  ██╗██╗    ██╗ ██████╗
 * ██║  ██║██║    ██║██╔════╝
 * ███████║██║ █╗ ██║██║  ███╗
 * ██╔══██║██║███╗██║██║   ██║
 * ██║  ██║╚███╔███╔╝╚██████╔╝
 * ╚═╝  ╚═╝ ╚══╝╚══╝  ╚═════╝
 * Created by huwenguang on 2019/3/19.
 */
@Data
public class PivcEsFlow {
    @Expose(serialize = true, deserialize = true)
    public String msgId;
    @Expose(serialize = true, deserialize = true)
    public String msgSrc;
    @Expose(serialize = true, deserialize = true)
    public String requestTimestamp;
    @Expose(serialize = true, deserialize = true)
    public String srcReserve;
    @Expose(serialize = true, deserialize = true)
    public String invoiceMaterial;
    @Expose(serialize = true, deserialize = true)
    public String invoiceType;
    @Expose(serialize = true, deserialize = true)
    public String merchantId;
    @Expose(serialize = true, deserialize = true)
    public String terminalId;
    @Expose(serialize = true, deserialize = true)
    public String merOrderDate;
    @Expose(serialize = true, deserialize = true)
    public String merOrderId;
    @Expose(serialize = true, deserialize = true)
    public String buyerName;
    @Expose(serialize = true, deserialize = true)
    public String buyerTaxCode;
    @Expose(serialize = true, deserialize = true)
    public String buyerAddress;
    @Expose(serialize = true, deserialize = true)
    public String buyerTelephone;
    @Expose(serialize = true, deserialize = true)
    public String buyerBank;
    @Expose(serialize = true, deserialize = true)
    public String buyerAccount;
    @Expose(serialize = true, deserialize = true)
    public String amount;
    @Expose(serialize = true, deserialize = true)
    public String deductionAmount;
    @Expose(serialize = true, deserialize = true)
    public String goodsDetail;
    @Expose(serialize = true, deserialize = true)
    public String remark;
    @Expose(serialize = true, deserialize = true)
    public String notifyMobileNo;
    @Expose(serialize = true, deserialize = true)
    public String notifyEMail;
    @Expose(serialize = true, deserialize = true)
    public String notifyUrl;
    @Expose(serialize = true, deserialize = true)
    public String storeId;
    @Expose(serialize = true, deserialize = true)
    public String status;



    @Expose(serialize = true, deserialize = true)
    public String retcode;
    @Expose(serialize = true, deserialize = true)
    public String retmsg;

    @Expose(serialize = true, deserialize = true)
    public String responseTimestamp;
    @Expose(serialize = true, deserialize = true)
    public String invoiceNo;
    @Expose(serialize = true, deserialize = true)
    public String invoiceCode;
    @Expose(serialize = true, deserialize = true)
    public String checkCode;
    @Expose(serialize = true, deserialize = true)
    public String cipherCode;
    @Expose(serialize = true, deserialize = true)
    public String issueDate;
    @Expose(serialize = true, deserialize = true)
    public String deviceNo;
    @Expose(serialize = true, deserialize = true)
    public String qrCodeId;
    @Expose(serialize = true, deserialize = true)
    public String storeName;
    @Expose(serialize = true, deserialize = true)
    public String merchantName;
    @Expose(serialize = true, deserialize = true)
    public String sellerName;
    @Expose(serialize = true, deserialize = true)
    public String sellerTaxCode;
    @Expose(serialize = true, deserialize = true)
    public String sellerAddress;
    @Expose(serialize = true, deserialize = true)
    public String sellerTelephone;
    @Expose(serialize = true, deserialize = true)
    public String sellerBank;
    @Expose(serialize = true, deserialize = true)
    public String sellerAccount;
    @Expose(serialize = true, deserialize = true)
    public String payee;
    @Expose(serialize = true, deserialize = true)
    public String checker;
    @Expose(serialize = true, deserialize = true)
    public String drawer;
    @Expose(serialize = true, deserialize = true)
    public String taxMethod;
    @Expose(serialize = true, deserialize = true)
    public String totalPriceIncludingTax;
    @Expose(serialize = true, deserialize = true)
    public String totalTax;
    @Expose(serialize = true, deserialize = true)
    public String totalPrice;
    @Expose(serialize = true, deserialize = true)
    public String notifyMerEmail;
    @Expose(serialize = true, deserialize = true)
    public String qrCode;
    @Expose(serialize = true, deserialize = true)
    public String pdfUrl;
    @Expose(serialize = true, deserialize = true)
    public String pdfPreviewUrl;
}
