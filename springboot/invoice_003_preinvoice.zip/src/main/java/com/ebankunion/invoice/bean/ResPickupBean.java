package com.ebankunion.invoice.bean;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.google.gson.annotations.Expose;

import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(value = {"msgSrc","msgType","resultCode","resultMsg"})
public class ResPickupBean {
	@Expose(serialize = false, deserialize = true)
	private String msgId;
	@Expose(serialize = false, deserialize = true)
	private String msgSrc; 
	@Expose(serialize = false, deserialize = true)
	private String msgType; 
	@Expose(serialize = false, deserialize = true)
	private String resultCode; 
	@Expose(serialize = false, deserialize = true)
	private String resultMsg;
	@Expose(serialize = false, deserialize = false)
	private String retcode;
	@Expose(serialize = false, deserialize = false)
	private String retmsg;
	@Expose(serialize = false, deserialize = true)
	private String responseTimestamp;
	@Expose(serialize = false, deserialize = true)
	private String srcReserve;
	@Expose(serialize = false, deserialize = true)
	private String pdf ;
	@Expose(serialize = false, deserialize = true)
	private String sign;
	
}
