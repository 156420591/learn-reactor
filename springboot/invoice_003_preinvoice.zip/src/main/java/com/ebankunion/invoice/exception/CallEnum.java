package com.ebankunion.invoice.exception;
/**
* @author 林创标  linchuangbiao@ebankunion.com
* @version 创建时间：2019年2月14日 上午10:13:46
* 类说明
*/
public enum CallEnum {
	SUCCESS("SUCCESS","成功"),
	
	INTERNAL_ERROR("INTERNAL_ERROR","系统错误"),
	BAD_REQUEST("BAD_REQUEST","请求报文有错"),
	NO_SERVICE("NO_SERVICE","没有能处理请求 的服务"),
	NO_MERCHANT("NO_MERCHANT","找不到商户信息"),
	NO_INVOICE("NO_INVOICE","找不到发票信息"),
	DUP_INVOICE("DUP_INVOICE","重复开票"),
	DUP_SCAN("DUP_SCAN","重复扫码"),
	API_ERROR("API_ERROR","第三方开票接口失败"),
	NET_ERROR("NET_ERROR","通讯异常"),
	ABNORMAL_REQUEST_TIME("ABNORMAL_REQUEST_TIME","请求时间异常"),
	BAD_SIGN("BAD_SIGN","签名错误"),
	TIMEOUT("TIMEOUT","处理超时"),
	;
	
	private String code;
	private String msg;
	
	CallEnum(String code,String msg) {
		this.code = code;
		this.msg = msg;
	}
 
	public String getCode() {
		return code;
	}
 
	public String getMsg() {
		return msg;
	}
}
