package com.ebankunion.invoice.service;

import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

import org.elasticsearch.ElasticsearchException;
import org.elasticsearch.action.DocWriteRequest;
import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.action.index.IndexResponse;
import org.elasticsearch.action.support.WriteRequest;
import org.elasticsearch.action.update.UpdateRequest;
import org.elasticsearch.action.update.UpdateResponse;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.common.xcontent.XContentType;
import org.elasticsearch.rest.RestStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ebankunion.invoice.bean.Goods;
import com.ebankunion.invoice.bean.ReqIssueBean;
import com.ebankunion.invoice.bean.ResIssueBean;
import com.ebankunion.invoice.bean.ToEsFlowData;
import com.ebankunion.invoice.exception.BusinessException;
import com.ebankunion.invoice.exception.ExceptionUtil;
import com.ebankunion.invoice.exception.ResultEnum;
import com.ebankunion.invoice.properties.ParamUms;
import com.ebankunion.invoice.ums.ToIssue;
import com.ebankunion.invoice.util.HttpClient;
import com.ebankunion.invoice.util.Sign;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class Issue {
	@Autowired
	private ParamUms paramUms;
	
	@Autowired
	RestHighLevelClient highLevelClient;

	private ToEsFlowData toEsFlowData = new ToEsFlowData();

	public ResIssueBean process(ReqIssueBean reqIssueBean) {
		ToIssue toIssue = new ToIssue();
		ResIssueBean resIssueBean = new ResIssueBean();
		initValue(toIssue, reqIssueBean);
		toIssue.setSign(Sign.doSign(toIssue, paramUms.getSignKey()));
		// 生成请求包
		Gson gson = new GsonBuilder().excludeFieldsWithoutExposeAnnotation().create();
		String toUms = gson.toJson(toIssue).toString();

		String _id = ToEsFlowData.getEsId(Sign.transBean2MapStr(reqIssueBean));
		toEsFlowData.doIssueRequest(reqIssueBean);
		String toES = gson.toJson(toEsFlowData).toString();
		
		// 发送给银联之前，保存数据到es
		insertES(_id,toES);

		// 发送出去
		String fromString = HttpClient.executePost(paramUms.getUmsAddr(), toUms);

		// 接收解包
		resIssueBean = parse(fromString);

		// 响应成功时，保存数据到es
		if (isResponseValid(resIssueBean)) {
			toEsFlowData.doIssueResponse(resIssueBean);
			toES = gson.toJson(toEsFlowData).toString();
			updateES(_id,toES);
		}

		return resIssueBean;
	}
	
	// 判断返回包是否成功
	protected boolean isResponseValid(ResIssueBean response) {
		boolean isValid = false;
		String resultCode = response.getResultCode();
		if ("SUCCESS".equalsIgnoreCase(resultCode)) {
			isValid = true;
		}

		return isValid;
	}
	
	// 插入流水，要求校验唯一性、插入后即可刷新
	protected void insertES(String _id,String toES) {
		IndexRequest request = new IndexRequest(ToEsFlowData.doIvcEsDbName(), ToEsFlowData.doIvcEsTableName(), _id)
		        .source(toES, XContentType.JSON)
		        .opType(DocWriteRequest.OpType.CREATE);
		try {
			request.setRefreshPolicy(WriteRequest.RefreshPolicy.IMMEDIATE);
		    IndexResponse response = highLevelClient.index(request, RequestOptions.DEFAULT);
		    log.info("插入结果{}",response);
		    log.info("成功存入{}/{}/{}", ToEsFlowData.doIvcEsDbName(), ToEsFlowData.doIvcEsTableName(), _id);
		} catch(ElasticsearchException e) {
		    if (e.status() == RestStatus.CONFLICT) {
		    	throw new BusinessException(ResultEnum.DUP_INVOICE, "订单号重复");
		    }
		    log.info("失败存入{}/{}/{}", ToEsFlowData.doIvcEsDbName(), ToEsFlowData.doIvcEsTableName(), _id);
			log.error("exception happened! detail:{}", ExceptionUtil.getMessage(e));
			throw new BusinessException(ResultEnum.UNKONW_ERROR, "ums request es save error");
		} catch (IOException e) {
			log.info("失败存入{}/{}/{}", ToEsFlowData.doIvcEsDbName(), ToEsFlowData.doIvcEsTableName(), _id);
			log.error("exception happened! detail:{}", ExceptionUtil.getMessage(e));
			throw new BusinessException(ResultEnum.UNKONW_ERROR, "ums request es save error");
		}
	}
	
	// 更新流水，只针对version=1的数据做更新
	protected void updateES(String _id,String toES) {
		UpdateRequest request = new UpdateRequest(ToEsFlowData.doIvcEsDbName(), ToEsFlowData.doIvcEsTableName(), _id)
				.doc(toES, XContentType.JSON)
				.version(1);
		try {
			request.setRefreshPolicy(WriteRequest.RefreshPolicy.IMMEDIATE);
			UpdateResponse response = highLevelClient.update(request, RequestOptions.DEFAULT);
		    log.info("更新结果{}",response);
		    log.info("成功更新{}/{}/{}", ToEsFlowData.doIvcEsDbName(), ToEsFlowData.doIvcEsTableName(), _id);
		} catch(Exception e) {
			log.info("失败更新{}/{}/{}", ToEsFlowData.doIvcEsDbName(), ToEsFlowData.doIvcEsTableName(), _id);
			log.error("exception happened! detail:{}", ExceptionUtil.getMessage(e));
			throw new BusinessException(ResultEnum.UNKONW_ERROR, "ums request es update error");
		}
	}

	protected void initValue(ToIssue toIssue, ReqIssueBean reqIssueBean) {
		toIssue.setMsgId(reqIssueBean.getMsgId());
		toIssue.setMsgSrc(paramUms.getMsgSrc());

		toIssue.setMsgType("issue");
		toIssue.setRequestTimestamp(reqIssueBean.getRequestTimestamp());
		toIssue.setSrcReserve(reqIssueBean.getSrcReserve());
		toIssue.setInvoiceMaterial(reqIssueBean.getInvoiceMaterial());
		toIssue.setInvoiceType(reqIssueBean.getInvoiceType());
		toIssue.setMerchantId(reqIssueBean.getMerchantId());
		toIssue.setTerminalId(reqIssueBean.getTerminalId());
		toIssue.setMerOrderDate(reqIssueBean.getMerOrderDate());
		toIssue.setMerOrderId(reqIssueBean.getMerOrderId());
		toIssue.setBuyerName(reqIssueBean.getBuyerName());
		toIssue.setBuyerTaxCode(reqIssueBean.getBuyerTaxCode());
		toIssue.setBuyerAddress(reqIssueBean.getBuyerAddress());
		toIssue.setBuyerTelephone(reqIssueBean.getBuyerTelephone());
		toIssue.setBuyerBank(reqIssueBean.getBuyerBank());
		toIssue.setBuyerAccount(reqIssueBean.getBuyerAccount());
		toIssue.setAmount(reqIssueBean.getAmount());
		toIssue.setDeductionAmount(reqIssueBean.getDeductionAmount());

		log.info("针对商品goodsDetail（String）做json解析，验证格式，再序列化为json -> String");
		Gson gson = new GsonBuilder().excludeFieldsWithoutExposeAnnotation().create();
		Type type = new TypeToken<ArrayList<Goods>>() {
		}.getType();
		List<Goods> goodsDetailGoods = gson.fromJson(reqIssueBean.getGoodsDetail(), type);

		toIssue.setGoodsDetail(gson.toJson(goodsDetailGoods));

		toIssue.setRemark(reqIssueBean.getRemark());
		toIssue.setNotifyMobileNo(reqIssueBean.getNotifyMobileNo());
		toIssue.setNotifyEMail(reqIssueBean.getNotifyEMail());
		toIssue.setNotifyUrl(paramUms.getBackUrl());
		toIssue.setMerWxAppId(reqIssueBean.getMerWxAppId());
		toIssue.setMerWxOrderId(reqIssueBean.getMerWxOrderId());
		toIssue.setStoreId(reqIssueBean.getStoreId());
	}

	// 解包JSON，验证签名
	protected ResIssueBean parse(String pkgJson) {
		Gson gson = new GsonBuilder().excludeFieldsWithoutExposeAnnotation().create();
		ResIssueBean resIssueBean = gson.fromJson(pkgJson, ResIssueBean.class);

		// 成功返回需要验证签名
		if (resIssueBean.getResultCode().equalsIgnoreCase("SUCCESS")) {
			Sign.checkSign(pkgJson, paramUms.getSignKey());
			resIssueBean.setRetcode(ResultEnum.SUCCESS.getCode());
			resIssueBean.setRetmsg(resIssueBean.getResultMsg());
		} else {
			throw new BusinessException(resIssueBean.getResultCode(), resIssueBean.getResultMsg());
		}
		return resIssueBean;
	}
}
