package com.ebankunion.invoice.bean;

import com.google.gson.annotations.Expose;

import lombok.Data;

@Data
public class Company {
	@Expose(serialize = true, deserialize = true)
	private String name;
	@Expose(serialize = true, deserialize = true)
	private String taxCode;
	@Expose(serialize = true, deserialize = true)
	private String address;
	@Expose(serialize = true, deserialize = true)
	private String telephone; 
	@Expose(serialize = true, deserialize = true)
	private String bank;
	@Expose(serialize = true, deserialize = true)
	private String account;
	
}
