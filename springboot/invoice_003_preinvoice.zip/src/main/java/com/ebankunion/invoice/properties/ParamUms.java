package com.ebankunion.invoice.properties;

import java.util.Map;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Data
@Component
@PropertySource("classpath:application.properties")
@ConfigurationProperties(prefix = "invoice")
public class ParamUms {
	private String signKey;
	private String msgSrc;
	private String umsAddr;
	private String backUrl;
	private String esUrl;
	private Map<String, Object> errCode;
}
