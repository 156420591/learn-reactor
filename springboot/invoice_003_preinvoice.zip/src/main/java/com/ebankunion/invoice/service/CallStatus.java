package com.ebankunion.invoice.service;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Map;

import org.elasticsearch.ElasticsearchException;
import org.elasticsearch.action.get.GetRequest;
import org.elasticsearch.action.get.GetResponse;
import org.elasticsearch.action.support.WriteRequest;
import org.elasticsearch.action.update.UpdateRequest;
import org.elasticsearch.action.update.UpdateResponse;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.common.xcontent.XContentType;
import org.elasticsearch.rest.RestStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ebankunion.invoice.bean.ReqCallStatusBean;
import com.ebankunion.invoice.bean.ResCallStatusBean;
import com.ebankunion.invoice.bean.ToEsFlowData;
import com.ebankunion.invoice.exception.CallEnum;
import com.ebankunion.invoice.exception.CallException;
import com.ebankunion.invoice.exception.ExceptionUtil;
import com.ebankunion.invoice.util.HttpClient;
import com.ebankunion.invoice.util.LogEnc;
import com.ebankunion.invoice.util.Sign;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class CallStatus {	
	@Autowired
	RestHighLevelClient highLevelClient;

	public ResCallStatusBean process(ReqCallStatusBean reqCallStatusBean) {
		ResCallStatusBean resNotifyBean = new ResCallStatusBean();
		try {
			// 查找订单及返回地址
			String _id = ToEsFlowData.getEsId(Sign.transBean2MapStr(reqCallStatusBean));
			ToEsFlowData toEsFlowData = queryES(_id);
			
			if(toEsFlowData!=null) {
				log.info("查询到es流水");
				toEsFlowData.doReqCallStatus(reqCallStatusBean);
				updateES(_id,toEsFlowData);
			}
			
			if(toEsFlowData==null || toEsFlowData.getNotifyUrl()==null) {
				log.info("查询不到回调通知地址");
				throw new CallException(CallEnum.SUCCESS, "成功");
			}else {
				// 回应给前端系统
				Map<String, String> toybsMap = initValue(reqCallStatusBean);
				HttpClient.executePost(toEsFlowData.getNotifyUrl(), toybsMap);
			}
			
			// 无论对方返回成功或失败，均一致返回给ums成功
			LocalDateTime payTime = LocalDateTime.now();
			resNotifyBean.setResponseTimestamp(payTime.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));

			resNotifyBean.setResultCode("SUCCESS");
			resNotifyBean.setResultMsg("成功");
		} catch (CallException e) {
			log.error("exception happened! detail:{}", ExceptionUtil.getMessage(e));
			throw new CallException(e.getCode(), e.getMsg());
		} catch (Exception e) {
			log.error("exception happened! detail:{}", ExceptionUtil.getMessage(e));
			throw new CallException(CallEnum.INTERNAL_ERROR, "处理报错");
		}
		return resNotifyBean;
	}

	protected ToEsFlowData queryES(String id) {
		ToEsFlowData toEsFlowData = null;
		GetRequest request = new GetRequest(ToEsFlowData.doIvcEsDbName(), ToEsFlowData.doIvcEsTableName(), id).version(1);
		try {
		    GetResponse getResponse = highLevelClient.get(request, RequestOptions.DEFAULT);
		    if (getResponse.isExists()) {
		    	log.info(LogEnc.encrypt(getResponse.toString()));
		    	String sourceAsString = getResponse.getSourceAsString();
		    	Gson gson = new GsonBuilder().excludeFieldsWithoutExposeAnnotation().create();
				toEsFlowData = gson.fromJson(sourceAsString, ToEsFlowData.class);
				log.info("成功查询{}/{}/{}", ToEsFlowData.doIvcEsDbName(), ToEsFlowData.doIvcEsTableName(), id);
		    }
		} catch (ElasticsearchException e) {
		    if (e.status() != RestStatus.NOT_FOUND) {
		    	log.info("失败查询{}/{}/{}", ToEsFlowData.doIvcEsDbName(), ToEsFlowData.doIvcEsTableName(), id);
				log.error("exception happened! detail:{}", ExceptionUtil.getMessage(e));
				throw new CallException(CallEnum.INTERNAL_ERROR, "查询订单信息失败");
		    }
		} catch (IOException e) {
			log.info("失败查询{}/{}/{}", ToEsFlowData.doIvcEsDbName(), ToEsFlowData.doIvcEsTableName(), id);
			log.error("exception happened! detail:{}", ExceptionUtil.getMessage(e));
			throw new CallException(CallEnum.INTERNAL_ERROR, "查询订单信息失败");
		}
		return toEsFlowData;
	}

	protected void updateES(String _id,ToEsFlowData toEsFlowData) {
		Gson gson = new GsonBuilder().excludeFieldsWithoutExposeAnnotation().create();
		String toES = gson.toJson(toEsFlowData);
		UpdateRequest request = new UpdateRequest(ToEsFlowData.doIvcEsDbName(), ToEsFlowData.doIvcEsTableName(), _id)
				.doc(toES, XContentType.JSON)
				.version(1);
		try {
			request.setRefreshPolicy(WriteRequest.RefreshPolicy.IMMEDIATE);
			UpdateResponse response = highLevelClient.update(request, RequestOptions.DEFAULT);
		    log.info("更新结果{}",response);
		    log.info("成功更新{}/{}/{}", ToEsFlowData.doIvcEsDbName(), ToEsFlowData.doIvcEsTableName(), _id);
		}catch(Exception e) {
			log.info("失败更新{}/{}/{}", ToEsFlowData.doIvcEsDbName(), ToEsFlowData.doIvcEsTableName(), _id);
			log.error("exception happened! detail:{}", ExceptionUtil.getMessage(e));
			throw new CallException(CallEnum.INTERNAL_ERROR, "更新订单信息失败");
		}
	}
	
	protected Map<String, String> initValue(ReqCallStatusBean reqNotifyBean) {
		Map<String, String> map = Sign.transBean2MapStr(reqNotifyBean);

		map.remove("msgSrc");
		map.remove("msgType");

		map.remove("buyerName");
		map.remove("buyerTaxCode");
		map.remove("buyerAddress");
		map.remove("buyerTelephone");
		map.remove("buyerBank");
		map.remove("buyerAccount");

		map.remove("goodsDetail");
		map.remove("notifyMobileNo");
		map.remove("notifyEmail");
		map.remove("notifyUrl");

		return map;
	}
}
