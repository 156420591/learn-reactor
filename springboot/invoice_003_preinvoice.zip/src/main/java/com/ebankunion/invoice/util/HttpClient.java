package com.ebankunion.invoice.util;

import java.io.IOException;
import java.util.Map;

import com.ebankunion.invoice.exception.BusinessException;
import com.ebankunion.invoice.exception.CallEnum;
import com.ebankunion.invoice.exception.CallException;
import com.ebankunion.invoice.exception.ResultEnum;

import lombok.extern.slf4j.Slf4j;
import okhttp3.FormBody;
import okhttp3.Interceptor;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

@Slf4j
class LoggingInterceptor implements Interceptor {
	  @Override public Response intercept(Interceptor.Chain chain) throws IOException {
	    Request request = chain.request();

	    long t1 = System.nanoTime();
	    log.info(String.format("Sending request to: %s",request.url()));
	    log.info(String.format("Sending request head: %s",request.headers().toString()));

	    Response response = chain.proceed(request);

	    long t2 = System.nanoTime();
	    log.info("Received response is ok: "+response.isSuccessful());
	    log.info(String.format("Received response for: %.1fms", (t2 - t1) / 1e6d));
	    log.info(String.format("Received response head: %s", response.headers().toString()));
	    
	    return response;
	  }
}

@Slf4j
public class HttpClient {

	// to ums
	public static String executePost(String url, String data) {
		log.info("send data:" + LogEnc.encrypt(data));
		String result = null;

		OkHttpClient httpClient = new OkHttpClient.Builder()
				.addInterceptor(new LoggingInterceptor())
			    .build();
		RequestBody requestBody = RequestBody.create(MediaType.parse("application/json;charset=UTF-8"), data);
		Request request = new Request.Builder().url(url).post(requestBody).build();
		try {
			Response response = httpClient.newCall(request).execute();
			result = response.body().string();
			log.info("recv data:"+LogEnc.encrypt(result));
		} catch (IOException e) {
			throw new BusinessException(ResultEnum.NET_ERROR);
		}
		return result;
	}

	// to ybs
	public static String executePost(String url, Map<String, String> data) {
		log.info("send data:" + LogEnc.encrypt(data.toString()));
		String result = null;

		OkHttpClient httpClient = new OkHttpClient.Builder()
				.addInterceptor(new LoggingInterceptor())
			    .build();
		// 创建表单请求参数
		FormBody.Builder builder = new FormBody.Builder();
		data.forEach((k, v) -> builder.add(k, v));

		FormBody formBody = builder.build();
		Request request = new Request.Builder().url(url).post(formBody).build();
		try {
			Response response = httpClient.newCall(request).execute();
			result = response.body().string();
			log.info("recv data:"+LogEnc.encrypt(result));
		} catch (IOException e) {
			throw new CallException(CallEnum.NET_ERROR);
		}
		return result;
	}
}
