package com.ebankunion.invoice.aspect;

import com.ebankunion.invoicep.service.PivcTrapService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
//import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
//import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
//import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.ebankunion.invoice.properties.Monitor;
import com.ebankunion.invoice.properties.ParamUms;
import com.ebankunion.invoice.util.GenSn;
import com.ebankunion.invoice.util.LogEnc;
import com.google.gson.Gson;
//import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import javax.servlet.http.HttpServletRequest;
//import java.util.Arrays;
//import java.util.UUID;

@Aspect
@Order(0)
@Component
public class WebLogAspect {
	ThreadLocal<Long> startTime = new ThreadLocal<>();
	private final Logger logger = LoggerFactory.getLogger(getClass());
	
	@Autowired
	private ParamUms paramUms;
	
	@Autowired
	private Monitor monitor;
	
	@Pointcut("execution(public * com.ebankunion.invoice.controller..*.*(..))")
	public void webLog() {
	}

//	@Before("webLog()")
//	public void doBefore(JoinPoint joinPoint) {
//		String uuid = UUID.randomUUID().toString().replace("-", "").toLowerCase();
//		MDC.put("LOG_ID", uuid);
//
//		startTime.set(System.currentTimeMillis());
//		// 接收到请求，记录请求内容
//		ServletRequestAttributes attributes = (ServletRequestAttributes) RequestContextHolder
//				.currentRequestAttributes();
//		if (attributes != null) {
//			HttpServletRequest request = attributes.getRequest();
//
//			// 记录下请求内容
//			System.out.println("\r\n");
//			logger.info("地址 : " + request.getRequestURL().toString());
//			logger.info("请求方式 : " + request.getMethod());
//			logger.info("IP : " + request.getRemoteAddr());
//			logger.info("执行的方法 : " + joinPoint.getSignature().getDeclaringTypeName() + "."
//					+ joinPoint.getSignature().getName());
//			Object[] args = joinPoint.getArgs().clone();
//			logger.info("参数 : " + Arrays.toString(args));
//		}
//	}

	/**
	 * 处理完请求，返回内容
	 * 
	 * @param ret
	 */
//	@AfterReturning(returning = "ret", pointcut = "webLog()")
//	public void doAfterReturning(Object ret) {
//		logger.info("返回内容 : " + ret.toString());
//		logger.info("花费时间 : " + (System.currentTimeMillis() - startTime.get()) + "毫秒");
//	}

	@Around("webLog()")
	public Object doAround(ProceedingJoinPoint pjp) throws Throwable {
		MDC.put("LOG_ID", GenSn.randomString(8));
		monitor.setStartTime(startTime);

		startTime.set(System.currentTimeMillis());
		// 接收到请求，记录请求内容
		ServletRequestAttributes attributes = (ServletRequestAttributes) RequestContextHolder
				.currentRequestAttributes();
		if (attributes != null) {
			HttpServletRequest request = attributes.getRequest();

			// 记录下请求内容
			System.out.println("\r\n");
			logger.info("地址 : " + request.getRequestURL().toString());
			logger.info("请求方式 : " + request.getMethod());
			logger.info("IP : " + request.getRemoteAddr());
			logger.info("执行的方法 : " + pjp.getSignature().getDeclaringTypeName() + "."
					+ pjp.getSignature().getName());
			Object[] args = pjp.getArgs().clone();
			logger.info("参数 : " + LogEnc.encrypt(args[0].toString()));

			logger.debug(LogEnc.encrypt(paramUms.toString()));
			
			Gson gson = new Gson();
			JsonObject jsonObject = new JsonParser().parse(gson.toJson(args[0])).getAsJsonObject();
			if(jsonObject!=null) {
				JsonElement jsonObjecttmp = jsonObject.get("merchantId");
				if(jsonObjecttmp!=null) { 
					monitor.setMerchantId(jsonObjecttmp.getAsString());
				}
				jsonObjecttmp = jsonObject.get("terminalId");
				if(jsonObjecttmp!=null) { 
					monitor.setTerminalId(jsonObjecttmp.getAsString());
				}
				jsonObjecttmp = jsonObject.get("merOrderId");
				if(jsonObjecttmp!=null) { 
					monitor.setMerOrderId(jsonObjecttmp.getAsString());
				}
			}
			monitor.setUriString(request.getRequestURI());
		}
		
		// result的值就是被拦截方法的返回值
		Object result = pjp.proceed();
		logger.info("返回内容 : " + LogEnc.encrypt(result.toString()));
		logger.info("花费时间 : " + (System.currentTimeMillis() - startTime.get()) + "毫秒");

		Long ssLong = System.currentTimeMillis() - startTime.get();
		MDC.put("LOG_TC", ssLong.toString() );
		
		Gson gson = new Gson();
		JsonObject jsonObject = new JsonParser().parse(gson.toJson(result)).getAsJsonObject();
		if(jsonObject!=null) {
			JsonElement jsonObjecttmp = jsonObject.get("retcode");
			if(jsonObjecttmp!=null) { 
				monitor.setRetcode(jsonObjecttmp.getAsString());
			}else {
				jsonObjecttmp = jsonObject.get("resultCode");
				if(jsonObjecttmp!=null) { 
					monitor.setRetcode(jsonObjecttmp.getAsString());
				}
			}
			jsonObjecttmp = jsonObject.get("retmsg");
			if(jsonObjecttmp!=null) {
				monitor.setRetmsg(jsonObjecttmp.getAsString());
			}else {
				jsonObjecttmp = jsonObject.get("resultMsg");
				if(jsonObjecttmp!=null) { 
					monitor.setRetmsg(jsonObjecttmp.getAsString());
				}
			}
		}
		
		monitor.log();
		return result;
	}




	@Pointcut("execution(public * com.ebankunion.invoicep.controller..*.*(..))")
	public void preinvoice() {}


	@Around("preinvoice()")
	public Object aroundPreinvoice(ProceedingJoinPoint pjp) throws Throwable {
		PivcTrapService trap = new PivcTrapService();

		Object result = trap.process(pjp);

		return result;
	}

}