package com.ebankunion.invoice.bean;

import javax.validation.constraints.NotEmpty;

import com.ebankunion.invoice.validator.DateTime;

import lombok.Data;

@Data
public class ReqQueryfuzzytitleBean {
	@NotEmpty
	private String msgId;
	@NotEmpty
	private String msgSrc;
	@NotEmpty
	@DateTime(message = "您输入的格式错误，正确的格式为：{format}", format = "yyyy-MM-dd HH:mm:ss")
	private String requestTimestamp;
	private String srcReserve;

	private String name;
	private String taxCode;
	
}
