package com.ebankunion.invoice.service;

import org.elasticsearch.action.support.WriteRequest;
import org.elasticsearch.action.update.UpdateRequest;
import org.elasticsearch.action.update.UpdateResponse;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.common.xcontent.XContentType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ebankunion.invoice.bean.ReqQueryBean;
import com.ebankunion.invoice.bean.ResIssueBean;
import com.ebankunion.invoice.bean.ToEsFlowData;
import com.ebankunion.invoice.exception.BusinessException;
import com.ebankunion.invoice.exception.ExceptionUtil;
import com.ebankunion.invoice.exception.ResultEnum;
import com.ebankunion.invoice.properties.ParamUms;
import com.ebankunion.invoice.ums.ToQuery;
import com.ebankunion.invoice.util.HttpClient;
import com.ebankunion.invoice.util.Sign;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class Query {
	@Autowired
	private ParamUms paramUms;

	@Autowired
	RestHighLevelClient highLevelClient;

	public Query(ParamUms myProperties1) {
		this.paramUms = myProperties1;
	}

	public ResIssueBean process(ReqQueryBean reqQueryBean) {
		ToQuery toQuery = new ToQuery();
		ResIssueBean resIssueBean = new ResIssueBean();

		initValue(toQuery, reqQueryBean);
		toQuery.setSign(Sign.doSign(toQuery, paramUms.getSignKey()));

		// 生成请求包
		Gson gson = new GsonBuilder().excludeFieldsWithoutExposeAnnotation().create();
		String toUms = gson.toJson(toQuery).toString();
		// 发送出去
		String fromString = HttpClient.executePost(paramUms.getUmsAddr(), toUms);

		// 接收解包
		resIssueBean = parse(fromString);

		// 响应成功时，保存数据到es
		if (isResponseValid(resIssueBean)) {
			String _id = ToEsFlowData.getEsId(Sign.transBean2MapStr(reqQueryBean));
			ToEsFlowData toEsFlowData = new ToEsFlowData();
			toEsFlowData.doIssueResponse(resIssueBean);
			updateES(_id, toEsFlowData);
		}

		return resIssueBean;
	}

	// 判断返回包是否成功
	protected boolean isResponseValid(ResIssueBean response) {
		boolean isValid = false;
		String resultCode = response.getResultCode();
		if ("SUCCESS".equalsIgnoreCase(resultCode)) {
			isValid = true;
		}

		return isValid;
	}

	// 更新流水，只针对version=1的数据做更新
		protected void updateES(String _id, ToEsFlowData toEsFlowData) {
			Gson gson = new GsonBuilder().excludeFieldsWithoutExposeAnnotation().create();
			String toES = gson.toJson(toEsFlowData);
			UpdateRequest request = new UpdateRequest(ToEsFlowData.doIvcEsDbName(), ToEsFlowData.doIvcEsTableName(), _id)
					.doc(toES, XContentType.JSON)
					.version(1);
			try {
				request.setRefreshPolicy(WriteRequest.RefreshPolicy.IMMEDIATE);
				UpdateResponse response = highLevelClient.update(request, RequestOptions.DEFAULT);
			    log.info("更新结果{}",response);
			    log.info("成功更新{}/{}/{}", ToEsFlowData.doIvcEsDbName(), ToEsFlowData.doIvcEsTableName(), _id);
			} catch(Exception e) {
				log.info("失败更新{}/{}/{}", ToEsFlowData.doIvcEsDbName(), ToEsFlowData.doIvcEsTableName(), _id);
				log.error("exception happened! detail:{}", ExceptionUtil.getMessage(e));
				throw new BusinessException(ResultEnum.UNKONW_ERROR, "ums request es update error");
			}
		}

	protected void initValue(ToQuery toQuery, ReqQueryBean reqQueryBean) {
		toQuery.setMsgId(reqQueryBean.getMsgId());
		toQuery.setMsgSrc(paramUms.getMsgSrc());

		toQuery.setMsgType("query");
		toQuery.setRequestTimestamp(reqQueryBean.getRequestTimestamp());
		toQuery.setSrcReserve(reqQueryBean.getSrcReserve());
		toQuery.setMerchantId(reqQueryBean.getMerchantId());
		toQuery.setTerminalId(reqQueryBean.getTerminalId());
		toQuery.setMerOrderDate(reqQueryBean.getMerOrderDate());
		toQuery.setMerOrderId(reqQueryBean.getMerOrderId());
	}

	// 解包JSON，验证签名
	protected ResIssueBean parse(String pkgJson) {
		Gson gson = new GsonBuilder().excludeFieldsWithoutExposeAnnotation().create();
		ResIssueBean resIssueBean = gson.fromJson(pkgJson, ResIssueBean.class);

		// 成功返回需要验证签名
		if (resIssueBean.getResultCode().equalsIgnoreCase("SUCCESS")) {
			Sign.checkSign(pkgJson, paramUms.getSignKey());
			resIssueBean.setRetcode(ResultEnum.SUCCESS.getCode());
			resIssueBean.setRetmsg(resIssueBean.getResultMsg());
		} else {
			throw new BusinessException(resIssueBean.getResultCode(), resIssueBean.getResultMsg());
		}
		return resIssueBean;
	}
}
