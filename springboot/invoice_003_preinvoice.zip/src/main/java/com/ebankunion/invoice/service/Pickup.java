package com.ebankunion.invoice.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ebankunion.invoice.bean.ReqPickupBean;
import com.ebankunion.invoice.bean.ResPickupBean;
import com.ebankunion.invoice.exception.BusinessException;
import com.ebankunion.invoice.exception.ResultEnum;
import com.ebankunion.invoice.properties.ParamUms;
import com.ebankunion.invoice.ums.ToPickup;
import com.ebankunion.invoice.util.HttpClient;
import com.ebankunion.invoice.util.Sign;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

@Component
public class Pickup {
	@Autowired
	private ParamUms paramUms;

	public Pickup(ParamUms myProperties1) {
		this.paramUms = myProperties1;
	}

	public ResPickupBean process(ReqPickupBean reqPickupBean) {
		ToPickup toPickup = new ToPickup();
		ResPickupBean resPickupBean = new ResPickupBean();

		initValue(toPickup, reqPickupBean);
		toPickup.setSign(Sign.doSign(toPickup, paramUms.getSignKey()));

		// 生成请求包
		Gson gson = new GsonBuilder().excludeFieldsWithoutExposeAnnotation().create();
		String toUms = gson.toJson(toPickup).toString();
		// 发送出去
		String fromString = HttpClient.executePost(paramUms.getUmsAddr(), toUms);

		// 接收解包
		resPickupBean = parse(fromString);

		return resPickupBean;
	}

	protected void initValue(ToPickup toPickup, ReqPickupBean reqPickupBean) {
		toPickup.setMsgId(reqPickupBean.getMsgId());
		toPickup.setMsgSrc(paramUms.getMsgSrc());

		toPickup.setMsgType("pickup");
		toPickup.setRequestTimestamp(reqPickupBean.getRequestTimestamp());
		toPickup.setSrcReserve(reqPickupBean.getSrcReserve());
		toPickup.setMerchantId(reqPickupBean.getMerchantId());
		toPickup.setTerminalId(reqPickupBean.getTerminalId());
		toPickup.setMerOrderDate(reqPickupBean.getMerOrderDate());
		toPickup.setMerOrderId(reqPickupBean.getMerOrderId());
	}

	// 解包JSON，验证签名
	protected ResPickupBean parse(String pkgJson) {
		Gson gson = new GsonBuilder().excludeFieldsWithoutExposeAnnotation().create();
		ResPickupBean resPickupBean = gson.fromJson(pkgJson, ResPickupBean.class);

		// 成功返回需要验证签名
		if (resPickupBean.getResultCode().equalsIgnoreCase("SUCCESS")) {
			Sign.checkSign(pkgJson, paramUms.getSignKey());
			resPickupBean.setRetcode(ResultEnum.SUCCESS.getCode());
			resPickupBean.setRetmsg(resPickupBean.getResultMsg());
		} else {
			throw new BusinessException(resPickupBean.getResultCode(), resPickupBean.getResultMsg());
		}
		return resPickupBean;
	}
}
