package com.ebankunion.invoice.util;

import com.ebankunion.invoice.exception.ExceptionUtil;
import com.ybs.util.Aes128;

import lombok.extern.slf4j.Slf4j;

/**
* @author 林创标  linchuangbiao@ebankunion.com
* @version 创建时间：2019年2月21日 上午10:47:07
* 类说明
*/
@Slf4j
public class LogEnc {
	public static String encrypt( String str ){
		if(log.isDebugEnabled())
			return str;
	    try {
	      if ( str == null){
	        str = "";
	      }
	      return "encrypt:"+Aes128.encrypt(str);
	    } catch (Exception e) {
	      log.error("exception happened! detail:{}", ExceptionUtil.getMessage(e));
	      return "encrypt:error";
	    }
	  }
}
