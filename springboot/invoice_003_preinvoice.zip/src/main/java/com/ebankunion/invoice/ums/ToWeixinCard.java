package com.ebankunion.invoice.ums;

import com.google.gson.annotations.Expose;

import lombok.Data;

/**
* @author 林创标  linchuangbiao@ebankunion.com
* @version 创建时间：2019年2月22日 上午9:54:50
* 类说明
*/
@Data
public class ToWeixinCard {
	@Expose(serialize = true, deserialize = true)
	private String msgId;
	@Expose(serialize = true, deserialize = true)
	private String msgSrc;
	@Expose(serialize = true, deserialize = true)
	private String msgType;
	@Expose(serialize = true, deserialize = true)
	private String requestTimestamp;
	@Expose(serialize = true, deserialize = true)
	private String srcReserve;

	@Expose(serialize = true, deserialize = true)
	private String merchantId;
	@Expose(serialize = true, deserialize = true)
	private String terminalId;
	@Expose(serialize = true, deserialize = true)
	private String merOrderId;
	@Expose(serialize = true, deserialize = true)
	private String merOrderDate;
	@Expose(serialize = true, deserialize = true)
	private String source;
	@Expose(serialize = true, deserialize = true)
	private String invoiceNo;
	@Expose(serialize = true, deserialize = true)
	private String invoiceCode;

	@Expose(serialize = true, deserialize = true)
	private String sign;
}
