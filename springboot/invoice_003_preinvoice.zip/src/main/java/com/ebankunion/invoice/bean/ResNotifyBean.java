package com.ebankunion.invoice.bean;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.google.gson.annotations.Expose;

import lombok.Data;

/**
* @author 林创标  linchuangbiao@ebankunion.com
* @version 创建时间：2019年2月14日 下午5:34:07
* 类说明
*/
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(value = {"msgSrc","msgType","resultCode","resultMsg"})
public class ResNotifyBean {
	@Expose(serialize = false, deserialize = true)
	private String msgId;
	@Expose(serialize = false, deserialize = true)
	private String msgSrc; 
	@Expose(serialize = false, deserialize = true)
	private String msgType; 
	@Expose(serialize = false, deserialize = true)
	private String resultCode; 
	@Expose(serialize = false, deserialize = true)
	private String resultMsg;
	@Expose(serialize = false, deserialize = false)
	private String retcode;
	@Expose(serialize = false, deserialize = false)
	private String retmsg;
	@Expose(serialize = false, deserialize = true)
	private String responseTimestamp;
	@Expose(serialize = false, deserialize = true)
	private String srcReserve;
	@Expose(serialize = false, deserialize = true)
	private String sign;
}
