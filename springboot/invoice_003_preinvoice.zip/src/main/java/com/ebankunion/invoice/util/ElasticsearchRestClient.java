package com.ebankunion.invoice.util;

import java.util.Arrays;
import java.util.Objects;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpHost;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.nio.client.HttpAsyncClientBuilder;
import org.elasticsearch.client.RestClient;
import org.elasticsearch.client.RestClientBuilder;
import org.elasticsearch.client.RestClientBuilder.HttpClientConfigCallback;
import org.elasticsearch.client.RestHighLevelClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import lombok.extern.slf4j.Slf4j;

import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;

import org.apache.http.ssl.SSLContextBuilder;
import org.apache.http.ssl.TrustStrategy;


/**
* @author 林创标  linchuangbiao@ebankunion.com
* @version 创建时间：2019年2月26日 下午1:03:51
* 类说明
*/
@Slf4j
@Configuration
public class ElasticsearchRestClient {
    private static final int ADDRESS_LENGTH = 2;
    private static final String HTTP_SCHEME = "https";

    /**
     * 使用冒号隔开ip和端口1
     */
    @Value("${invoice.esUrl}")
    String[] ipAddress;

    @Value("${invoice.esUser}")
    String esUser;
    
    @Value("${invoice.esUserPasswd}")
    String esUserPasswd;
    
    @Bean
    public RestClientBuilder restClientBuilder() throws KeyManagementException, NoSuchAlgorithmException, KeyStoreException {
    	log.info(Arrays.toString(ipAddress));
        HttpHost[] hosts = Arrays.stream(ipAddress)
                .map(this::makeHttpHost)
                .filter(Objects::nonNull)
                .toArray(HttpHost[]::new);
        log.debug("hosts:{}", Arrays.toString(hosts));
        
        // 支持单向认证，忽略证书
        final CredentialsProvider credentialsProvider =
        	    new BasicCredentialsProvider();
        	credentialsProvider.setCredentials(AuthScope.ANY,
        	    new UsernamePasswordCredentials(esUser, esUserPasswd));

        	SSLContext sslContext = new SSLContextBuilder().loadTrustMaterial(null, new TrustStrategy()
			{
				// 信任所有
				public boolean isTrusted(X509Certificate[] chain, String authType) throws CertificateException 
				{
					return true;
				}
			}).build();

        	
        return RestClient.builder(hosts)
        		.setHttpClientConfigCallback(new HttpClientConfigCallback() {
	            @Override
	            public HttpAsyncClientBuilder customizeHttpClient(
	                    HttpAsyncClientBuilder httpClientBuilder) {
	                return httpClientBuilder
	                    .setDefaultCredentialsProvider(credentialsProvider)
	                    .setSSLContext(sslContext)
	                    .setSSLHostnameVerifier(new HostnameVerifier() {
	                        @Override
	                        public boolean verify(String hostname, SSLSession session) {
	                            return true; // 不检查证书和域名是否匹配
	                        }
	                    });
	            }
        });
    }


    @Bean(name = "highLevelClient")
    public RestHighLevelClient highLevelClient(@Autowired RestClientBuilder restClientBuilder) {
        restClientBuilder.setMaxRetryTimeoutMillis(60000);
        return new RestHighLevelClient(restClientBuilder);
    }


    private HttpHost makeHttpHost(String s) {
        assert StringUtils.isNotEmpty(s);
        String[] address = s.split(":");
        if (address.length == ADDRESS_LENGTH) {
            String ip = address[0];
            int port = Integer.parseInt(address[1]);
            return new HttpHost(ip, port, HTTP_SCHEME);
        } else {
            return null;
        }
    }
}
