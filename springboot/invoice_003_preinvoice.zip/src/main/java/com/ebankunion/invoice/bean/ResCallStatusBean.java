package com.ebankunion.invoice.bean;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ResCallStatusBean {
	private String resultCode; 
	private String resultMsg;
	private String responseTimestamp;
}
