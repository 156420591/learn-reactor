package com.ebankunion.invoice.controller;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ebankunion.invoice.bean.ReqIssueBean;
import com.ebankunion.invoice.bean.ReqNotifyBean;
import com.ebankunion.invoice.bean.ReqCallStatusBean;
import com.ebankunion.invoice.bean.ReqPickupBean;
import com.ebankunion.invoice.bean.ReqQueryBean;
import com.ebankunion.invoice.bean.ReqQueryfuzzytitleBean;
import com.ebankunion.invoice.bean.ReqReverseBean;
import com.ebankunion.invoice.bean.ReqWeixinCardBean;
import com.ebankunion.invoice.bean.ResIssueBean;
import com.ebankunion.invoice.bean.ResNotifyBean;
import com.ebankunion.invoice.bean.ResCallStatusBean;
import com.ebankunion.invoice.bean.ResPickupBean;
import com.ebankunion.invoice.bean.ResQueryfuzzytitleBean;
import com.ebankunion.invoice.bean.ResWeixinCardBean;
import com.ebankunion.invoice.exception.BusinessException;
import com.ebankunion.invoice.exception.CallEnum;
import com.ebankunion.invoice.exception.CallException;
import com.ebankunion.invoice.exception.ResultEnum;
import com.ebankunion.invoice.properties.Monitor;
import com.ebankunion.invoice.service.Issue;
import com.ebankunion.invoice.service.Notify;
import com.ebankunion.invoice.service.Pickup;
import com.ebankunion.invoice.service.Queryfuzzytitle;
import com.ebankunion.invoice.service.Reverse;
import com.ebankunion.invoice.service.WeixinnCard;

@RestController
@RequestMapping(value = "/invoice")
public class Invoice {
	private final Logger logger = LoggerFactory.getLogger(getClass());
    
	@Autowired
	Issue issue;
	@Autowired
	com.ebankunion.invoice.service.Query iquery;
	@Autowired
	com.ebankunion.invoice.service.CallStatus callStatus;
	@Autowired
	Queryfuzzytitle queryfuzzytitle;
	@Autowired
	Pickup pickup;
	@Autowired
	Reverse reverse;
	@Autowired
	Notify notify;
	@Autowired
	WeixinnCard WeixinnCard;
	
	@Autowired
	Monitor monitor;
	
	@RequestMapping(value = "/issue", method = RequestMethod.POST)
    public ResIssueBean issue(@Valid ReqIssueBean reqIssueBean, BindingResult bindingResult) {
		monitor.setMsgId( reqIssueBean.getMsgId());
		monitor.setSrcReserve ( reqIssueBean.getSrcReserve());
		if (bindingResult.hasErrors()){ 
			//            获取错误信息，并打印 
			logger.info(bindingResult.getFieldError().getField()+":"+bindingResult.getFieldError().getDefaultMessage()); 
			//            禁止其继续执行
			throw new BusinessException(ResultEnum.BAD_REQUEST,bindingResult.getFieldError().getField()+":"+bindingResult.getFieldError().getDefaultMessage());
		}

		return issue.process(reqIssueBean);
    }
	
	@RequestMapping(value = "/query", method = RequestMethod.POST)
    public ResIssueBean query(@Valid ReqQueryBean reqQueryBean, BindingResult bindingResult) {
		monitor.setMsgId( reqQueryBean.getMsgId());
		monitor.setSrcReserve ( reqQueryBean.getSrcReserve());
		if (bindingResult.hasErrors()){ 
			//            获取错误信息，并打印 
			logger.info(bindingResult.getFieldError().getField()+":"+bindingResult.getFieldError().getDefaultMessage()); 
			//            禁止其继续执行
			throw new BusinessException(ResultEnum.BAD_REQUEST,bindingResult.getFieldError().getField()+":"+bindingResult.getFieldError().getDefaultMessage());
		}
		return iquery.process(reqQueryBean);
    }
	
	@RequestMapping(value = "/callstatus", method = RequestMethod.POST)
    public ResCallStatusBean callstatus(@RequestBody @Valid ReqCallStatusBean reqNotifyBean, BindingResult bindingResult) {
	
		if (bindingResult.hasErrors()){ 
			//            获取错误信息，并打印 
			logger.info(bindingResult.getFieldError().getField()+":"+bindingResult.getFieldError().getDefaultMessage()); 
			//            禁止其继续执行
			throw new CallException(CallEnum.BAD_REQUEST,bindingResult.getFieldError().getField()+":"+bindingResult.getFieldError().getDefaultMessage());
		}
		return callStatus.process(reqNotifyBean);
    }
	
	@RequestMapping(value = "/queryfuzzytitle", method = RequestMethod.POST)
	public ResQueryfuzzytitleBean queryfuzzytitle(@Valid ReqQueryfuzzytitleBean reqQueryfuzzytitleBean, BindingResult bindingResult) {
		monitor.setMsgId( reqQueryfuzzytitleBean.getMsgId());
		monitor.setSrcReserve ( reqQueryfuzzytitleBean.getSrcReserve());
		if (bindingResult.hasErrors()){ 
			//            获取错误信息，并打印 
			logger.info(bindingResult.getFieldError().getField()+":"+bindingResult.getFieldError().getDefaultMessage()); 
			//            禁止其继续执行
			throw new BusinessException(ResultEnum.BAD_REQUEST,bindingResult.getFieldError().getField()+":"+bindingResult.getFieldError().getDefaultMessage()); 
		}
		
		return queryfuzzytitle.process(reqQueryfuzzytitleBean);
    }
	
	@RequestMapping(value = "/pickup", method = RequestMethod.POST)
	public ResPickupBean pickup(@Valid ReqPickupBean reqPickupBean, BindingResult bindingResult) {
		monitor.setMsgId( reqPickupBean.getMsgId());
		monitor.setSrcReserve ( reqPickupBean.getSrcReserve());
		if (bindingResult.hasErrors()){ 
			//            获取错误信息，并打印 
			logger.info(bindingResult.getFieldError().getField()+":"+bindingResult.getFieldError().getDefaultMessage()); 
			//            禁止其继续执行
			throw new BusinessException(ResultEnum.BAD_REQUEST,bindingResult.getFieldError().getField()+":"+bindingResult.getFieldError().getDefaultMessage());
		}

		return pickup.process(reqPickupBean);
    }
	
	@RequestMapping(value = "/reverse", method = RequestMethod.POST)
	public  ResIssueBean reverse(@Valid ReqReverseBean reqReverseBean, BindingResult bindingResult) {
		monitor.setMsgId( reqReverseBean.getMsgId());
		monitor.setSrcReserve ( reqReverseBean.getSrcReserve());
		if (bindingResult.hasErrors()){ 
			//            获取错误信息，并打印 
			logger.info(bindingResult.getFieldError().getField()+":"+bindingResult.getFieldError().getDefaultMessage()); 
			//            禁止其继续执行
			throw new BusinessException(ResultEnum.BAD_REQUEST,bindingResult.getFieldError().getField()+":"+bindingResult.getFieldError().getDefaultMessage());
		}
		
		return reverse.process(reqReverseBean);
    }
	
	@RequestMapping(value = "/notify", method = RequestMethod.POST)
	public  ResNotifyBean notify(@Valid ReqNotifyBean reqNotifyBean, BindingResult bindingResult) {
		monitor.setMsgId( reqNotifyBean.getMsgId());
		monitor.setSrcReserve ( reqNotifyBean.getSrcReserve());
		if (bindingResult.hasErrors()){ 
			//            获取错误信息，并打印 
			logger.info(bindingResult.getFieldError().getField()+":"+bindingResult.getFieldError().getDefaultMessage()); 
			//            禁止其继续执行
			throw new BusinessException(ResultEnum.BAD_REQUEST,bindingResult.getFieldError().getField()+":"+bindingResult.getFieldError().getDefaultMessage());
		}
		
		return notify.process(reqNotifyBean);
    }
	
	@RequestMapping(value = "/weixincard", method = RequestMethod.POST)
	public ResWeixinCardBean weixincard(@Valid ReqWeixinCardBean reqWeixinCardBean, BindingResult bindingResult) {
		monitor.setMsgId( reqWeixinCardBean.getMsgId());
		monitor.setSrcReserve ( reqWeixinCardBean.getSrcReserve());
		if (bindingResult.hasErrors()){ 
			//            获取错误信息，并打印 
			logger.info(bindingResult.getFieldError().getField()+":"+bindingResult.getFieldError().getDefaultMessage()); 
			//            禁止其继续执行
			throw new BusinessException(ResultEnum.BAD_REQUEST,bindingResult.getFieldError().getField()+":"+bindingResult.getFieldError().getDefaultMessage());
		}

		return WeixinnCard.process(reqWeixinCardBean);
    }
}
