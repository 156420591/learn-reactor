package com.ebankunion.invoice.bean;

import javax.validation.constraints.NotEmpty;

import org.hibernate.validator.constraints.Length;

import com.ebankunion.invoice.validator.DateTime;

import lombok.Data;

@Data
public class ReqIssueBean {
	@NotEmpty
	private String msgId;
	@NotEmpty
	private String msgSrc;
	@NotEmpty
	@DateTime(message = "您输入的格式错误，正确的格式为：{format}", format = "yyyy-MM-dd HH:mm:ss")
	private String requestTimestamp; 
	private String srcReserve;
	@NotEmpty
	private String invoiceMaterial;
	@NotEmpty
	private String invoiceType;
	@NotEmpty
	@Length(min = 15, max = 15, message = "长度必须是{min}")
	private String merchantId;
	@NotEmpty
	@Length(min = 8, max = 8, message = "长度必须是{min}")
	private String terminalId;
	@NotEmpty
	@DateTime(message = "您输入的格式错误，正确的格式为：{format}", format = "yyyyMMdd")
	private String merOrderDate;
	@NotEmpty
	private String merOrderId;
	@NotEmpty
	private String buyerName;
	private String buyerTaxCode;
	private String buyerAddress;
	private String buyerTelephone;
	private String buyerBank;
	private String buyerAccount;
	@NotEmpty
	private String amount;
	private String deductionAmount;
	private String goodsDetail;
	private String remark;
	private String notifyMobileNo;
	private String notifyEMail;
	private String notifyUrl;
	private String merWxAppId;
	private String merWxOrderId;
	private String storeId;
	
}
