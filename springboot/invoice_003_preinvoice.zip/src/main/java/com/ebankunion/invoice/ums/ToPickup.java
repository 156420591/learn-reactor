package com.ebankunion.invoice.ums;

import com.google.gson.annotations.Expose;

import lombok.Data;

@Data
public class ToPickup {
	@Expose(serialize = true, deserialize = true)
	private String msgId;
	@Expose(serialize = true, deserialize = true)
	private String msgSrc;
	@Expose(serialize = true, deserialize = true)
	private String msgType;
	@Expose(serialize = true, deserialize = true)
	private String requestTimestamp;
	@Expose(serialize = true, deserialize = true)
	private String srcReserve;

	@Expose(serialize = true, deserialize = true)
	private String merchantId;
	@Expose(serialize = true, deserialize = true)
	private String terminalId;
	@Expose(serialize = true, deserialize = true)
	private String merOrderId;
	@Expose(serialize = true, deserialize = true)
	private String merOrderDate;
	@Expose(serialize = true, deserialize = true)
	private String sign;
}
