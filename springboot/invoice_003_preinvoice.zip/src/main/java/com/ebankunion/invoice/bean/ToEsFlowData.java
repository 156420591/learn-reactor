package com.ebankunion.invoice.bean;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Map;

import com.google.gson.annotations.Expose;

import lombok.Data;

/**
* @author 林创标  linchuangbiao@ebankunion.com
* @version 创建时间：2019年2月25日 下午4:15:27
* 类说明
*/
@Data
public class ToEsFlowData {
	@Expose(serialize = true, deserialize = true)
	public String msgId;
	@Expose(serialize = true, deserialize = true)
	public String msgSrc;
	@Expose(serialize = true, deserialize = true)
	public String requestTimestamp;
	@Expose(serialize = true, deserialize = true)
	public String srcReserve;
	@Expose(serialize = true, deserialize = true)
	public String invoiceMaterial;
	@Expose(serialize = true, deserialize = true)
	public String invoiceType;
	@Expose(serialize = true, deserialize = true)
	public String merchantId;
	@Expose(serialize = true, deserialize = true)
	public String terminalId;
	@Expose(serialize = true, deserialize = true)
	public String merOrderDate;
	@Expose(serialize = true, deserialize = true)
	public String merOrderId;
	@Expose(serialize = true, deserialize = true)
	public String buyerName;
	@Expose(serialize = true, deserialize = true)
	public String buyerTaxCode;
	@Expose(serialize = true, deserialize = true)
	public String buyerAddress;
	@Expose(serialize = true, deserialize = true)
	public String buyerTelephone;
	@Expose(serialize = true, deserialize = true)
	public String buyerBank;
	@Expose(serialize = true, deserialize = true)
	public String buyerAccount;
	@Expose(serialize = true, deserialize = true)
	public String amount;
	@Expose(serialize = true, deserialize = true)
	public String deductionAmount;
	@Expose(serialize = true, deserialize = true)
	public String goodsDetail;
	@Expose(serialize = true, deserialize = true)
	public String remark;
	@Expose(serialize = true, deserialize = true)
	public String notifyMobileNo;
	@Expose(serialize = true, deserialize = true)
	public String notifyEMail;
	@Expose(serialize = true, deserialize = true)
	public String notifyUrl;
	@Expose(serialize = true, deserialize = true)
	public String storeId;
	@Expose(serialize = true, deserialize = true)
	public String status;
	
	@Expose(serialize = true, deserialize = true)
	public String responseTimestamp;
	@Expose(serialize = true, deserialize = true)
	public String invoiceNo;
	@Expose(serialize = true, deserialize = true)
	public String invoiceCode;
	@Expose(serialize = true, deserialize = true)
	public String checkCode;
	@Expose(serialize = true, deserialize = true)
	public String cipherCode;
	@Expose(serialize = true, deserialize = true)
	public String issueDate;
	@Expose(serialize = true, deserialize = true)
	public String deviceNo;
	@Expose(serialize = true, deserialize = true)
	public String qrCodeId;
	@Expose(serialize = true, deserialize = true)
	public String storeName;
	@Expose(serialize = true, deserialize = true)
	public String merchantName;
	@Expose(serialize = true, deserialize = true)
	public String sellerName;
	@Expose(serialize = true, deserialize = true)
	public String sellerTaxCode;
	@Expose(serialize = true, deserialize = true)
	public String sellerAddress;
	@Expose(serialize = true, deserialize = true)
	public String sellerTelephone;
	@Expose(serialize = true, deserialize = true)
	public String sellerBank;
	@Expose(serialize = true, deserialize = true)
	public String sellerAccount;
	@Expose(serialize = true, deserialize = true)
	public String payee;
	@Expose(serialize = true, deserialize = true)
	public String checker;
	@Expose(serialize = true, deserialize = true)
	public String drawer;
	@Expose(serialize = true, deserialize = true)
	public String taxMethod;
	@Expose(serialize = true, deserialize = true)
	public String totalPriceIncludingTax;
	@Expose(serialize = true, deserialize = true)
	public String totalTax;
	@Expose(serialize = true, deserialize = true)
	public String totalPrice;
	@Expose(serialize = true, deserialize = true)
	public String notifyMerEmail;
	@Expose(serialize = true, deserialize = true)
	public String qrCode;
	@Expose(serialize = true, deserialize = true)
	public String pdfUrl;
	@Expose(serialize = true, deserialize = true)
	public String pdfPreviewUrl;

	public static String doIvcEsDbName() {
		return "ips";
	}
	
	public static String doIvcEsTableName() {
		return "invoice";
	}
	
	public static String getEsId( Map<String, String> mapbean) {
		String eskey = String.format("%s_%s_%s", 
				String.valueOf(mapbean.get("merchantId")),
				String.valueOf(mapbean.get("merOrderId")),
				String.valueOf(mapbean.get("merOrderDate"))
				);

		return eskey;
	}
	
	public void doIssueRequest(ReqIssueBean obj) {
				msgId = obj.getMsgId();
				msgSrc = obj.getMsgSrc();
				requestTimestamp = obj.getRequestTimestamp();
				srcReserve = obj.getSrcReserve();
				invoiceMaterial = obj.getInvoiceMaterial();
				invoiceType = obj.getInvoiceType();
				merchantId = obj.getMerchantId();
				terminalId = obj.getTerminalId();
				merOrderDate = obj.getMerOrderDate();
				merOrderId = obj.getMerOrderId();
				buyerName = obj.getBuyerName();
				buyerTaxCode = obj.getBuyerTaxCode();
				buyerAddress = obj.getBuyerAddress();
				buyerTelephone = obj.getBuyerTelephone();
				buyerBank = obj.getBuyerBank();
				buyerAccount = obj.getBuyerAccount();
				amount = obj.getAmount();
				deductionAmount = obj.getDeductionAmount();
				goodsDetail = obj.getGoodsDetail();
				remark = obj.getRemark();
				notifyMobileNo = obj.getNotifyMobileNo();
				notifyEMail = obj.getNotifyEMail();
				notifyUrl = obj.getNotifyUrl();
				storeId = obj.getStoreId();
				status = "ISSUING";
	}
	
	public void doIssueResponse(ResIssueBean obj) {
				responseTimestamp = obj.getResponseTimestamp();
				status = obj.getStatus();
				invoiceNo = obj.getInvoiceNo();
				invoiceCode = obj.getInvoiceCode();
				checkCode = obj.getCheckCode();
				cipherCode = obj.getCipherCode();
				issueDate = obj.getIssueDate();
				deviceNo = obj.getDeviceNo();
				qrCodeId = obj.getQrCode();
				storeId = obj.getStoreId();
				storeName = obj.getStoreName();
				merchantName = obj.getMerchantName();
				sellerName = obj.getSellerName();
				sellerTaxCode = obj.getSellerTaxCode();
				sellerAddress = obj.getSellerAddress();
				sellerTelephone = obj.getSellerTelephone();
				sellerBank = obj.getSellerBank();
				sellerAccount = obj.getSellerAccount();
				payee = obj.getPayee();
				checker = obj.getChecker();
				drawer = obj.getDrawer();
				taxMethod = obj.getTaxMethod();
				totalPriceIncludingTax = obj.getTotalPriceIncludingTax();
				totalTax = obj.getTotalTax();
				totalPrice = obj.getTotalPrice();
				notifyMerEmail = obj.getNotifyMerEmail();
				qrCode = obj.getQrCode();
				pdfUrl = obj.getPdfUrl();
				pdfPreviewUrl = obj.getPdfPreviewUrl();
	}
	
	public void doReqCallStatus(ReqCallStatusBean obj) {
		LocalDateTime payTime = LocalDateTime.now();
		responseTimestamp = payTime.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
		status = obj.getStatus();
		invoiceNo = obj.getInvoiceNo();
		invoiceCode = obj.getInvoiceCode();
		checkCode = obj.getCheckCode();
		cipherCode = obj.getCipherCode();
		issueDate = obj.getIssueDate();
		deviceNo = obj.getDeviceNo();
		qrCodeId = obj.getQrCode();
		storeId = obj.getStoreId();
		storeName = obj.getStoreName();
		merchantName = obj.getMerchantName();
		sellerName = obj.getSellerName();
		sellerTaxCode = obj.getSellerTaxCode();
		sellerAddress = obj.getSellerAddress();
		sellerTelephone = obj.getSellerTelephone();
		sellerBank = obj.getSellerBank();
		sellerAccount = obj.getSellerAccount();
		payee = obj.getPayee();
		checker = obj.getChecker();
		drawer = obj.getDrawer();
		taxMethod = obj.getTaxMethod();
		totalPriceIncludingTax = obj.getTotalPriceIncludingTax();
		totalTax = obj.getTotalTax();
		totalPrice = obj.getTotalPrice();
		notifyMerEmail = obj.getNotifyMerEmail();
		qrCode = obj.getQrCode();
		pdfUrl = obj.getPdfUrl();
		pdfPreviewUrl = obj.getPdfPreviewUrl();
	}
}
