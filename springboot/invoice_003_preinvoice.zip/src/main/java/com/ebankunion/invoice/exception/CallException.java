package com.ebankunion.invoice.exception;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;

/**
* @author 林创标  linchuangbiao@ebankunion.com
* @version 创建时间：2019年2月14日 上午10:12:07
* 类说明
*/

@Slf4j
@Data
public class CallException extends RuntimeException {
	private static final long serialVersionUID = 1L;
	
	private String msg;   //错误信息
	private String code;  //错误码

	public CallException(CallEnum resultEnum) {
		super();
		
		this.code = resultEnum.getCode();
		this.msg = resultEnum.getMsg();
	}
	
	public CallException(CallEnum resultEnum,String msg) {
		super();
		
		this.code = resultEnum.getCode();
		this.msg = msg;
	}
	
	// 商户返回错误码
	public CallException(String code,String msg) {
		super();
		
		if(code==null) {
			log.info("商户未定义错误:"+code);
			this.code = CallEnum.INTERNAL_ERROR.getCode();
			if(msg==null) {
				this.msg = CallEnum.INTERNAL_ERROR.getMsg();
			}else {
				this.msg = msg;
			}
		}else {
			CallEnum resultEnum = null;
			try {
				resultEnum = Enum.valueOf(CallEnum.class, code);
		    } catch (Exception ex) {
		    	log.error("exception happened! detail:{}", ExceptionUtil.getMessage(ex));
		    	log.info("商户错误码未找到定义:"+code);
		    	resultEnum = CallEnum.INTERNAL_ERROR;
		    }
			
			this.code = resultEnum.getCode();
			
			if(msg==null) {
				this.msg = resultEnum.getMsg();
			}else {
				this.msg = msg;
			}
		}
	}
}
