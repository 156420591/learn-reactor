package com.ebankunion.invoice.bean;


import javax.validation.constraints.NotEmpty;
import org.hibernate.validator.constraints.Length;
import com.ebankunion.invoice.validator.DateTime;
import lombok.Data;

@Data
public class ReqCallStatusBean {
	@NotEmpty
	private String status;
	@NotEmpty
	private String merchantName ;
	@NotEmpty
	@Length(min = 15, max = 15, message = "长度必须是{min}")
	private String merchantId ;
	@NotEmpty
	@Length(min = 8, max = 8, message = "长度必须是{min}")
	private String terminalId ;
	@NotEmpty
	private String merOrderId ;
	@NotEmpty
	@DateTime(message = "您输入的格式错误，正确的格式为：{format}", format = "yyyyMMdd")
	private String merOrderDate ;
	@NotEmpty
	private String qrCodeId ;
	
	@NotEmpty
	private String invoiceMaterial;
	@NotEmpty
	private String invoiceType;
	private String invoiceNo;
	private String invoiceCode;
	private String checkCode;
	private String cipherCode;
	private String issueDate;
	
	private String reverseInvoiceNo ;
	private String reverseInvoiceCode ;
	private String reverseCheckCode ;
	private String reverseCipherCode ;
	private String reverseDate ;
	
	private String deviceNo;
	private String storeId;
	private String storeName;
	private String buyerName;
	private String buyerTaxCode;
	private String buyerAddress;
	private String buyerTelephone;
	private String buyerBank;
	private String buyerAccount;
	@NotEmpty
	private String sellerName;
	@NotEmpty
	private String sellerTaxCode;
	@NotEmpty
	private String sellerAddress;
	@NotEmpty
	private String sellerTelephone;
	@NotEmpty
	private String sellerBank;
	@NotEmpty
	private String sellerAccount;
	@NotEmpty
	private String payee;
	@NotEmpty
	private String checker;
	@NotEmpty
	private String drawer;
	private String remark;
	@NotEmpty
	private String taxMethod;
	@NotEmpty
	private String deductionAmount;
	@NotEmpty
	private String totalPriceIncludingTax;
	@NotEmpty
	private String totalTax;
	@NotEmpty
	private String totalPrice;
	@NotEmpty
	private String goodsDetail;
	private String notifyMobileNo;
	private String notifyEmail;
	private String notifyUrl;
	private String notifyMerEmail;
	private String qrCode;
	private String pdfUrl;
	private String pdfPreviewUrl;
	private String errMsg;
}
