package com.ebankunion.invoice.bean;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.google.gson.annotations.Expose;

import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(value = {"msgSrc","msgType","resultCode","resultMsg"})
public class ResIssueBean {
	@Expose(serialize = false, deserialize = true)
	private String msgId;
	@Expose(serialize = false, deserialize = true)
	private String msgSrc; 
	@Expose(serialize = false, deserialize = true)
	private String msgType; 
	@Expose(serialize = false, deserialize = true)
	private String resultCode; 
	@Expose(serialize = false, deserialize = true)
	private String resultMsg;
	@Expose(serialize = false, deserialize = false)
	private String retcode;
	@Expose(serialize = false, deserialize = false)
	private String retmsg;
	@Expose(serialize = false, deserialize = true)
	private String responseTimestamp;
	@Expose(serialize = false, deserialize = true)
	private String srcReserve;
	@Expose(serialize = false, deserialize = true)
	private String status;
	@Expose(serialize = false, deserialize = true)
	private String invoiceMaterial;
	@Expose(serialize = false, deserialize = true)
	private String invoiceType;
	@Expose(serialize = false, deserialize = true)
	private String invoiceNo;
	@Expose(serialize = false, deserialize = true)
	private String invoiceCode;
	@Expose(serialize = false, deserialize = true)
	private String checkCode;
	@Expose(serialize = false, deserialize = true)
	private String cipherCode;
	@Expose(serialize = false, deserialize = true)
	private String issueDate;
	@Expose(serialize = false, deserialize = true)
	private String deviceNo;
	@Expose(serialize = false, deserialize = true)
	private String qrCodeId;
	@Expose(serialize = false, deserialize = true)
	private String storeId;
	@Expose(serialize = false, deserialize = true)
	private String storeName;
	@Expose(serialize = false, deserialize = true)
	private String merchantName;
	@Expose(serialize = false, deserialize = true)
	private String merchantId;
	@Expose(serialize = false, deserialize = true)
	private String terminalId;
	@Expose(serialize = false, deserialize = true)
	private String merOrderId;
	@Expose(serialize = false, deserialize = true)
	private String merOrderDate;
//	@Expose(serialize = false, deserialize = true)
//	private String buyerName;
//	@Expose(serialize = false, deserialize = true)
//	private String buyerTaxCode;
//	@Expose(serialize = false, deserialize = true)
//	private String buyerAddress;
//	@Expose(serialize = false, deserialize = true)
//	private String buyerTelephone;
//	@Expose(serialize = false, deserialize = true)
//	private String buyerBank;
//	@Expose(serialize = false, deserialize = true)
//	private String buyerAccount;
	@Expose(serialize = false, deserialize = true)
	private String sellerName;
	@Expose(serialize = false, deserialize = true)
	private String sellerTaxCode;
	@Expose(serialize = false, deserialize = true)
	private String sellerAddress;
	@Expose(serialize = false, deserialize = true)
	private String sellerTelephone;
	@Expose(serialize = false, deserialize = true)
	private String sellerBank;
	@Expose(serialize = false, deserialize = true)
	private String sellerAccount;
	@Expose(serialize = false, deserialize = true)
	private String payee;
	@Expose(serialize = false, deserialize = true)
	private String checker;
	@Expose(serialize = false, deserialize = true)
	private String drawer;
	@Expose(serialize = false, deserialize = true)
	private String remark;
	@Expose(serialize = false, deserialize = true)
	private String taxMethod;
	@Expose(serialize = false, deserialize = true)
	private String deductionAmount;
	@Expose(serialize = false, deserialize = true)
	private String totalPriceIncludingTax;
	@Expose(serialize = false, deserialize = true)
	private String totalTax;
	@Expose(serialize = false, deserialize = true)
	private String totalPrice;
//	@Expose(serialize = false, deserialize = true)
//	private String goodsDetail;
//	@Expose(serialize = false, deserialize = true)
//	private String notifyMobileNo;
//	@Expose(serialize = false, deserialize = true)
//	private String notifyEmail;
//	@Expose(serialize = false, deserialize = true)
//	private String notifyUrl;
	@Expose(serialize = false, deserialize = true)
	private String notifyMerEmail;
	@Expose(serialize = false, deserialize = true)
	private String qrCode;
	@Expose(serialize = false, deserialize = true)
	private String pdfUrl;
	@Expose(serialize = false, deserialize = true)
	private String pdfPreviewUrl;
	@Expose(serialize = false, deserialize = true)
	private String errMsg;
	@Expose(serialize = false, deserialize = true)
	private String sign;
	
}
