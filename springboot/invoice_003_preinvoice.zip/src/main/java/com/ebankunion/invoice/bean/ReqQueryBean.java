package com.ebankunion.invoice.bean;

import javax.validation.constraints.NotEmpty;

import org.hibernate.validator.constraints.Length;

import com.ebankunion.invoice.validator.DateTime;

import lombok.Data;

@Data
public class ReqQueryBean {
	@NotEmpty
	private String msgId;
	@NotEmpty
	private String msgSrc;
	@NotEmpty
	@DateTime(message = "您输入的格式错误，正确的格式为：{format}", format = "yyyy-MM-dd HH:mm:ss")
	private String requestTimestamp; 
	private String srcReserve ;
	@NotEmpty
	@Length(min = 15, max = 15, message = "长度必须是{min}")
	private String merchantId ;
	@NotEmpty
	@Length(min = 8, max = 8, message = "长度必须是{min}")
	private String terminalId ;
	@NotEmpty
	private String merOrderId;
	@NotEmpty
	@DateTime(message = "您输入的格式错误，正确的格式为：{format}", format = "yyyyMMdd")
	private String merOrderDate;
	
}
