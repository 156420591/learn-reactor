package com.ebankunion.invoice.exception;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;

import com.ebankunion.invoicep.exception.PivcException;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ebankunion.invoice.properties.Monitor;
import lombok.extern.slf4j.Slf4j;


/**
 * 全局捕获异常类，只要作用在@RequestMapping上，所有的异常都会被捕获
 */
@ControllerAdvice
@Slf4j
public class MyControllerAdvice {

	@Autowired
	private Monitor monitor;
	
	@ResponseBody
	@ExceptionHandler(value = Exception.class)
    public Map<String,Object> errorHandle(Exception e){
        Map<String,Object> map = new HashMap<String,Object>();
        
        map.put("msgId",monitor.getMsgId());
    	map.put("srcReserve",monitor.getSrcReserve());
        
    	LocalDateTime payTime = LocalDateTime.now();
    	map.put("responseTimestamp",payTime.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
    	payTime = LocalDateTime.now();
		map.put("retcode",ResultEnum.UNKONW_ERROR.getCode());
        map.put("retmsg",ResultEnum.UNKONW_ERROR.getMsg());
		
		log.info("返回内容 : " + map.toString());
		Long ssLong = System.currentTimeMillis() - monitor.getStartTime().get();
		log.info("花费时间 : " + ssLong + "毫秒");
		MDC.put("LOG_TC", ssLong.toString() );
		
		monitor.setRetcode(map.get("retcode").toString());
		monitor.setRetmsg(map.get("retmsg").toString());
		monitor.log();
        return map;
    }

	@ResponseBody
    @ExceptionHandler(value = BusinessException.class)
    public Map<String,Object> errorHandle(BusinessException e){
    	Map<String,Object> map = new HashMap<String,Object>();
    	
    	map.put("msgId",monitor.getMsgId());
    	map.put("srcReserve",monitor.getSrcReserve());
    	
		LocalDateTime payTime = LocalDateTime.now();
    	map.put("responseTimestamp",payTime.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
        map.put("retcode",e.getCode());
        map.put("retmsg",e.getMsg());
		
		log.info("返回内容 : " + map.toString());
		Long ssLong = System.currentTimeMillis() - monitor.getStartTime().get();
		log.info("花费时间 : " + ssLong + "毫秒");
		MDC.put("LOG_TC", ssLong.toString() );
		
		monitor.setRetcode(map.get("retcode").toString());
		monitor.setRetmsg(map.get("retmsg").toString());
		monitor.log();
        return map;
    }
	
	@ResponseBody
    @ExceptionHandler(value = CallException.class)
    public Map<String,Object> errorHandle(CallException e){
    	Map<String,Object> map = new HashMap<String,Object>();

    	map.put("msgId",monitor.getMsgId());
    	map.put("msgSrc",monitor.getMsgSrc());
    	map.put("msgType",monitor.getMsgType());
    	map.put("srcReserve",monitor.getSrcReserve());
    	
		LocalDateTime payTime = LocalDateTime.now();
    	map.put("responseTimestamp",payTime.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
        map.put("resultCode",e.getCode());
        map.put("resultMsg",e.getMsg());
		
		log.info("返回内容 : " + map.toString());
		Long ssLong = System.currentTimeMillis() - monitor.getStartTime().get();
		log.info("花费时间 : " + ssLong + "毫秒");
		MDC.put("LOG_TC", ssLong.toString() );
		
		monitor.setRetcode(map.get("resultCode").toString());
		monitor.setRetmsg(map.get("resultMsg").toString());
		monitor.log();
        return map;
    }



	@ResponseBody
	@ExceptionHandler(value = PivcException.class)
	public Map<String, Object> handlePivcException(PivcException exception){
		Map<String,Object> map = new HashMap<String,Object>();

//		LocalDateTime payTime = LocalDateTime.now();
//		map.put("responseTimestamp", payTime.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
		map.put("retcode" , exception.getRetcode());
		map.put("retmsg"  , exception.getRetmsg());


		return map;
	}
}
