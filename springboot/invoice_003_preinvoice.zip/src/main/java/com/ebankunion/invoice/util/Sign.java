package com.ebankunion.invoice.util;

import java.beans.BeanInfo;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

import com.ebankunion.invoice.exception.BusinessException;
import com.ebankunion.invoice.exception.ExceptionUtil;
import com.ebankunion.invoice.exception.ResultEnum;
import com.google.common.hash.Hashing;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import lombok.extern.slf4j.Slf4j;

class MapKeyComparator implements Comparator<String>{

    @Override
    public int compare(String str1, String str2) {
        
        return str1.compareTo(str2);
    }
}

@Slf4j
public class Sign {	
	 private static Object tmpvalueObject;

	// Bean --> Map 1: 利用Introspector和PropertyDescriptor 将Bean --> Map
    static Map<String, Object> transBean2Map(Object obj) {
 
        if(obj == null){
            return null;
        }        
        Map<String, Object> map = new HashMap<String, Object>();
        try {
            BeanInfo beanInfo = Introspector.getBeanInfo(obj.getClass());
            PropertyDescriptor[] propertyDescriptors = beanInfo.getPropertyDescriptors();
            for (PropertyDescriptor property : propertyDescriptors) {
                String key = property.getName();
 
                // 过滤class属性
                if (!key.equals("class")) {
                    // 得到property对应的getter方法
                    Method getter = property.getReadMethod();
                    Object value = getter.invoke(obj);
 
                    map.put(key, value);
                }
            }
        } catch (Exception e) {
        	log.error("exception happened! detail:{}", ExceptionUtil.getMessage(e));
        }
 
        return map;
    }
    
 // Bean --> Map 2: 利用Introspector和PropertyDescriptor 将Bean --> Map
    static public Map<String, String> transBean2MapStr(Object obj) {
 
        if(obj == null){
            return null;
        }        
        Map<String, String> map = new HashMap<String, String>();
        try {
            BeanInfo beanInfo = Introspector.getBeanInfo(obj.getClass());
            PropertyDescriptor[] propertyDescriptors = beanInfo.getPropertyDescriptors();
            for (PropertyDescriptor property : propertyDescriptors) {
                String key = property.getName();
 
                // 过滤class属性
                if (!key.equals("class")) {
                    // 得到property对应的getter方法
                    Method getter = property.getReadMethod();
                    Object tmpObject = getter.invoke(obj);
                    if(tmpObject!=null) {
                    	String value = tmpObject.toString();
                    	map.put(key, value);
                    }
                }
            }
        } catch (Exception e) {
        	log.error("exception happened! detail:{}", ExceptionUtil.getMessage(e));
        }
 
        return map;
    }
	
    static Map<String, Object> sortMapByKey(Map<String, Object> map) {
        if (map == null || map.isEmpty()) {
            return null;
        }

        Map<String, Object> sortMap = new TreeMap<String, Object>(
                new MapKeyComparator());

        sortMap.putAll(map);

        return sortMap;
    }
    
    public static String mapDoSign(Map<String, Object> map, String key) {
    	Map<String, Object> resultMap = sortMapByKey(map);    //按Key进行排序

        StringBuilder result = new StringBuilder();
        for (Map.Entry<String, Object> entry : resultMap.entrySet()) {
            String tmpkeyString = entry.getKey();
            tmpvalueObject = entry.getValue();
            
            if(tmpkeyString.equals("titleList") && tmpvalueObject!=null && !tmpvalueObject.toString().equalsIgnoreCase("")) {
            	result.append(tmpkeyString);
            	result.append("=");
            	Gson gson = new GsonBuilder()
        		        .excludeFieldsWithoutExposeAnnotation()
        		        .create();
            	result.append(gson.toJson(entry.getValue()));
            	result.append("&");
            }else if(!tmpkeyString.equals("sign") && tmpvalueObject!=null && !tmpvalueObject.toString().equalsIgnoreCase("")){
            	result.append(tmpkeyString);
            	result.append("=");
            	result.append(entry.getValue().toString());
            	result.append("&");
			}
        }
        if(result.substring(result.length()-1).equals("&")) {
        	result.deleteCharAt(result.length()-1);
        }
        result.append (key);
        
        log.debug(LogEnc.encrypt(result.toString()));
        String sha256hex = Hashing.sha256()
        		  .hashString(result.toString(), StandardCharsets.UTF_8)
        		  .toString();
        return sha256hex.toUpperCase();
    }
    
    static public String doSign(Object toIssue, String key) {
        Map<String, Object> map = transBean2Map(toIssue);
        return mapDoSign(map,key);
	}
    
    // 验证返回包的签名
    static public void checkSign(String resPkg, String key) {
    	Gson gson = new GsonBuilder()
		        .excludeFieldsWithoutExposeAnnotation()
		        .create();
		Map<String, Object> map = gson.fromJson(resPkg,
				new TypeToken<Map<String, Object>>() {
				}.getType());
		String macString =  mapDoSign(map,key);
		String retSignString = map.get("sign").toString();
		if(!macString.equalsIgnoreCase(retSignString)) {
			log.info("返回报文验证签名失败，自我计算的sign："+macString);
			throw new BusinessException(ResultEnum.BAD_SIGN,"返回报文验证签名失败");
		}
    }
}
