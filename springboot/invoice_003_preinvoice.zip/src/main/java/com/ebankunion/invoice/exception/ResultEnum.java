package com.ebankunion.invoice.exception;

public enum ResultEnum {
	SUCCESS("0000","成功"),
	UNKONW_ERROR("6099","系统错误"),
	
	INTERNAL_ERROR("6001","(银商)机构系统错误"),
	BAD_REQUEST("6002","请求报文有错"),
	NO_SERVICE("6003","没有能处理请求 的服务"),
	NO_MERCHANT("6004","找不到商户信息"),
	NO_INVOICE("6005","找不到发票信息"),
	DUP_INVOICE("6006","重复开票"),
	DUP_SCAN("6007","重复扫码"),
	API_ERROR("6008","第三方开票接口失败"),
	NET_ERROR("6009","(银商)机构通讯异常"),
	ABNORMAL_REQUEST_TIME("6010","请求时间异常"),
	BAD_SIGN("6011","签名错误"),
	TIMEOUT("6019","(银商)机构处理超时"),
	;
	
	private String code;
	private String msg;
	
	ResultEnum(String code,String msg) {
		this.code = code;
		this.msg = msg;
	}
 
	public String getCode() {
		return code;
	}
 
	public String getMsg() {
		return msg;
	}
}
