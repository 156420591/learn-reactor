package com.ebankunion.invoice.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ebankunion.invoice.bean.ReqNotifyBean;
import com.ebankunion.invoice.bean.ReqPickupBean;
import com.ebankunion.invoice.bean.ResNotifyBean;
import com.ebankunion.invoice.bean.ResPickupBean;
import com.ebankunion.invoice.exception.BusinessException;
import com.ebankunion.invoice.exception.ResultEnum;
import com.ebankunion.invoice.properties.ParamUms;
import com.ebankunion.invoice.ums.ToNotify;
import com.ebankunion.invoice.ums.ToPickup;
import com.ebankunion.invoice.util.HttpClient;
import com.ebankunion.invoice.util.Sign;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import lombok.extern.slf4j.Slf4j;

/**
 * @author 林创标 linchuangbiao@ebankunion.com
 * @version 创建时间：2019年2月14日 下午5:33:10 类说明
 */
@Slf4j
@Component
public class Notify {
	@Autowired
	private ParamUms paramUms;

	public ResNotifyBean process(ReqNotifyBean reqNotifyBean) {
		ToNotify toNotify = new ToNotify();
		ResNotifyBean resNotifyBean = new ResNotifyBean();

		initValue(toNotify, reqNotifyBean);
		toNotify.setSign(Sign.doSign(toNotify, paramUms.getSignKey()));

		// 生成请求包
		Gson gson = new GsonBuilder().excludeFieldsWithoutExposeAnnotation().create();
		String toUms = gson.toJson(toNotify).toString();
		// 发送出去
		String fromString = HttpClient.executePost(paramUms.getUmsAddr(), toUms);

		// 接收解包
		resNotifyBean = parse(fromString);

		return resNotifyBean;
	}

	protected void initValue(ToNotify toNotify , ReqNotifyBean reqNotifyBean) {
		toNotify.setMsgId(reqNotifyBean.getMsgId());
		toNotify.setMsgSrc(paramUms.getMsgSrc());

		toNotify.setMsgType("notify");
		toNotify.setRequestTimestamp(reqNotifyBean.getRequestTimestamp());
		toNotify.setSrcReserve(reqNotifyBean.getSrcReserve());
		toNotify.setMerchantId(reqNotifyBean.getMerchantId());
		toNotify.setTerminalId(reqNotifyBean.getTerminalId());
		toNotify.setMerOrderDate(reqNotifyBean.getMerOrderDate());
		toNotify.setMerOrderId(reqNotifyBean.getMerOrderId());
		
		toNotify.setNotifyEMail(reqNotifyBean.getNotifyEMail());
		toNotify.setNotifyMobileNo(reqNotifyBean.getNotifyMobileNo());
	}

// 解包JSON，验证签名
	protected ResNotifyBean parse(String pkgJson) {
		Gson gson = new GsonBuilder().excludeFieldsWithoutExposeAnnotation().create();
		ResNotifyBean resNotifyBean = gson.fromJson(pkgJson, ResNotifyBean.class);

		// 成功返回需要验证签名
		if (resNotifyBean.getResultCode().equalsIgnoreCase("SUCCESS")) {
			Sign.checkSign(pkgJson, paramUms.getSignKey());
			resNotifyBean.setRetcode(ResultEnum.SUCCESS.getCode());
			resNotifyBean.setRetmsg(resNotifyBean.getResultMsg());
		} else {
			throw new BusinessException(resNotifyBean.getResultCode(), resNotifyBean.getResultMsg());
		}
		return resNotifyBean;
	}

}
