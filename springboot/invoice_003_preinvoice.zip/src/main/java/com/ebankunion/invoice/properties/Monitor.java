package com.ebankunion.invoice.properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import lombok.Data;

@Data
@Component
public class Monitor {
	private static final Logger monitor = LoggerFactory.getLogger("MONITOR");
	
	private ThreadLocal<Long> startTime;
	private String uriString = "_";
	private String merchantId = "_";
	private String terminalId = "_";
	private String merOrderId = "_";
	private String retcode = "_";
	private String retmsg = "_";

	private String msgId; 
	private String msgSrc; 
	private String msgType; 
	private String srcReserve;
	
	public void log() {
		monitor.info("{} {} {} {} {} {}",
				uriString, merchantId, terminalId, merOrderId, retcode, retmsg);
	}
}
