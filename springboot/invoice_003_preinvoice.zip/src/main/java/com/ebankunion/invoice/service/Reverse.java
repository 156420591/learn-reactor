package com.ebankunion.invoice.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ebankunion.invoice.bean.ReqReverseBean;
import com.ebankunion.invoice.bean.ResIssueBean;
import com.ebankunion.invoice.exception.BusinessException;
import com.ebankunion.invoice.exception.ResultEnum;
import com.ebankunion.invoice.properties.ParamUms;
import com.ebankunion.invoice.ums.ToReverse;
import com.ebankunion.invoice.util.HttpClient;
import com.ebankunion.invoice.util.Sign;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

@Component
public class Reverse {
	@Autowired
	private ParamUms paramUms;

	public Reverse(ParamUms myProperties1) {
		this.paramUms = myProperties1;
	}

	public ResIssueBean process(ReqReverseBean reqReverseBean) {
		ToReverse toReverse = new ToReverse();
		ResIssueBean resIssueBean = new ResIssueBean();

			initValue(toReverse, reqReverseBean);
			toReverse.setSign(Sign.doSign(toReverse, paramUms.getSignKey()));

			// 生成请求包
			Gson gson = new GsonBuilder().excludeFieldsWithoutExposeAnnotation().create();
			String toUms = gson.toJson(toReverse).toString();
			// 发送出去
			String fromString = HttpClient.executePost(paramUms.getUmsAddr(), toUms);

			// 接收解包
			resIssueBean = parse(fromString);
		return resIssueBean;
	}

	protected void initValue(ToReverse toReverse, ReqReverseBean reqReverseBean) {
		toReverse.setMsgId(reqReverseBean.getMsgId());
		toReverse.setMsgSrc(paramUms.getMsgSrc());

		toReverse.setMsgType("reverse");
		toReverse.setRequestTimestamp(reqReverseBean.getRequestTimestamp());
		toReverse.setSrcReserve(reqReverseBean.getSrcReserve());
		toReverse.setMerchantId(reqReverseBean.getMerchantId());
		toReverse.setTerminalId(reqReverseBean.getTerminalId());
		toReverse.setMerOrderDate(reqReverseBean.getMerOrderDate());
		toReverse.setMerOrderId(reqReverseBean.getMerOrderId());
	}

	// 解包JSON，验证签名
	protected ResIssueBean parse(String pkgJson) {
		Gson gson = new GsonBuilder().excludeFieldsWithoutExposeAnnotation().create();
		ResIssueBean resIssueBean = gson.fromJson(pkgJson, ResIssueBean.class);
		
		// 成功返回需要验证签名
		if (resIssueBean.getResultCode().equalsIgnoreCase("SUCCESS")) {
			Sign.checkSign(pkgJson, paramUms.getSignKey());
			resIssueBean.setRetcode(ResultEnum.SUCCESS.getCode());
			resIssueBean.setRetmsg(resIssueBean.getResultMsg());
		} else {
			throw new BusinessException(resIssueBean.getResultCode(), resIssueBean.getResultMsg());
		}
		return resIssueBean;
	}

}
