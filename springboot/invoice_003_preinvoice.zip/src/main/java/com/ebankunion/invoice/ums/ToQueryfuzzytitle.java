package com.ebankunion.invoice.ums;

import com.google.gson.annotations.Expose;

import lombok.Data;

@Data
public class ToQueryfuzzytitle {
	@Expose(serialize = true, deserialize = true)
	private String msgId;
	@Expose(serialize = true, deserialize = true)
	private String msgSrc;
	@Expose(serialize = true, deserialize = true)
	private String msgType;
	@Expose(serialize = true, deserialize = true)
	private String requestTimestamp;
	@Expose(serialize = true, deserialize = true)
	private String srcReserve;

	@Expose(serialize = true, deserialize = true)
	private String name;
	@Expose(serialize = true, deserialize = true)
	private String taxCode;

	@Expose(serialize = true, deserialize = true)
	private String sign;

}
