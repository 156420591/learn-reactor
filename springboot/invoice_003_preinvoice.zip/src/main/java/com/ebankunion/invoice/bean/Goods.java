package com.ebankunion.invoice.bean;

import com.google.gson.annotations.Expose;

import lombok.Data;

@Data
public class Goods {
	@Expose(serialize = true, deserialize = true)
	private int index;
	@Expose(serialize = true, deserialize = true)
	private String attribute;
	@Expose(serialize = true, deserialize = true)
	private int discountIndex;
	@Expose(serialize = true, deserialize = true)
	private String name;
	@Expose(serialize = true, deserialize = true)
	private String sn;
	@Expose(serialize = true, deserialize = true)
	private int taxRate;
	@Expose(serialize = true, deserialize = true)
	private double priceIncludingTax;
	@Expose(serialize = true, deserialize = true)
	private double quantity;
	@Expose(serialize = true, deserialize = true)
	private String unit;
	@Expose(serialize = true, deserialize = true)
	private String model;
	@Expose(serialize = true, deserialize = true)
	private String freeTaxType;
	@Expose(serialize = true, deserialize = true)
	private String preferPolicyFlag;
	@Expose(serialize = true, deserialize = true)
	private String vatSpecial;
	
}
