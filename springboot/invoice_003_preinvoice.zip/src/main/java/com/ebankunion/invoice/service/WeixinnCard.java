package com.ebankunion.invoice.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ebankunion.invoice.bean.ReqWeixinCardBean;
import com.ebankunion.invoice.bean.ResWeixinCardBean;
import com.ebankunion.invoice.exception.BusinessException;
import com.ebankunion.invoice.exception.ResultEnum;
import com.ebankunion.invoice.properties.ParamUms;
import com.ebankunion.invoice.ums.ToWeixinCard;
import com.ebankunion.invoice.util.HttpClient;
import com.ebankunion.invoice.util.Sign;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import lombok.extern.slf4j.Slf4j;

/**
* @author 林创标  linchuangbiao@ebankunion.com
* @version 创建时间：2019年2月22日 上午9:51:51
* 类说明
*/
@Slf4j
@Component
public class WeixinnCard {
	@Autowired
	private ParamUms paramUms;

	public ResWeixinCardBean process(ReqWeixinCardBean reqWeixinCardBean) {
		ToWeixinCard toWeixinCard = new ToWeixinCard();
		Gson gson = new GsonBuilder().excludeFieldsWithoutExposeAnnotation().create();

		initValue(toWeixinCard, reqWeixinCardBean);
		toWeixinCard.setSign(Sign.doSign(toWeixinCard, paramUms.getSignKey()));

		// 生成请求包
		String toUms = gson.toJson(toWeixinCard).toString();
		// 发送出去
		String fromString = HttpClient.executePost(paramUms.getUmsAddr(), toUms);

		// 接收解包
		ResWeixinCardBean resWeixinCardBean = parse(fromString);
		return resWeixinCardBean;
	}

	protected void initValue(ToWeixinCard toWeixinCard, ReqWeixinCardBean reqWeixinCardBean) {
		toWeixinCard.setMsgId(reqWeixinCardBean.getMsgId());
		toWeixinCard.setMsgSrc(paramUms.getMsgSrc());
		toWeixinCard.setMsgType("weixin.card");
		toWeixinCard.setRequestTimestamp(reqWeixinCardBean.getRequestTimestamp());
		toWeixinCard.setSrcReserve(reqWeixinCardBean.getSrcReserve());
		toWeixinCard.setMerchantId(reqWeixinCardBean.getMerchantId());
		toWeixinCard.setTerminalId(reqWeixinCardBean.getTerminalId());
		toWeixinCard.setMerOrderDate(reqWeixinCardBean.getMerOrderDate());
		toWeixinCard.setMerOrderId(reqWeixinCardBean.getMerOrderId());
		toWeixinCard.setSource(reqWeixinCardBean.getSource());
		toWeixinCard.setInvoiceCode(reqWeixinCardBean.getInvoiceCode());
		toWeixinCard.setInvoiceNo(reqWeixinCardBean.getInvoiceNo());
	}

	// 解包JSON，验证签名
	protected ResWeixinCardBean parse(String pkgJson) {
		// 成功返回需要验证签名
		Gson gson = new GsonBuilder().excludeFieldsWithoutExposeAnnotation().create();
		ResWeixinCardBean resWeixinCardBean = gson.fromJson(pkgJson, ResWeixinCardBean.class);
		// 成功返回需要验证签名
		if (resWeixinCardBean.getResultCode().equalsIgnoreCase("SUCCESS")) {
			Sign.checkSign(pkgJson, paramUms.getSignKey());
			resWeixinCardBean.setRetcode(ResultEnum.SUCCESS.getCode());
			resWeixinCardBean.setRetmsg(resWeixinCardBean.getResultMsg());
		} else {
			log.info("失败交易无需验证MAC");
			throw new BusinessException(resWeixinCardBean.getResultCode(), resWeixinCardBean.getResultMsg());
		}
		return resWeixinCardBean;
	}
}
