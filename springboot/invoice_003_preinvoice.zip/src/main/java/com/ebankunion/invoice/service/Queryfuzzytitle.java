package com.ebankunion.invoice.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ebankunion.invoice.bean.ReqQueryfuzzytitleBean;
import com.ebankunion.invoice.bean.ResQueryfuzzytitleBean;
import com.ebankunion.invoice.exception.BusinessException;
import com.ebankunion.invoice.exception.ResultEnum;
import com.ebankunion.invoice.properties.ParamUms;
import com.ebankunion.invoice.ums.ToQueryfuzzytitle;
import com.ebankunion.invoice.util.HttpClient;
import com.ebankunion.invoice.util.Sign;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class Queryfuzzytitle {
	@Autowired
	private ParamUms paramUms;

	public ResQueryfuzzytitleBean process(ReqQueryfuzzytitleBean reqQueryfuzzytitleBean) {
		ToQueryfuzzytitle toQueryfuzzytitle = new ToQueryfuzzytitle();
		ResQueryfuzzytitleBean resQueryfuzzytitleBean = new ResQueryfuzzytitleBean();
		Gson gson = new GsonBuilder().excludeFieldsWithoutExposeAnnotation().create();

		initValue(toQueryfuzzytitle, reqQueryfuzzytitleBean);
		toQueryfuzzytitle.setSign(Sign.doSign(toQueryfuzzytitle, paramUms.getSignKey()));

		// 生成请求包
		String toUms = gson.toJson(toQueryfuzzytitle).toString();
		// 发送出去
		String fromString = HttpClient.executePost(paramUms.getUmsAddr(), toUms);

		// 接收解包
		resQueryfuzzytitleBean = parse(fromString);
		return resQueryfuzzytitleBean;
	}

	protected void initValue(ToQueryfuzzytitle toQueryfuzzytitle, ReqQueryfuzzytitleBean reqQueryfuzzytitleBean) {
		toQueryfuzzytitle.setMsgId(reqQueryfuzzytitleBean.getMsgId());
		toQueryfuzzytitle.setMsgSrc(paramUms.getMsgSrc());
		toQueryfuzzytitle.setMsgType("query.fuzzy.title");
		toQueryfuzzytitle.setRequestTimestamp(reqQueryfuzzytitleBean.getRequestTimestamp());
		toQueryfuzzytitle.setSrcReserve(reqQueryfuzzytitleBean.getSrcReserve());
		toQueryfuzzytitle.setName(reqQueryfuzzytitleBean.getName());
		toQueryfuzzytitle.setTaxCode(reqQueryfuzzytitleBean.getTaxCode());
	}

	// 解包JSON，验证签名
	protected ResQueryfuzzytitleBean parse(String pkgJson) {
		// 成功返回需要验证签名
		Gson gson = new GsonBuilder().excludeFieldsWithoutExposeAnnotation().create();
		ResQueryfuzzytitleBean resQueryfuzzytitleBean = gson.fromJson(pkgJson, ResQueryfuzzytitleBean.class);
		// 成功返回需要验证签名
		if (resQueryfuzzytitleBean.getResultCode().equalsIgnoreCase("SUCCESS")) {
			Sign.checkSign(pkgJson, paramUms.getSignKey());
			resQueryfuzzytitleBean.setRetcode(ResultEnum.SUCCESS.getCode());
			resQueryfuzzytitleBean.setRetmsg(resQueryfuzzytitleBean.getResultMsg());
		} else {
			log.info("失败交易无需验证MAC");
			throw new BusinessException(resQueryfuzzytitleBean.getResultCode(), resQueryfuzzytitleBean.getResultMsg());
		}
		return resQueryfuzzytitleBean;
	}
}
