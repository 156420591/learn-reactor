package com.ebankunion.invoice.ums;

import com.google.gson.annotations.Expose;

import lombok.Data;

/**
* @author 林创标  linchuangbiao@ebankunion.com
* @version 创建时间：2019年2月14日 下午5:46:01
* 类说明
*/
@Data
public class ToNotify {
	@Expose(serialize = true, deserialize = true)
	private String msgId;
	@Expose(serialize = true, deserialize = true)
	private String msgSrc;
	@Expose(serialize = true, deserialize = true)
	private String msgType;
	@Expose(serialize = true, deserialize = true)
	private String requestTimestamp;
	@Expose(serialize = true, deserialize = true)
	private String srcReserve;

	@Expose(serialize = true, deserialize = true)
	private String merchantId;
	@Expose(serialize = true, deserialize = true)
	private String terminalId;
	@Expose(serialize = true, deserialize = true)
	private String merOrderId;
	@Expose(serialize = true, deserialize = true)
	private String merOrderDate;

	@Expose(serialize = true, deserialize = true)
	private String notifyMobileNo;
	@Expose(serialize = true, deserialize = true)
	private String notifyEMail;
	
	@Expose(serialize = true, deserialize = true)
	private String sign;
}
