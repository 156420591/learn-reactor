package ybs.ips.message.tddl;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.vertx.core.Handler;
import io.vertx.core.Vertx;
import io.vertx.core.json.JsonArray;
import io.vertx.core.json.JsonObject;
import ybs.ips.message.constant.ConstantError;
import ybs.ips.message.constant.ConstantSYS;
import ybs.ips.message.handler.HttpHandler;
import ybs.ips.message.handler.JsonHandler;
import ybs.ips.message.util.HttpUtil;
import ybs.ips.message.util.JsonParse;
import ybs.ips.message.util.LogFormat;
import ybs.ips.message.util.Util;

/**
* @author zhangjifeng
* @create 2018��1��4�� ����4:36:37
* @email  414512194@qq.com
* @desc  
*/

public class TddlService {
	// trace log
	private Logger log = LoggerFactory.getLogger(getClass());
	
	private String retryCode,logId,HOST,queryURI;
	private LogFormat lF;
	private int PORT,TIMEOUT;
	//retryTimePeriod ��λ��
	private Integer retryTimes,retryTimePeriod, calCnt;
	private String scheme,database,collection,usertoken;
	
	public TddlService(JsonObject conf,String logId) {
		this.retryTimes = conf.getInteger("retryTimes",0);
		this.retryTimePeriod = conf.getInteger("retryTimePeriod",0);
		this.retryCode = conf.getString("retryCode","");
		this.TIMEOUT = conf.getInteger("timeout",0);
		this.HOST    = conf.getString("host");
		this.PORT =  conf.getInteger("port");
		this.queryURI = conf.getString("query");
		this.logId = logId;
		this.lF = new LogFormat(logId);
		this.scheme = conf.getString("scheme","http");
		this.database = conf.getString("database");
		this.collection = conf.getString("collection");
		this.usertoken = conf.getString("usertoken");
		this.calCnt = 0;
	}
	
	private String packReq(JsonObject condition,int skip, int limit) {

		Map<String, Object> map = new HashMap<>();
		map.put("collection", collection);
		map.put("database", database);
		map.put("usertoken", usertoken);
		map.put("returncols", "{}");
		map.put("conditioncols", condition.toString());
		
		JsonObject options = new JsonObject();
		options.put("skip", skip);
		options.put("limit", limit);
		map.put("options", options.encode());
		
		return Util.map2queryString(map);
	}
	
	/**
	 * 
	 * @param kafkaJson
	 * @param vertx
	 * @param skip
	 * @param limit
	 * @param respHandler
	 */
	public void process(JsonObject condition , Vertx vertx, int skip, int limit, JsonHandler respHandler ){
		log.info(lF.format("��ȡmysql����"));
		this.calCnt++;
		String sendBody = packReq(condition, skip, limit);
		HttpUtil httpPost = new HttpUtil(vertx, logId, scheme, HOST, PORT, queryURI, TIMEOUT, ConstantSYS.GBK);
		httpPost.post(sendBody, new HttpHandler() {
			@Override
			public void handle(String respStr, HttpHandler httpHandler, Integer cnt) {
				JsonObject jsonObject = JsonParse.parse(respStr);
				String retcode = jsonObject.getString("retcode", "8999");
				log.info(lF.format("retcode:"+retcode));
				if ( retryCode.contains(retcode) && cnt <= retryTimes ){
					log.info(lF.format("��� "+ retryTimePeriod +" ms"));
					vertx.setTimer(retryTimePeriod, new Handler<Long>() {
						@Override
						public void handle(Long event) {
							log.info(lF.format("���Ե�"+cnt+"��"));
							httpPost.post(sendBody, httpHandler);
						}
					});
				}else {
					jsonObject.put("retcode", retcode);
					JsonObject respObj = parseResp(jsonObject, retcode);
					respHandler.handle(respObj, respHandler, calCnt);
				}
			}
		});
	}
	
	/**
	 * ΢�Ŵ���
	 * @param msg
	 * @param vertx
	 */
	public void process(JsonObject condition , Vertx vertx, Handler<JsonObject> respHandler ){
		log.info(lF.format("��ȡmysql����"));
		String sendBody = packReq(condition, 0, 2);
		HttpUtil httpPost = new HttpUtil(vertx, logId, scheme, HOST, PORT, queryURI, TIMEOUT, ConstantSYS.GBK);
		httpPost.post(sendBody, new HttpHandler() {
			@Override
			public void handle(String respStr, HttpHandler httpHandler, Integer cnt) {
				JsonObject jsonObject = JsonParse.parse(respStr);
				String retcode = jsonObject.getString("retcode", "8999");
				log.info(lF.format("retcode:"+retcode));
				if ( retryCode.contains(retcode) && cnt <= retryTimes ){
					log.info(lF.format("��� "+ retryTimePeriod +" ms"));
					vertx.setTimer(retryTimePeriod, new Handler<Long>() {
						@Override
						public void handle(Long event) {
							log.info(lF.format("���Ե�"+cnt+"��"));
							httpPost.post(sendBody, httpHandler);
						}
					});
				}else {
					jsonObject.put("retcode", retcode);
					JsonObject respObj = parseResp(jsonObject, retcode);
					respHandler.handle(respObj);
				}
			}
		});
	}
	
	public JsonObject parseResp(JsonObject jsonObject, String retcode){
		JsonArray rs = null;
		JsonObject respObj = new JsonObject();
		respObj.put("retcode", retcode);
		if(ConstantSYS.SUCCESS.equals(retcode)){
			String jStr = jsonObject.encode();
			if (jStr.contains("mccode") && jStr.contains("res")){
				rs = jsonObject.getJsonArray("res");
				log.info(lF.format("rs:"+rs.toString()));
				respObj.put("res", rs);
			}
			if(rs == null){
				log.info(lF.format("��ȡ����Ϊ��"));
				return ConstantError.NO_PUSH_CONFIG;
			}
		}
		
		return respObj;
	}
}
