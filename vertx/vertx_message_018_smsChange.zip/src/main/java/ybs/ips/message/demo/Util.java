package ybs.ips.message.demo;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Util {

	public static List<Integer> rand(int cnt, int size){
		List<Integer> l = new ArrayList<>();
		Random random = new Random();
		for (int k=0;k<cnt;++k){
			int i = random.nextInt(size);
			l.add(i);
		} 
		return l;
	}
}
