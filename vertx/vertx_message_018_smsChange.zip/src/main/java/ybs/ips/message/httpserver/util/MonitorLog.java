package ybs.ips.message.httpserver.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.vertx.core.json.JsonObject;
import ybs.ips.message.util.Util;

/**
* @author zhangjifeng
* @create 2018��1��11�� ����11:36:31
* @email  414512194@qq.com
* @desc  
*/

public class MonitorLog {
	
	private static Logger monitor = LoggerFactory.getLogger("monitor-http");
	
	public static void monitor(JsonObject reqJson, JsonObject respJson, String logId, String startTime) {
		try {
			String endTime = Util.getTime("HH:mm:ss.SSS");

			String msgId = reqJson.getString("MsgID", "_");
			String msgType = reqJson.getString("MsgType", "_");
			String event = reqJson.getString("Event", "_");
			String status = reqJson.getString("Status", "_");

			String tftxcode = respJson.getString("tftxcode", "_");
			String dataFrom = respJson.getString("datafrom", "_");
			String stamt = respJson.getString("tftxmony", "0");
			String tranamt = Util.safeGetJsonString(respJson, "tftxmony", "0");
			String tfcardno = respJson.getString("tfcardno", "_");
			tfcardno = Util.maskStr(tfcardno, 6, 4);
			String tfteacct = respJson.getString("tfteacct", "_");
			String tfmccode = respJson.getString("tfmccode", "_");

			String termid = respJson.getString("tftermid", "_");
			if (termid.length() > 8) {
				termid = termid.substring(0, 8);
			}
			String retcode = respJson.getString("retcode", "_");
			//String retmsg  = respJson.getString("retmsg","_");

			monitor.info("{} {} {} {} {} {} {} {} {} {} {} {} {} {} {}", startTime, endTime,
					logId,
					tftxcode,
					dataFrom,
					tranamt,
					tfcardno,
					tfteacct,
					tfmccode,
					termid,
					msgId,
					msgType,
					event,
					retcode,
					status);
		} catch (Exception ex) {
		}
	}
}
