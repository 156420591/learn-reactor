package ybs.ips.message.constant;

public class ConstantKafka {
	
	public static final String GBK = "GBK";
	public static final String UTF8 = "UTF-8";
	public static final String WXACCTOKENKEY = "wx_access_token_map";
	public static final int WXACCTOKENKEY_EXPIRETIME = 110 * 60;// ��λ�� 1Сʱ50������Чʱ�䣬΢����Чʱ��2Сʱ
	
	public static final String SYSCACHEMAP = "sys_cache_map";
	
}
