package ybs.ips.message.handler;

import io.vertx.core.json.JsonObject;

/**
* @author zhangjifeng
* @create 2018��1��4�� ����5:13:33
* @email  414512194@qq.com
* @desc  
*/

public interface IpsMessageHandler {

	public void handle(JsonObject kafkaJson, JsonObject respJson);
}
