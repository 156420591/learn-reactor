package ybs.ips.message.httpserver.wxcallback;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.vertx.core.Handler;
import io.vertx.core.Vertx;
import io.vertx.core.http.HttpMethod;
import io.vertx.core.http.HttpServerRequest;
import io.vertx.core.http.HttpServerResponse;
import io.vertx.core.json.JsonObject;
import io.vertx.ext.web.RoutingContext;
import ybs.ips.message.constant.ConstantError;
import ybs.ips.message.httpserver.util.MonitorLog;
import ybs.ips.message.util.LogFormat;
import ybs.ips.message.util.SHA1;
import ybs.ips.message.util.Util;
import ybs.ips.message.util.Xml2JsonUtil;

/**
* @author zhangjifeng
* @create 2018��1��11�� ����11:28:05
* @email  414512194@qq.com
* @desc  
*/

public class WxPaCallHandler {
	
	private Logger log = LoggerFactory.getLogger(getClass());
	private LogFormat lF;
	private JsonObject conf;
	private JsonObject sysConf;
	private Vertx vertx;
	private String logId;
	
	public WxPaCallHandler(Vertx vertx, JsonObject conf) {
		this.conf = conf.getJsonObject("tddl");
		this.sysConf = conf;
		this.vertx = vertx;
	}
	
	public void reloadConf( JsonObject conf){
		this.conf = conf;
	}
	
	public void handle(RoutingContext routingContext) {
		this.logId = Util.getUid();
		this.lF = new LogFormat(logId);
		HttpMethod method = routingContext.request().method();
		if(HttpMethod.GET.equals(method)){
			get(routingContext);
		}
		if(HttpMethod.POST.equals(method)){
			post(routingContext);
		}
	}
	
	private void get( RoutingContext routingContext ){
		String serverToken = sysConf.getJsonObject("wx").getString("serverToken");
		log.info(lF.format("serverToken:" + serverToken));
		
		HttpServerRequest request = routingContext.request();
		String signature = request.getParam("signature");
		String timestamp = request.getParam("timestamp");
		String nonce = request.getParam("nonce");
		String echostr = request.getParam("echostr");
		String sh1 = SHA1.getSHA1(serverToken, timestamp, nonce);
		log.info( lF.format("�յ�΢�����÷�������ַ����signature:" + signature +" timestamp:"+timestamp
				+" nonce:"+nonce +" echostr:"+echostr));
		log.info(lF.format("sha1:"+ sh1));
		
		HttpServerResponse response = routingContext.response();
	    response.end(echostr, "GBK");
	}
	
	private void post(RoutingContext routingContext) {
		String startTime = Util.getTime("HH:mm:ss.SSS");
		
		HttpServerResponse response = routingContext.response();

		// https://mp.weixin.qq.com/wiki?t=resource/res_main&id=mp1421140454
		response.end("", "GBK");

		//region ΢�Żص�����(ע�͵�)
//		String msg = routingContext.getBodyAsString();
//		log.info( lF.format("�յ���Ϣ��"+msg));
//		try{
//			JsonObject json = Xml2JsonUtil.xml2json(msg);
//
//			WxCallBackService wxCallBack = new WxCallBackService(vertx, conf, logId);
//			wxCallBack.process(json, new Handler<JsonObject>() {
//				@Override
//				public void handle(JsonObject event ) {
//					MonitorLog.monitor( json, event, logId, startTime);
//				}
//			});
//		}catch(Exception e){
//			e.printStackTrace();
//			log.error(lF.format("���ʧ��"));
//			log.error(lF.format("StackTrace"), e);
//			MonitorLog.monitor(new JsonObject(), ConstantError.PARSE_WX_CALL_ERROR, logId, startTime);
//		}
		//endregion
	}
}
