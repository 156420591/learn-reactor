package ybs.ips.message.service.wx;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.vertx.core.Vertx;
import io.vertx.core.json.JsonObject;
import ybs.ips.message.constant.ConstantWX;
import ybs.ips.message.util.LogFormat;
import ybs.ips.message.util.SysCache;
import ybs.ips.message.util.Util;

/**
* @author zhangjifeng
* @create 2018��1��5�� ����12:26:33
* @email  414512194@qq.com
* @desc  
*/

public class IntTemplateCache {
	private Logger log = LoggerFactory.getLogger(getClass());
	private Vertx vertx;
	private Integer refreshPeriod = 10*1000;// 3*60*1000; // ��λ���룬 3 ����ˢ��һ��
	private LogFormat lf;
	private String templatePath = "E:/log/wx_push_tempalte.json";
	
	public IntTemplateCache(Vertx vertx ) {
		this.vertx = vertx;
	}
	
	public void start(){
		refresh();
		log.info("����΢��ģ�建��, ˢ�¼��"+ refreshPeriod + " ms");
		this.vertx.setPeriodic(refreshPeriod, id -> {
			lf = new LogFormat(Util.getUid());
			log.info(lf.format("����ˢ��΢��ģ��"));
			refresh();
		});
	}
	
	private void refresh() {
		vertx.fileSystem().readFile(templatePath, result -> {
		    if (result.succeeded()) {
		        JsonObject obj = new JsonObject(result.result().toString("GBK"));
		        JsonObject data = obj.getJsonObject("wxtemplate");
		        for(String key : data.fieldNames()){
		        	log.info(lf.format(key + " : " + data.getJsonObject(key).encode()));
		        	SysCache.setCache(vertx, ConstantWX.WXTEMPLATEMSGKEY, key, data.getJsonObject(key), ConstantWX.WXACCTOKENKEY_EXPIRETIME);
		        }
		    } else {
		    	log.error(lf.format("��ȡ�ļ�����"), result.cause());
		    }
		});
	}
}
