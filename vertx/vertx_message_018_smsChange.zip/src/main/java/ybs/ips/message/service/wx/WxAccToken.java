package ybs.ips.message.service.wx;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.vertx.core.Handler;
import io.vertx.core.Vertx;
import io.vertx.core.json.JsonObject;
import ybs.ips.message.constant.ConstantSYS;
import ybs.ips.message.handler.HttpHandler;
import ybs.ips.message.util.HttpUtil;
import ybs.ips.message.util.JsonParse;
import ybs.ips.message.util.LogFormat;

/**
* @author zhangjifeng
* @create 2018��1��4�� ����1:25:54
* @email  414512194@qq.com
* @desc  
*/

public class WxAccToken {
	// trace log
	private Logger log = LoggerFactory.getLogger(getClass());
	
	private String retryCode,logId,HOST,URI;
	private LogFormat lF;
	private int PORT,TIMEOUT;
	//retryTimePeriod ��λ��
	private Integer retryTimes,retryTimePeriod;
	private String scheme;
	
	public WxAccToken(JsonObject jsonConf, String logId) {
		
		this.retryTimes = jsonConf.getInteger("retryTimes", 0);
		this.retryTimePeriod = jsonConf.getInteger("retryTimePeriod",0);
		this.retryCode = jsonConf.getString("retryCode");
		this.TIMEOUT = jsonConf.getInteger("timeout",0);
		this.scheme = jsonConf.getString("scheme");
		this.HOST    = jsonConf.getString("host");
		this.PORT = jsonConf.getInteger("port");
		this.URI = jsonConf.getString("accessTokenUri");
		this.logId = logId;
		this.lF = new LogFormat(logId);
	}
	/**
	 * ΢�Ŵ���
	 * @param msg
	 * @param vertx
	 */
	public void process(String appId, String appSecret, Vertx vertx, Handler<JsonObject> respHandler ){
		log.info(lF.format("΢�Ż�ȡAccessToken"));
		String sendBody = "grant_type=client_credential&appid="+appId+"&secret="+appSecret;
		HttpUtil httpUtil = new HttpUtil(vertx, logId, scheme, HOST, PORT, URI+"?"+sendBody, TIMEOUT, ConstantSYS.UTF8);
		httpUtil.get(new HttpHandler() {
			@Override
			public void handle(String respStr, HttpHandler httpHandler, Integer cnt) {
				JsonObject respJson = JsonParse.parse(respStr);
				String accessToken = respJson.getString("access_token");
				String retcode = "0000";
				if (accessToken == null){
					log.info(lF.format("��ȡaccess tokenʧ��"));
					retcode = "8999";
				}
				
				log.info(lF.format("retcode:"+retcode));
				if ( retryCode.contains(retcode) && cnt <= retryTimes ){
					log.info(lF.format("��� "+ retryTimePeriod +" ms"));
					vertx.setTimer(retryTimePeriod, new Handler<Long>() {
						@Override
						public void handle(Long event) {
							log.info(lF.format("���Ե�"+cnt+"��"));
							httpUtil.get(httpHandler);
						}
					});
				}else {
					JsonObject rJson = new JsonObject();
					rJson.put("retcode", retcode);
					rJson.put("accessToken", accessToken);
					respHandler.handle(rJson);
				}
			}
		});
	}
}
