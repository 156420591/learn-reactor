package ybs.ips.message.demo;

import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

public class File {
	static AtomicInteger counter=new AtomicInteger(0);  
	public static void main(String[] args) throws Exception {
		
		if(args.length < 1){
			System.out.println("��������");
			System.out.println("Usage: java -jar file.jar E:/data/100W.txt ");
			System.exit(0);
		}
		System.out.println(Arrays.asList(args));
		System.out.println("PROGRARM STARTING");
		
		String fileName = "E:/data/100W.txt";
		if (args[0] != null) {
			fileName = args[0];
		}
		RandomAccessFile randomAccessFile = new RandomAccessFile(fileName, "r");
		
		List<String> accList = new ArrayList<>();
		
		String str ;
		while( (str = randomAccessFile.readLine()) != null ){
			str = str.replaceAll("\"", "");
			accList.add(str);
		}
		System.out.println("������"+accList.size());
		randomAccessFile.close();
		
		int worker = 2;
		if (args[1] != null) {
			worker = Integer.parseInt(args[1]);
		}
		
		int onc = 10;
		if(args[2] !=null){
			onc = Integer.parseInt(args[2]);
		}
		
		for( int i=0; i< worker; ++i ){
			System.out.println("start worker " +i);
			new FileJson(KafkaProperties.TOPIC, true, accList,i,counter,onc).start();
		}
		System.out.println("PROGRARM STARTED");
	}
	
}
