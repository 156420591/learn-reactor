//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package ybs.ips.message.util;

import com.ybs.util.CharsetUtil;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class Aes128 {

    public Aes128() {
    }

    public static String encrypt(String sSrc, String enKey, String ivParameter) throws Exception {
        Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
        byte[] raw = enKey.getBytes("utf-8");
        SecretKeySpec skeySpec = new SecretKeySpec(raw, "AES");
        IvParameterSpec iv = new IvParameterSpec(ivParameter.getBytes("utf-8"));
        cipher.init(1, skeySpec, iv);
        byte[] encrypted = cipher.doFinal(sSrc.getBytes());
        return CharsetUtil.bytesToHex(encrypted);
    }

    public static String decrypt(String sSrc, String enKey, String ivParameter) throws Exception {
        byte[] raw = enKey.getBytes("utf-8");
        SecretKeySpec skeySpec = new SecretKeySpec(raw, "AES");
        Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
        IvParameterSpec iv = new IvParameterSpec(ivParameter.getBytes("utf-8"));
        cipher.init(2, skeySpec, iv);
        byte[] encrypted1 = CharsetUtil.hexToBytes(sSrc);
        byte[] original = cipher.doFinal(encrypted1);
        String originalString = new String(original);
        return originalString;
    }

    public static void main(String[] args) throws Exception {
        String cSrc = "621524113657911384";
        System.out.println("ԭʼ�ַ�����" + cSrc);
        String enString = encrypt(cSrc, "9510598948615840", "0000000000000000");
        System.out.println("���ܺ���ִ��ǣ�" + enString);
        String DeString = decrypt(enString, "9510598948615840", "0000000000000000");
        System.out.println("���ܺ���ִ��ǣ�" + DeString);
    }
}
