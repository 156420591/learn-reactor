package ybs.ips.message.util;

import io.vertx.core.json.JsonArray;
import io.vertx.core.json.JsonObject;
import ybs.ips.message.constant.ConstantSYS;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Util {
	
	public static void main(String[] args) {
	}
	
	public static String getTime( long timestamp, String format){
		//"yyyy-MM-dd HH:mm:ss.SSS"
		SimpleDateFormat sdf= new SimpleDateFormat(format);
		Date dt = new Date( timestamp );  
		String sDateTime = sdf.format(dt);  //
		return sDateTime;
	}

	/**
	 * @author hwg
	 */
	public static Date timeGetDateFromString(String timeval, String fmt){
		Date dateParsed = null;
		try{
			DateFormat df = new SimpleDateFormat(fmt);
			dateParsed = df.parse(timeval);
		}catch (Exception e){
		}

		return dateParsed;
	}

	/**
	 * @author hwg
	 */
	public static Date timeNow(){
		Date now = new Date();
		return now;
	}

	/**
	 * @author hwg
	 */
	public static String timeNowyyyyMMddHHmmss(){
		Date now = timeNow();
		return timeGetDateString(now, "yyyyMMddHHmmss");
	}

	/**
	 * @author hwg
	 */
	public static String timeGetDateString(Date thetime, String fmt){
		String result = "";
		try{
			DateFormat df = new SimpleDateFormat(fmt);
			result = df.format(thetime);
		}catch (Exception e){
		}

		return result;
	}

	/**
	 * @author hwg
	 */
	public static Long timeGetDateDiff(Date now, Date future, TimeUnit tu){
		Long diff = future.getTime() - now.getTime();
		return tu.convert(diff, TimeUnit.MILLISECONDS);
	}

	/**
	 * @author hwg
	 */
	public static Long timeGetDateDiffSecs(Date now, Date future){
		return timeGetDateDiff(now, future, TimeUnit.SECONDS);
	}

	/**
	 * @author hwg
	 */
	public static String takeRight(String strSource, int right){
		String strTakeRight = strSource;
		if(strSource != null){
			if(strSource.length() >= right){
				strTakeRight = strSource.substring(strSource.length() - right);
			}
		}
		return strTakeRight;
	}

	/**
	 * @author hwg
	 */
	public static String getStacktrackInfo(Throwable ex){
		StringWriter writer = new StringWriter();
		PrintWriter printWriter = new PrintWriter( writer );
		ex.printStackTrace( printWriter );
		printWriter.flush();
		String stackTrace = writer.toString();
		return stackTrace;
	}

	/**
	 * @author hwg
	 */
	public static String strRepeat(int len, char chPadding){
		int initlen = len > 0 ? len : 0;
		StringBuffer sb = new StringBuffer(initlen);
		for(int i=0; i < len; ++i){
			sb.append(chPadding);
		}
		return sb.toString();
	}

	/**
	 * @author hwg
	 */
	public static String trimPaddingRight(String strInput, int maxlen, char chPadding){
		String strNew = strInput==null ? "" : strInput;
        maxlen = maxlen > 0 ? maxlen : 0;

		if(strNew.length() < maxlen){
			int lenPad = maxlen - strNew.length();
			strNew = strNew + strRepeat(lenPad, chPadding);
		}else if(strNew.length() > maxlen){
			strNew = safeSubString(strNew, 0, maxlen);
		}
		return strNew;
	}

	/**
	 * @author hwg
	 */
	public static boolean isJieShuanTransType(String strJieShuan, JsonObject kafkaJson){
		String tftranstypeInKafka = safeGetJsonString(kafkaJson, "tftranstype", "");
		String[] arrJieShuan = strJieShuan.split(",");
		for(String jieshuan : arrJieShuan){
			if( isNotEmptyString(jieshuan) && safeStringEquals(jieshuan, tftranstypeInKafka) ){
				return true;
			}
		}
		return false;
	}

	/**
	 * @author hwg
	 */
    public static String myHashMccodeJson(JsonObject kafkaJson){
        String mccode = safeGetJsonString(kafkaJson, "tfmccode", "");
        return myHashMccode(mccode);
    }

	/**
	 * @author hwg
	 */
	public static String myHashMccode(String mccode){
        String newMccode = mccode==null ? "" : mccode;

        if(isNotEmptyString(mccode)){
            char chApple = 0;
            for(int i=0; i<mccode.length(); ++i){
                char ch = mccode.charAt(i);
                chApple += ch;
            }
            int chRemainder = chApple % 26;
            char chFirst = (char)('a' + chRemainder);

            StringBuffer sb = new StringBuffer();
            sb.append(chFirst);
            for(int i=1; i< newMccode.length(); ++i){
                char ch = mccode.charAt(i);
                sb.append(ch);
            }
            newMccode = sb.toString();
        }

        return newMccode;
    }


	/**
	 * @author hwg
	 */
	public static boolean isSuccessKafkaData(JsonObject kafkaJson){
        String errorcode = kafkaJson.getString("tfbackno");
        if ("0000".equals(errorcode)){
            return true;
        }
        return false;
    }

	/**
	 * @author hwg
	 */
	public static boolean isTaxiSmsAllowed(JsonObject kafkaJson){
		String sms_flag = safeGetJsonString(kafkaJson, "sms_flag", "");
		if("1".equals(sms_flag)){
			return true;
		}
		return false;
	}


	/**
	 * @author hwg
	 */
	public static String myGetPayTypeString(JsonObject kafkaJson){
//        tfcardtype �� WX ΢�� �� AL ֧���� �� UP (CE\DE)  ����,    ST  ����ͨ �� LG ��֧��
		String paytypeString = "����";
		String tfcardtype    = kafkaJson.getString("tfcardtype", "");
		if(ConstantSYS.PYS_WX.equalsIgnoreCase(tfcardtype)){
			paytypeString = "΢��";
		}
		if(ConstantSYS.PYS_AL.equalsIgnoreCase(tfcardtype)){
			paytypeString = "֧����";
		}
		if(ConstantSYS.PYS_ST.equalsIgnoreCase(tfcardtype)){
			paytypeString = "����ͨ";
		}
		if(ConstantSYS.PYS_LG.equalsIgnoreCase(tfcardtype)){
			paytypeString = "��֧��";
		}

		return paytypeString;
	}

	/**
	 * @author hwg
	 */
	public static String myGetDateFromTfdate(JsonObject kafkaJson){
		String tfdate  = safeGetJsonString(kafkaJson, "tfdate", "");
		String strDate = safeSubString(tfdate, 0, 8);

		return strDate;
	}

	/**
	 * @author hwg
	 */
	public static String myGetDateFromPaSettDate(JsonObject kafkaJson){
		String tfdate  = safeGetJsonString(kafkaJson, "settdate", "");
		String strDate = safeSubString(tfdate, 0, 8);

		return strDate;
	}

	/**
	 * @author hwg
	 */
	public static String myGetMongoDate(JsonObject kafkaJson){
		String strDate     = getTime("yyyyMMdd");
		String tfdateTaxi  = myGetDateFromTfdate(kafkaJson);
		String paSettDate  = myGetDateFromPaSettDate(kafkaJson);
		if(isNotEmptyString(tfdateTaxi)){
			strDate = tfdateTaxi;
		}
		if(isNotEmptyString(paSettDate)){
			strDate = paSettDate;
		}

		return strDate;
	}

	/**
	 * @author hwg
	 */
	public static String safeGetJsonString(JsonObject jo, String key, String defvalue){
		String value = String.valueOf(defvalue);
		try{
			Object tmpvalue = jo.getValue(key);
			if(null != tmpvalue){
				value = String.valueOf(tmpvalue);
			}
		}catch (Exception ex){}

		return value;
	}


	public static byte[] base64decode(String msg){
		msg = String.valueOf(msg);
		byte[] decoded = msg.getBytes();

		try{
			decoded = Base64.getDecoder().decode(msg);
		}catch (Exception e){}

		return decoded;
	}


	/**
	 * @author hwg
	 */
	public static int safeGetJsonInt(JsonObject jo, String key, int defvalue){
		int value = defvalue;
		try {
			Object tmpvalue = jo.getValue(key);
			if(null != tmpvalue){
				String strTmp = String.valueOf(tmpvalue);
				value = Integer.valueOf(strTmp);
			}
		}catch (Exception ex){}

		return value;
	}


	/**
	 * @author hwg
	 */
	public static JsonArray safeGetJsonArray(JsonObject jo, String key){
		JsonArray value = new JsonArray();
		try{
			value = jo.getJsonArray(key);
		}catch (Exception ex){}
		return value;
	}

	public static JsonObject safeGetJsonObject(JsonObject jo, String key){
		JsonObject value = new JsonObject();
		try{
			value = jo.getJsonObject(key);
			if(value == null)
				value = new JsonObject();
		}catch (Exception ex){}
		return value;
	}
	

	/**
	 * @author hwg
	 */
    public static String safeSubString(String strInput, int startindex, int length){
        length     = length > 0 ? length : 0;
        startindex = startindex > 0 ? startindex : 0;

        try {
            if(strInput == null){
                return "";
            }
            int lenofstr = strInput.length();
            int endindex = startindex + length;

            if(startindex >= lenofstr){
                return "";
            }
            if(endindex >= lenofstr){
                return strInput.substring(startindex);
            }

            return strInput.substring(startindex, endindex);
        } catch (Exception e) {
            return "";
        }
    }

	/**
	 * @author hwg
	 */
	public static String json2KeyValue(JsonObject jo){
        jo = (jo==null) ? new JsonObject() : jo;

        StringJoiner myjoiner = new StringJoiner("&");
        Set<String> keysets   = jo.getMap().keySet();
        List<String> lstKeys  = new ArrayList<>();
        lstKeys.addAll(keysets);
//        Collections.sort(lstKeys);
        lstKeys.sort( (s1, s2) -> s1.compareTo(s2) );

        for(String key : lstKeys){
            String value = safeGetJsonString(jo, key, "");
            String kv = String.format("%s=%s", String.valueOf(key), String.valueOf(value) );
            myjoiner.add(kv);
        }

        return myjoiner.toString();
    }

	/**
	 * @author hwg
	 */
    public static String normalizeField(String strInput, int maxlen, char chPadding){
        String strNew = strInput==null ? "" : strInput;
        maxlen = maxlen > 0 ? maxlen : 0;

        if(isEmptyString(strInput)){
            strNew = "_";
        }
        strNew = trimPaddingRight(strNew, maxlen, chPadding);

        return strNew;
    }


	/**
	 * @author hwg
	 */
	public static boolean isEmptyString(String msg){
		if(null == msg){
			return true;
		}
		if(msg.isEmpty()){
			return true;
		}
		return false;
	}

	/**
	 * @author hwg
	 */
	public static boolean isNotEmptyString(String msg){
		return !isEmptyString(msg);
	}


	public static String getFirstNotEmpty(String... mystrs){
		String result = "";
		for(int i = 0; i < mystrs.length; ++i){
			String value = mystrs[i];
			if(isNotEmptyString(value)){
				result = value;
				break;
			}
		}

		return result;
	}

	public static JsonObject parseJsonString(String strjson){
		JsonObject jo = new JsonObject();
		try{
			jo = new JsonObject(strjson);
		}catch (Exception e){
		}

		return jo;
	}

	/**
	 * @author hwg
	 */
	public static boolean safeStringEquals(String david, String albert){
		if( david != null && david.equals(albert)){
			return true;
		}
		return false;
	}

	/**
	 * @author hwg
	 */
	public static boolean isEmptyJsonObject(JsonObject jo){
		if(jo == null){
			return true;
		}
		if(jo.isEmpty()){
			return true;
		}
		return false;
	}
	
	public static String getTime(String format){
		//"yyyy-MM-dd HH:mm:ss.SSS"
		SimpleDateFormat sdf= new SimpleDateFormat(format);
		Date dt = new Date();  
		String sDateTime = sdf.format(dt);  //
		return sDateTime;
	}
	
	public static String getBeforeDay(){
		SimpleDateFormat sdf=new SimpleDateFormat("yyyyMMdd");  
        Date date=new Date();  
        Calendar calendar = Calendar.getInstance();  
        calendar.setTime(date);  
        calendar.add(Calendar.DAY_OF_MONTH, -1);  
        date = calendar.getTime();  
        return sdf.format(date);
	}
	
	public static String getIcInfo(Map<String, Object> icMap){
		StringBuilder sb = new StringBuilder();
		for(String k: icMap.keySet()){
			String value = (String) icMap.get(k);
			String len   = String.format("%03d", value.length());
			sb.append(k);
			sb.append(len);
			sb.append(value);
		}
		
		return sb.toString();
	}
	
	public static String map2queryString(Map<String, Object> map){
		StringBuilder sb = new StringBuilder();
		for(String k : map.keySet()){
			if (map.get(k)!=null){
				sb.append(k);
				sb.append("=");
				sb.append(map.get(k));
				sb.append("&");
			} 
		}
		String queryStr = sb.toString();
		if(queryStr.endsWith("&")){
			queryStr = queryStr.substring(0, queryStr.length()-1);
		}
		return queryStr;
	}
	
	public static String map2Json(Map<String, Object> map) {
		StringBuilder sb = new StringBuilder();
		sb.append("{");
		for(String k: map.keySet()){
			String value = (String) map.get(k);
			if ( value != null){
				sb.append('"'+k+'"');
				sb.append(":");
				sb.append('"'+value+'"');
				sb.append(",");
			}
		}
		String str = sb.toString();
		if (str.contains(",")){
			str = str.substring(0, str.length() - 1);
		}
		str = str + "}";
		return str;
	}

    public static String maskStr(String str, int preLen, int endLen){

        try {
            if (str == null){
                str = "";
            }
            int strLen = str.length();

            if (strLen < preLen+endLen){
                return str;
            }

            String preStr = str.substring(0,preLen);
            String endStr = str.substring(strLen - endLen, strLen);
            String mask = "";
            for(int i=0; i<strLen - endLen - preLen; ++i){
                mask = mask+"*";
            }

            return preStr + mask + endStr;
        } catch (Exception e) {
            return "";
        }
    }
	
	public static String toFen(String yuan){
		BigDecimal bigDecimal = new BigDecimal(yuan);
		BigDecimal bigDecimal2 = new BigDecimal("100");
		
		BigDecimal bigDecimalMultiply = bigDecimal.multiply(bigDecimal2);
		int multiply = bigDecimalMultiply.intValue();
		String amt = String.format("%012d",  multiply);
		return amt;
	}
	
	public static String getUid(){
		String uid = UUID.randomUUID().toString().replaceAll("-", "").toUpperCase();
		return uid;
	}
	
	public static int calTime(String startTime, String endTime){
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmssSSS");
		long start,end;
		int sec = 0;
		try {
			start = sdf.parse(startTime).getTime();
			end   = sdf.parse(endTime).getTime();
			sec = (int) ((end - start)/(1000));
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return sec;
	}
	
	public static String formatDate(String dateStr, String format){
		if(dateStr == null || dateStr.length() == 0){
			return "";
		}
		if(dateStr.length() > 14){
			dateStr = dateStr.substring(0,15);
		}
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
		try {
			Date date = sdf.parse(dateStr);
			return new SimpleDateFormat(format).format(date);
		} catch (ParseException e) {
			e.printStackTrace();
			return "";
		}
	}
	
	public static String formatReplace(String str, String key, String value){
		return str.replace("{" + key + "}", value);
	}
	
	public static List<String> getQStr(String str){
		List<String> ls=new ArrayList<String>();
		Pattern pattern = Pattern.compile("(?<=\\{)(.+?)(?=\\})");
		Matcher matcher = pattern.matcher(str);
		while(matcher.find()){
			ls.add(matcher.group());
		}
		return ls;
	}
	
	public static String formatAmt(String amt) {
		if ( amt == null || amt.length() == 0) {
			amt = "0";
		}
		BigDecimal m = new BigDecimal(amt);
		DecimalFormat decimalFormat = new DecimalFormat("##0.00");  
		String f = decimalFormat.format(m.doubleValue());
		return f;
	}

	public static String amountToFen(String amt) {
		if ( amt == null || amt.length() == 0) {
			amt = "0";
		}
		BigDecimal m = new BigDecimal(amt);

		return m.movePointRight(2).toString();
	}
}
