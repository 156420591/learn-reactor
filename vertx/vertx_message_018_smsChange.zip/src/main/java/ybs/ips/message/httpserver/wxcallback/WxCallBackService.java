package ybs.ips.message.httpserver.wxcallback;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.vertx.core.Handler;
import io.vertx.core.Vertx;
import io.vertx.core.json.JsonArray;
import io.vertx.core.json.JsonObject;
import ybs.ips.message.constant.ConstantError;
import ybs.ips.message.constant.ConstantSYS;
import ybs.ips.message.tddl.TddlMongo;
import ybs.ips.message.util.LogFormat;
import ybs.ips.message.util.Util;

/**
* @author zhangjifeng
* @create 2018��1��9�� ����8:41:16
* @email  414512194@qq.com
* @desc  
*/

public class WxCallBackService {
	
	private Logger log = LoggerFactory.getLogger(getClass());
	private JsonObject conf;
	private Vertx vertx;
	private String logId;
	private LogFormat lF;
	
	public WxCallBackService(Vertx vertx, JsonObject conf, String logId) {
		this.vertx = vertx;
		this.conf = conf;
		this.logId = logId;
		this.lF = new LogFormat(logId);
	}
	
	public void process(JsonObject reqJson, Handler<JsonObject> jsonHandler) {
		String event = reqJson.getString("Event");
		log.info(lF.format("��Ϣ����Ϊ"+ event));
		if(!"TEMPLATESENDJOBFINISH".equals(event)){
			log.info(lF.format("��ģ����Ϣ"));
			jsonHandler.handle(ConstantError.NOT_TEMPLATE_MSG );
			return;
		}
		
		JsonObject condition = new JsonObject();
		condition.put("msgid", reqJson.getString("MsgID"));
		
		TddlMongo tddlMongo = new TddlMongo(conf, logId);
		String collection = TddlMongo.collection + Util.getTime("yyyyMMdd");
		tddlMongo.query(condition, collection, vertx, new Handler<JsonObject>() {
			@Override
			public void handle(JsonObject event) {
				String retcode = event.getString("retcode");
				JsonArray rs = event.getJsonArray("rs");
				if(ConstantSYS.SUCCESS.equals(retcode)){
					if(rs == null){
						queryBeforeDay(tddlMongo , condition, reqJson, jsonHandler);
					}else{
						update(tddlMongo , collection , rs.getJsonObject(0) ,reqJson, jsonHandler);
					}
				}else {
					jsonHandler.handle(event);
				}
			}
		});
	}
	
	private void queryBeforeDay( TddlMongo tddlMongo ,JsonObject condition, JsonObject reqJson, Handler<JsonObject> jsonHandler) {
		String collection = TddlMongo.collection + Util.getBeforeDay();
		tddlMongo.query(condition, collection, vertx, new Handler<JsonObject>() {
			@Override
			public void handle(JsonObject event) {
				String retcode = event.getString("retcode");
				JsonArray rs = event.getJsonArray("rs");
				if(ConstantSYS.SUCCESS.equals(retcode)){
					if(rs == null){
						jsonHandler.handle(ConstantError.QUERY_DATA_EMPTY);
					}else{
						update(tddlMongo , collection , rs.getJsonObject(0) ,reqJson, jsonHandler);
					}
				}else {
					jsonHandler.handle(event);
				}
			}
		});
	}

	private void update( TddlMongo tddlMongo ,String collection , JsonObject queryRes, JsonObject reqJson, Handler<JsonObject> jsonHandler){
		JsonObject condition = new JsonObject();
		condition.put("msgid", reqJson.getString("MsgID"));
		tddlMongo.update(condition, reqJson, collection, vertx, new Handler<JsonObject>() {
			@Override
			public void handle(JsonObject event) {
				for(String k: queryRes.getMap().keySet()){
					event.put(k, queryRes.getMap().get(k));
				}
				jsonHandler.handle(event);
			}
		});
	}
}
