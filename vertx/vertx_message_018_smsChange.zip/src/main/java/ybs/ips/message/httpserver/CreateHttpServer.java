package ybs.ips.message.httpserver;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.vertx.core.Vertx;
import io.vertx.core.json.JsonObject;
import io.vertx.ext.web.Router;
import io.vertx.ext.web.RoutingContext;
import io.vertx.ext.web.handler.BodyHandler;
import ybs.ips.message.httpserver.wxcallback.WxPaCallHandler;

/**
* @author zhangjifeng
* @create 2018��1��9�� ����7:24:50
* @email  414512194@qq.com
* @desc  
*/

public class CreateHttpServer {

	private Logger log = LoggerFactory.getLogger(getClass());
	private Vertx vertx;
	private int PORT = 8080;
	private JsonObject conf;
	
	public CreateHttpServer(Vertx vertx, JsonObject conf ) {
		this.vertx = vertx;
		this.conf = conf;
	}
	
	public void startServer(){
		Router router = Router.router(vertx);
	    router.route().handler(BodyHandler.create());
	    
	    router.route("/ips.message/wxcall").handler(this::handleWxCall);

	    vertx.createHttpServer().requestHandler(router::accept)
	    .exceptionHandler( th -> { log.error("HTTP�����쳣:", th); })
	    .listen(PORT, hs -> { log.info("HTTP����״̬��"+ hs.succeeded()); });
	}
	
	private void handleWxCall(RoutingContext routingContext ){
		WxPaCallHandler wxPaCallHandler = new WxPaCallHandler(vertx, this.conf);
		wxPaCallHandler.handle(routingContext);
	}
	
	public void reloadConf(JsonObject conf){
		this.conf = conf;
	}
	
}
