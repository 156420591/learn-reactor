package ybs.ips.message.handler;

import io.vertx.core.json.JsonObject;

/**
* @author zhangjifeng
* @create 2018��1��4�� ����11:56:59
* @email  414512194@qq.com
* @desc  
*/
public interface JsonHandler {

	public void handle(JsonObject event, JsonHandler jsonHandler, Integer cnt);
}
