package ybs.ips.message.tddl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.vertx.core.Vertx;
import io.vertx.core.json.JsonArray;
import io.vertx.core.json.JsonObject;
import io.vertx.core.shareddata.LocalMap;
import ybs.ips.message.constant.ConstantMYSQL;
import ybs.ips.message.handler.JsonHandler;
import ybs.ips.message.util.LogFormat;
import ybs.ips.message.util.SysCache;
import ybs.ips.message.util.Util;

/**
* @author zhangjifeng
* @create 2018��1��5�� ����12:26:33
* @email  414512194@qq.com
* @desc  
*/

public class IntMysqlCache {
	private Logger log = LoggerFactory.getLogger(getClass());
	private Vertx vertx;
	private Integer refreshPeriod = 3*60*1000;// 3*60*1000; // ��λ���룬 3 ����ˢ��һ��
	private JsonObject tddlConf;
	private LogFormat lf;
	
	public IntMysqlCache(Vertx vertx, JsonObject tddlConf ) {
		this.vertx = vertx;
		this.tddlConf = tddlConf;
	}
	
	private void initParam(JsonObject conf) {
		log.info("ԭ����"+tddlConf.toString());
		if (conf !=null){
			tddlConf = conf;
			log.info("�²���"+tddlConf.toString());
		}
	}
	
	public void start(){
		initParam(null);
		log.info("����myql����ˢ��, ˢ�¼��"+ refreshPeriod + " ms");
		this.vertx.setPeriodic(refreshPeriod, id -> {
				lf = new LogFormat(Util.getUid());
				log.info(lf.format("����ˢ�� myqsl ����"));
				refresh();
		});
	}
	
	public void restart(JsonObject newConf){
		if( tddlConf.equals(newConf) ){
			log.info("tddl �¾ɲ���һ��");
			return;
		}
		log.info("�¾ɲ�����һ�£�ˢ�²���");
		initParam( newConf );
	}
	
	private void refresh() {
		LocalMap<String, JsonObject> map = SysCache.getKeyMap(vertx, ConstantMYSQL.MYSQLCACHEKEY);
		if(map.size() == 0){
			log.info(lf.format("����mysql ��������"));
		}
		log.info(lf.format("ˢ���»���"));
		
		TddlService tddlService = new TddlService(tddlConf, lf.getLogId());
		JsonObject condtion = new JsonObject();
		tddlService.process(condtion, vertx, 0, 500, new JsonHandler() {
			@Override
			public void handle(JsonObject event, JsonHandler jsonHandler, Integer cnt) {
				String retcode = event.getString("retcode");
				if(!"0000".equals(retcode)){
					return;
				}
				log.info(lf.format("ˢ��cache�ɹ�"));
				setCache(event.getJsonArray("res"));
				tddlService.process(condtion, vertx, cnt*500, 500, jsonHandler);
			}
		});
	}
	
	private void setCache(JsonArray jsonArray) {
		for(int i=0; i< jsonArray.size(); ++i){
			JsonObject obj = jsonArray.getJsonObject(i);
			SysCache.setCache(vertx, ConstantMYSQL.MYSQLCACHEKEY, obj.getString("mccode"), obj, ConstantMYSQL.MYSQLCACHEKEY_EXPIRETIME);
		}
	}
}
