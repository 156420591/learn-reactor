package ybs.ips.message.util;

import io.vertx.core.json.JsonObject;
import net.sf.json.JSON;
import net.sf.json.JSONSerializer;
import net.sf.json.xml.XMLSerializer;

/**
* @author zhangjifeng
* @create 2018��1��9�� ����8:04:19
* @email  414512194@qq.com
* @desc  
*/

public class Xml2JsonUtil {
	
	/**
     * ��xml�ַ���<STRONG>ת��</STRONG>ΪJSON�ַ���
     * 
     * @param xmlString
     *            xml�ַ���
     * @return JSON<STRONG>����</STRONG>
     */
    public static JsonObject xml2json(String xmlString) {
        XMLSerializer xmlSerializer = new XMLSerializer();
        JSON json = xmlSerializer.read(xmlString);
        String jsonStr = json.toString();
        return new JsonObject(jsonStr);
    }

    /**
     * JSON(����)�ַ���<STRONG>ת��</STRONG>��XML�ַ���
     * 
     * @param jsonString
     * @return
     */
    public static String json2xml(String jsonString) {
        XMLSerializer xmlSerializer = new XMLSerializer();
        return xmlSerializer.write(JSONSerializer.toJSON(jsonString));
    }
}
