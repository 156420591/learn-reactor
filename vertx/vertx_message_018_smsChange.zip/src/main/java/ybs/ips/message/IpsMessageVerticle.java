package ybs.ips.message;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Scanner;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.vertx.config.ConfigChange;
import io.vertx.config.ConfigRetriever;
import io.vertx.config.ConfigRetrieverOptions;
import io.vertx.config.ConfigStoreOptions;
import io.vertx.core.AbstractVerticle;
import io.vertx.core.AsyncResult;
import io.vertx.core.DeploymentOptions;
import io.vertx.core.Future;
import io.vertx.core.Handler;
import io.vertx.core.Vertx;
import io.vertx.core.json.JsonObject;
import io.vertx.kafka.client.consumer.KafkaReadStream;
import kafka.common.KafkaException;
import ybs.ips.message.httpserver.CreateHttpServer;
import ybs.ips.message.service.IpsMessageService;
import ybs.ips.message.service.wx.IntAccTokenCache;
import ybs.ips.message.tddl.IntMysqlCache;
import ybs.ips.message.util.Util;
import ybs.ips.message.util.log.MonitorJson;

/**
* @author zhangjifeng
* @create 2017��12��25�� ����10:54:03
* @email  414512194@qq.com
* @desc  ����kafka��Ϣ��¼
*/
public class IpsMessageVerticle extends AbstractVerticle {

	// trace log
	private Logger log = LoggerFactory.getLogger(IpsMessageVerticle.class);
	// monitor log
	private Logger monitor = LoggerFactory.getLogger("monitor");
	
	private KafkaReadStream<String, String> consumer = null;
	private JsonObject kafkaJsonConf,wxJsonConf,tddlJsonConf;
	private String strTopics, configPath;
	private Integer scanPeriod;
	private HashSet<String> topicsSet;
	private JsonObject sysConf;
	private IntAccTokenCache intAccTokenCache;
	private IntMysqlCache intMysqlCache;
	private CreateHttpServer createHttpServer;
	
	// Convenience method so you can run it in your IDE
	public static void main(String[] args) {
		JsonObject config = null;
		try (Scanner scanner = new Scanner(new File("E:/log/ips_message_conf.json")).useDelimiter("\\A")){
	        String sconf = scanner.next();
	        config = new JsonObject(sconf);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		Vertx vertx = Vertx.vertx();
	    vertx.deployVerticle(IpsMessageVerticle.class.getName(), new DeploymentOptions().setConfig(config));
	}
	
	@Override
	public void start(Future<Void> startFuture) throws Exception {
		try{
			log.info("-- IPS MESSAGE SREVICE try to start --");

			// ��ʼ������
			initConfig(null);
			//���������仯
			initReloadConfig();
			//��ʼ����������
			initKafka();
			// ��ʼ��cache
			initCache();
			initHttpServer();

			log.info("-- IPS MESSAGE SREVICE start completed --");
			startFuture.complete();
		}catch (Exception e){
			String smsg = String.format("IpsMessageVerticle start failed[%s]", Util.getStacktrackInfo(e));
			log.info(smsg);
			startFuture.fail(e);
		}

	}
	
	private void initHttpServer(){
		createHttpServer = new CreateHttpServer(vertx, sysConf);
		createHttpServer.startServer();
	}
	
	private void initCache(){
		//new IntTemplateCache(vertx).start();
		
		intAccTokenCache = new IntAccTokenCache(vertx, wxJsonConf);
		intAccTokenCache.start();
		
		intMysqlCache = new IntMysqlCache(vertx, tddlJsonConf);
		intMysqlCache.start();
	}
	
	private void resetCacheConf(JsonObject conf){
		intAccTokenCache.restart(conf.getJsonObject("wx"));
		intMysqlCache.restart(conf.getJsonObject("tddl"));
		createHttpServer.reloadConf(conf);
	}

	/**
	 * ��ʼ������
	 */
	private void initConfig(JsonObject conf ) {
		JsonObject config = config();
		if(conf != null ){
			config = null;
			config = conf;
			// �ݲ�������kafka����
		}
		sysConf = config;
		log.info("��������:"+ sysConf.toString());
		kafkaJsonConf = config.getJsonObject("kafka");
		wxJsonConf  = config.getJsonObject("wx");
		tddlJsonConf  = config.getJsonObject("tddl");
		strTopics = config.getString("kafkaTopics");
		configPath = config.getString("configPath","/usr/verticles/ips_message/ips_message_conf.json");
		scanPeriod = config.getInteger("scanPeriod", 5);
		scanPeriod = scanPeriod*1000;
		
		if ( kafkaJsonConf == null ) {
			log.error("KAFKA ����δ����");
			throw new KafkaException("KAFKA ����δ����");
		}
		if ( strTopics == null ) {
			log.error("kafkaTopics ����δ����");
			throw new KafkaException("kafkaTopics ����δ����");
		}
		String [] kafkaTopics = strTopics.split(",");
		topicsSet = new HashSet<String>(Arrays.asList(kafkaTopics));
		if ( wxJsonConf == null ) {
			log.error("wx ����δ����");
			throw new KafkaException("wx ����δ����");
		}
		if ( tddlJsonConf == null ) {
			log.error("tddl ����δ����");
			throw new KafkaException("tddl ����δ����");
		}
	}
	
	/**
	 * ���������仯
	 */
	private void initReloadConfig() {
		ConfigStoreOptions fileStore = new ConfigStoreOptions()
				  .setType("file")
				  .setConfig(new JsonObject().put("path", configPath));
		
		ConfigRetriever retriever = ConfigRetriever.create(vertx,
			    new ConfigRetrieverOptions().addStore(fileStore).setScanPeriod(scanPeriod));
		retriever.listen(new Handler<ConfigChange>() {
			@Override
			public void handle(ConfigChange event) {
			  log.info("���ø���");
			  JsonObject previous = event.getPreviousConfiguration();
			  log.info("ԭ���ã�"+previous.toString());
			  JsonObject conf = event.getNewConfiguration();
			  log.info("�����ã�"+conf.toString());
			  //���¼���
			  initConfig(conf);
			  // �ж��Ƿ���Ҫ����kafka����
			  reConnectKafka(previous, conf);
			  resetCacheConf(conf);
			}
		});		
	}
	/**
	 * ����Kafka ����
	 */
	private void initKafka() {
	    // Create the consumer
		log.info("��ʼ����kafka");
	    consumer = KafkaReadStream.create(vertx, kafkaJsonConf.getMap());
	    // sub topics
	    log.info("kafka ����topics");


		consumer.subscribe(topicsSet, s -> {
			boolean bOk = s.succeeded();
			String smsg = String.format("subscribe topic[%s], ״̬[%s]", String.valueOf(strTopics), String.valueOf(bOk) );
			log.info(smsg);
		});


		log.info("kafka ��������ʼ��");


		consumer.handler(msg -> {
			String strTopicName = msg.topic();
			String logId        = Util.getUid();
			String startTime    = Util.getTime("HH:mm:ss.SSS");

			IpsMessageService ipsMessageService = new IpsMessageService(sysConf, logId);

			ipsMessageService.processKafkaMsg(msg, vertx, (kafkaJson, respJson) -> {
				moniterLog(kafkaJson, respJson, strTopicName, logId, startTime);
				MonitorJson.writeJson(kafkaJson, respJson);
			});


		});





		log.info("kafka �쳣��������ʼ��");
		// kakfa exception handle
		consumer.exceptionHandler(new Handler<Throwable>() {
			@Override
			public void handle(Throwable event) {
				log.error("��ȡ���쳣��Ϣ:" + event.getMessage());
				log.error("��ȡ���쳣��Ϣ", event);
			}
		});
	}
	/**
	 * kafka ����
	 */
	private void reConnectKafka(JsonObject oldConf, JsonObject newConf ) {
		
		JsonObject kafkaOldConf = oldConf.getJsonObject("kafka");
		//�¾� kafka ����һ�����ж�
		if(!kafkaOldConf.equals(this.kafkaJsonConf)){
			log.info("�¾�kafka������һ�£���������kafka����");
			log.info("����Kafka����");
			log.info("�ر�ԭ����");
			consumer.close(new Handler<AsyncResult<Void>>() {
				@Override
				public void handle(AsyncResult<Void> event) {
					log.info("kafka�ر�״̬��"+ event.succeeded());
					initKafka();
				}
			});
		}else {
			log.info("�¾�kafka����һ�£�������kafka����");
		}
	}
	
	@Override
	public void stop(Future<Void> stopFuture) throws Exception {
		log.info(" -- STOP IPS MESSAGE Verticle -- ");
		consumer.unsubscribe();
		consumer.close();
	}

	
	/**
	 * monitor ��־��¼
	 * @param reqJson
	 * @param respJson
	 * @param logId
	 * @param startTime
	 */
	private void moniterLog(JsonObject reqJson, JsonObject respJson, String strTopicName, String logId, String startTime) {
		try {
			String endTime  = Util.getTime("HH:mm:ss.SSS");
			String tftxcode = Util.safeGetJsonString(reqJson, "tftxcode"    , "_");
			String dataFrom = Util.safeGetJsonString(reqJson, "datafrom"    , "_");
			String tranamt  = Util.safeGetJsonString(reqJson, "tftxmony"    , "_");
			String tfcardno = Util.safeGetJsonString(reqJson, "tfcardno"    , "_"); tfcardno = Util.maskStr(tfcardno, 6, 4);
			String tfteacct = Util.safeGetJsonString(reqJson, "tfteacct"    , "_");
			String tfmccode = Util.safeGetJsonString(reqJson, "tfmccode"    , "_");
			String termid   = Util.safeGetJsonString(reqJson, "tftermid"    , "_");
			String chsDesc  = Util.safeGetJsonString(reqJson, "hwgChsDesc"  , "_"); //��������

			String tftranstype    = Util.safeGetJsonString(reqJson, "tftranstype"   , "_");
			String msgid          = Util.safeGetJsonString(reqJson, "msgid"         , "_");
			String transaction_id = Util.safeGetJsonString(reqJson, "transaction_id", "_");

			String retcode = Util.safeGetJsonString(respJson, "retcode"  , "_");
			String retmsg  = Util.safeGetJsonString(respJson, "retmsg"   , "_");

			StringBuffer sb = new StringBuffer();
			String mysep    = " ";
			sb.append(startTime).append(mysep)
					.append( endTime).append(mysep)
					.append( logId).append(mysep)
					.append( Util.normalizeField(strTopicName    , 14, ' ') ).append(mysep)
					.append( Util.normalizeField(tftranstype     , 3 , ' ') ).append(mysep)
					.append( Util.normalizeField(chsDesc         , 10, ' ') ).append(mysep)

					.append( Util.normalizeField(tftxcode        , 16, ' ') ).append(mysep)
					.append( Util.normalizeField(dataFrom        , 10, ' ') ).append(mysep)
					.append( Util.normalizeField(tranamt         , 13, ' ') ).append(mysep)
					.append( Util.normalizeField(tfcardno        , 19, ' ') ).append(mysep)
					.append( Util.normalizeField(tfteacct        , 22, ' ') ).append(mysep)
					.append( Util.normalizeField(tfmccode        , 8 , ' ') ).append(mysep)
					.append( Util.normalizeField(termid          , 8 , ' ') ).append(mysep)
					.append( Util.normalizeField(retcode         , 4 , ' ') ).append(mysep)
					.append( Util.normalizeField(transaction_id  , 35, ' ') ).append(mysep)
					.append( retmsg )
					;
			monitor.info(sb.toString());


		} catch (Exception e) {
			String msg = String.format("moniterLog�쳣[%s]", Util.getStacktrackInfo(e));
			log.info( msg );
		}
	}
}
