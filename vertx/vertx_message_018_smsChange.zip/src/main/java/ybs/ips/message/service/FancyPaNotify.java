package ybs.ips.message.service;

import io.vertx.core.AsyncResult;
import io.vertx.core.Future;
import io.vertx.core.Handler;
import io.vertx.core.Vertx;
import io.vertx.core.json.JsonObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ybs.ips.message.constant.ConstantSYS;
import ybs.ips.message.util.*;

import java.util.Date;

/**
 * �����[  �����[�����[    �����[ �������������[
 * �����U  �����U�����U    �����U�����X�T�T�T�T�a
 * ���������������U�����U ���[ �����U�����U  �������[
 * �����X�T�T�����U�����U�������[�����U�����U   �����U
 * �����U  �����U�^�������X�������X�a�^�������������X�a
 * �^�T�a  �^�T�a �^�T�T�a�^�T�T�a  �^�T�T�T�T�T�a
 * Created by huwenguang on 2018/5/31.
 */
public class FancyPaNotify {
    private Logger logPATrace   = LoggerFactory.getLogger( "loggerPaTrace" );
    private Logger logPAMonitor = LoggerFactory.getLogger( "loggerPaMonitor" );

    private LogFormat    lF;
    private String       logId;
    private Vertx        vertx;
    private JsonObject   sysConf;

    public FancyPaNotify(Vertx vertx, String logId, JsonObject sysConf){
        this.vertx     = vertx;
        this.logId     = logId;
        this.sysConf   = sysConf;
        this.lF = new LogFormat(logId);
    }

    public void increaseSendTimes(JsonObject kafkaJson){
        int paNotifyMaxCount_json = Util.safeGetJsonInt(kafkaJson, ConstantSYS.JSONKEY_paNotifyMaxCount, 0);
        int addAfterCount = paNotifyMaxCount_json + 1;
        kafkaJson.put(ConstantSYS.JSONKEY_paNotifyMaxCount, addAfterCount);
    }

    public void resendMsg2Kafka(JsonObject kafkaJson){
        increaseSendTimes(kafkaJson);

        JsonObject kafkaconf = sysConf.getJsonObject("kafka");
        String topicPA       = Util.safeGetJsonString(sysConf, "paNotifyTopic", "");
        String strResend     = kafkaJson.toString();
        FancyKafkaProducer producer = new FancyKafkaProducer(vertx, kafkaconf, logId);
        producer.sendMsg2Kafka(topicPA, strResend, ar->{
            String msgSimon = String.format("��дkafka��Ϣ���[%s], д����[%s]", String.valueOf(ar.succeeded()), DeSensi.Aes(strResend) );
            logPATrace.info( lF.format(msgSimon) );
        });
    }

    public boolean isThisMsgTimeAllowedToProcess(JsonObject kafkaJson, JsonObject sysConf, Date nowtime){
        String strTimeStart = Util.safeGetJsonString(kafkaJson, ConstantSYS.JSONKEY_timeStart, "");
        Date timeStart = Util.timeGetDateFromString(strTimeStart, "yyyyMMddHHmmss");
        if(null != timeStart){
            int paTimeToLive = Util.safeGetJsonInt(sysConf, ConstantSYS.JSONKEY_paTimeToLive, 86400);

            if(Util.timeGetDateDiffSecs(timeStart, nowtime) > paTimeToLive){
                return false;
            }
        }


        return true;
    }

    public boolean isThisMsgAllowedSendTimes(JsonObject kafkaJson){
        int paNotifyMaxCount_conf = Util.safeGetJsonInt(sysConf  , ConstantSYS.JSONKEY_paNotifyMaxCount, 0);
        int paNotifyMaxCount_json = Util.safeGetJsonInt(kafkaJson, ConstantSYS.JSONKEY_paNotifyMaxCount, 0);
        if(paNotifyMaxCount_conf > 0 && paNotifyMaxCount_json > paNotifyMaxCount_conf){
            String smsg = String.format("��������������ʹ���[%s], ��ǰ�Ѿ����͵Ĵ���[%s], �Ѿ�����������������",
                    String.valueOf(paNotifyMaxCount_conf), String.valueOf(paNotifyMaxCount_json) );
            logPATrace.info( lF.format(smsg) );
            return false;
        }
        return true;
    }


    public String getPaNotifyMonitor(JsonObject kafkaJson, String retcodePm, String retmsgPm, String startTime){
        StringBuffer sb = new StringBuffer();
        String mysep    = " ";

        String endTime  = Util.getTime("HH:mm:ss.SSS");
        String mcssn    = Util.safeGetJsonString(kafkaJson, "mcssn"      , "_");
        String tranamt  = Util.safeGetJsonString(kafkaJson, "tranamt"    , "_");
        String termid   = Util.safeGetJsonString(kafkaJson, "termid"     , "_");
        String settdate = Util.safeGetJsonString(kafkaJson, "settdate"   , "_");

        sb.append(startTime).append(mysep)
                .append(endTime).append(mysep)
                .append( Util.normalizeField(mcssn       , 16, ' ') ).append(mysep)
                .append( Util.normalizeField(tranamt     , 11, ' ') ).append(mysep)
                .append( Util.normalizeField(termid      , 8 , ' ') ).append(mysep)
                .append( Util.normalizeField(settdate    , 14, ' ') ).append(mysep)
                .append( Util.normalizeField(retcodePm   , 4 , ' ') ).append(mysep)
                .append(retmsgPm)
                ;

        return sb.toString();
    }

    public boolean isMsgLastSendTimeBigThanSpan(JsonObject kafkaJson, JsonObject sysConf, Date nowtime){
        try{
            String msgLastSendTime = Util.safeGetJsonString(kafkaJson, "paMessageLastSendTime", "");
            int paNotifySpan = Util.safeGetJsonInt(sysConf, ConstantSYS.JSONKEY_paNotifySpan, 180);

            if(Util.isEmptyString(msgLastSendTime)){
                return true;
            }

            Date dateLastSendTime = Util.timeGetDateFromString(msgLastSendTime, "yyyyMMddHHmmss");
            if(Util.timeGetDateDiffSecs(dateLastSendTime, nowtime) >= paNotifySpan){
                return true;
            }

        }catch (Exception e){
            return true;
        }

        return false;
    }
    public boolean isMsgLastSendTimeSmallThanSpan(JsonObject kafkaJson, JsonObject sysConf, Date nowtime){
        return !isMsgLastSendTimeBigThanSpan(kafkaJson, sysConf, nowtime);
    }

    public void sendNotification2PingAn(String urlOfPm, int timeout, JsonObject kafkaJson, Handler<AsyncResult<String>> resultHandler){
        Future<String> ft = Future.future();
        ft.setHandler(resultHandler);

        kafkaJson.put("modulename", "ips_message");

        //region �����Ϣ̫�ɲ�������
        Date nowtime     = Util.timeNow();
        if(!isThisMsgTimeAllowedToProcess(kafkaJson, this.sysConf, nowtime)){
            String msgAdam = "������Ϣ̫�ɲ�������";
            ft.fail(new Throwable(msgAdam));
            return;
        }
        //endregion

        //region ��Ϣ��������ʹ�������������
        if(!isThisMsgAllowedSendTimes(kafkaJson)){
            String msgAdam = "������Ϣ�Ѿ���������ʹ���";
            ft.fail(new Throwable(msgAdam));
            return;
        }
        //endregion

        int paNotifySpan = Util.safeGetJsonInt(sysConf, ConstantSYS.JSONKEY_paNotifySpan, 180);
        int timerSpan    = paNotifySpan * 1100;

        //region ��Ϣû�г���ʱ������ֻ�ز�kafka
        if(isMsgLastSendTimeSmallThanSpan(kafkaJson, this.sysConf, Util.timeNow())){
            String msgSimon = "������Ϣ���̫�̲�����pmֻ�ز�kafka";
            logPATrace.info(lF.format(msgSimon));
            ft.fail(new Throwable(msgSimon));

            this.vertx.setTimer(timerSpan, id -> {
                try{ resendMsg2Kafka(kafkaJson); }catch (Exception e){
                    String msgAdam = String.format("����kafka�쳣[%s]\n[%s]", e.getMessage(), Util.getStacktrackInfo(e));
                    logPATrace.info(lF.format(msgAdam));
                }
            });
        }
        //endregion

        //region ��ϢΪ��һ�λ��߳�����ʱ���������Է���
        else {
            //���Է�����Ϣ�����������ʱ��
            kafkaJson.put("paMessageLastSendTime", Util.timeNowyyyyMMddHHmmss());

            String strSend= Util.json2KeyValue(kafkaJson);
            FancyUrl furl = new FancyUrl(urlOfPm);
            HttpUtil hu   = new HttpUtil(vertx, logId, furl.scheme, furl.host, furl.port, furl.uri, timeout, ConstantSYS.GBK);
            String msgDavid = String.format("��pm[%s] ��ʱʱ��[%s] ������Ϣ[%s]", String.valueOf(urlOfPm), String.valueOf(timeout), DeSensi.Aes(strSend) );
            logPATrace.info( lF.format(msgDavid) );


            String startTime  = Util.getTime("HH:mm:ss.SSS");

            hu.post(strSend, (s, handler, c) -> {
                String msgSimon = String.format("���յ�pm��Ӧ[%s]", String.valueOf(s) ); msgSimon = DeSensi.Aes(msgSimon);
                logPATrace.info( lF.format(msgSimon) );


                JsonObject jo = JsonParse.parse(s);
                String rcPM = Util.safeGetJsonString(jo, "retcode", "");
                String rmPM = Util.safeGetJsonString(jo, "retmsg" , "");

                String strMonitor = getPaNotifyMonitor(kafkaJson, rcPM, rmPM, startTime);
                logPAMonitor.info(lF.format(strMonitor));

                if(ConstantSYS.SUCCESS.equals(rcPM)){
                    ft.complete("ƽ��֪ͨ�ɹ�");
                }else{
                    String msgAdam = String.format("pmƽ��֪ͨ���ز�Ϊ�ɹ�[%s]", String.valueOf(rcPM) );
                    logPATrace.info(lF.format(msgAdam));

                    ft.fail(new Throwable(msgAdam));

                    this.vertx.setTimer(timerSpan, id -> {
                        try{ resendMsg2Kafka(kafkaJson); }catch (Exception e){
                            String msgElliot = String.format("����kafka�쳣[%s]\n[%s]", e.getMessage(), Util.getStacktrackInfo(e));
                            logPATrace.info(lF.format(msgElliot));
                        }
                    });
                }
            });
        }
        //endregion



    }
}
