package ybs.ips.message.service;

import io.vertx.core.AsyncResult;
import io.vertx.core.Future;
import io.vertx.core.Handler;
import io.vertx.core.Vertx;
import io.vertx.core.json.JsonObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ybs.ips.message.constant.ConstantSYS;
import ybs.ips.message.util.*;

import java.util.*;

/**
 * �����[  �����[�����[    �����[ �������������[
 * �����U  �����U�����U    �����U�����X�T�T�T�T�a
 * ���������������U�����U ���[ �����U�����U  �������[
 * �����X�T�T�����U�����U�������[�����U�����U   �����U
 * �����U  �����U�^�������X�������X�a�^�������������X�a
 * �^�T�a  �^�T�a �^�T�T�a�^�T�T�a  �^�T�T�T�T�T�a
 * Created by huwenguang on 2018/11/23.
 */
public class FancyZhongBaoXin {
    private LogFormat    lF;
    private String       logId;
    private Vertx        vertx;
    private JsonObject   sysConf;
    private Logger log = LoggerFactory.getLogger(getClass());

    public FancyZhongBaoXin(Vertx vertx, String logId, JsonObject sysConf){
        this.vertx     = vertx;
        this.logId     = logId;
        this.sysConf   = sysConf;
        this.lF = new LogFormat(logId);
    }

    public void payBillNumberNcaspQuery(String payBillNumber, String urlOfCasp, int timeout, JsonObject kafkaJson, Handler<AsyncResult<Boolean>> resultHandler){
        Future<Boolean> ft = Future.future();
        ft.setHandler(resultHandler);

        String settdate         = Util.safeGetJsonString(kafkaJson, "trandt", Util.timeNowyyyyMMddHHmmss());
        JsonObject joNcaspQuery = new JsonObject().put("payno", payBillNumber);
        joNcaspQuery.put("querydate", settdate);


        String strSend= Util.json2KeyValue(joNcaspQuery);
        FancyUrl furl = new FancyUrl(urlOfCasp);
        HttpUtil hu   = new HttpUtil(vertx, logId, furl.scheme, furl.host, furl.port, furl.uri, timeout, ConstantSYS.GBK);
        String msgDavid = String.format("��pm[%s] ��ʱʱ��[%s] ������Ϣ[%s]", String.valueOf(urlOfCasp), String.valueOf(timeout), String.valueOf(strSend) );
        msgDavid = DeSensi.Aes(msgDavid);
        log.info( lF.format(msgDavid) );

        hu.post(strSend, (s, handler, c) -> {
            String msgSimon = String.format("���յ�pm��Ӧ[%s]", String.valueOf(s) ); msgSimon = DeSensi.Aes(msgSimon);
            log.info( lF.format(msgSimon) );

            JsonObject jo  = JsonParse.parse(s);
            String rcNcasp = Util.safeGetJsonString(jo, "retcode", "");
            String rmNcasp = Util.safeGetJsonString(jo, "retmsg" , "");
            if(Util.isEmptyJsonObject(jo) || Util.isEmptyString(rcNcasp)){
                String msgBrysen = "����ncasp��ѯδ��";
                log.info( lF.format(msgBrysen) );
                ft.fail(new Throwable(msgBrysen));
            }else{
                if(Util.safeStringEquals(rcNcasp, ConstantSYS.SUCCESS)){
                    String msgRocky = String.format("������[%s]������ѯ��Ȩ�ɹ�", String.valueOf(rcNcasp) );
                    log.info( lF.format(msgRocky) );
                    ft.complete(Boolean.TRUE);
                }else{
                    String msgRocky = String.format("������[%s]��������ѯ��Ȩʧ��", String.valueOf(rcNcasp));
                    log.info(lF.format(msgRocky));
                    ft.complete(Boolean.FALSE);
                }

            }

        });
    }

    public boolean isThisMsgTimeAllowedToProcess(JsonObject kafkaJson, JsonObject sysConf, Date nowtime){
        String strTimeStart = Util.safeGetJsonString(kafkaJson, ConstantSYS.JSONKEY_timeStart, "");
        Date timeStart = Util.timeGetDateFromString(strTimeStart, "yyyyMMddHHmmss");
        if(null != timeStart){
            int paTimeToLive = Util.safeGetJsonInt(sysConf, ConstantSYS.JSONKEY_paTimeToLive, 86400);

            if(Util.timeGetDateDiffSecs(timeStart, nowtime) > paTimeToLive){
                return false;
            }
        }


        return true;
    }


    public JsonObject getPMJson(JsonObject kafkaJson){
        JsonObject joPM = new JsonObject();
        Set<String> pmKeys = new HashSet<>();
        pmKeys.add("mcssn");
        pmKeys.add("tranamt");
        pmKeys.add("billid");
        pmKeys.add("termid");
        pmKeys.add("intype");
        pmKeys.add("settdate");
        //pmKeys.add("func");
        //pmKeys.add("mccode");
        //pmKeys.add("payno");
        //pmKeys.add("cardno");
        //pmKeys.add("bankno");
        for(String key : pmKeys){
            String value = Util.safeGetJsonString(kafkaJson, key, "");
            joPM.put(key, value);
        }

        JsonObject joMercMemo = new JsonObject();

        //decrypt cardno
        String cardno = Util.safeGetJsonString(kafkaJson, "cardno", "");
        String bankno = Util.safeGetJsonString(kafkaJson, "bankno", "");
        String payno  = Util.safeGetJsonString(kafkaJson, ConstantSYS.JSONKEY_zbxPayBillNO, "");
        cardno = DeSensi.decrypt(cardno);
        //joPM.put("cardno", cardno);
        joMercMemo.put("cardno"  , cardno);
        joMercMemo.put("bankcode", bankno);
        joMercMemo.put("payno"   , payno);

        joPM.put("mercmemo", joMercMemo.toString());

        //overwrite func to 004
        joPM.put("func", "004");

        //overwrite mccode
        String mccode = Util.safeGetJsonString(sysConf, ConstantSYS.CONF_zhongBaoXinMccode, "");
        joPM.put("mccode", mccode);

        return joPM;
    }

    public boolean isThisRetcodeAsSuccess(String retcode){
        boolean bSuccess = false;
        Set<String> setSuccess = new HashSet<>();
        setSuccess.add(ConstantSYS.SUCCESS);
        if(setSuccess.contains(retcode)){
            bSuccess = true;
        }

        return bSuccess;
    }

    public String getZbxPMString(JsonObject kafkaJson){
        JsonObject joPm      = getPMJson(kafkaJson);
        String strSend       = Util.json2KeyValue(joPm);

        return strSend;
    }

    public void sendMsg2PM(String urlOfPm, int timeout, JsonObject kafkaJson, Handler<AsyncResult<String>> resultHandler){
        Future<String> ft = Future.future();
        ft.setHandler(resultHandler);

        String strSend= getZbxPMString(kafkaJson);
        FancyUrl furl = new FancyUrl(urlOfPm);
        HttpUtil hu   = new HttpUtil(vertx, logId, furl.scheme, furl.host, furl.port, furl.uri, timeout, ConstantSYS.GBK);
        String msgDavid = String.format("��pm[%s] ��ʱʱ��[%s] ������Ϣ[%s]", String.valueOf(urlOfPm), String.valueOf(timeout), String.valueOf(strSend) );
        msgDavid = DeSensi.Aes(msgDavid);
        log.info( lF.format(msgDavid) );

        hu.post(strSend, (s, handler, c) -> {
            String msgSimon = String.format("���յ�pm��Ӧ[%s]", String.valueOf(s) ); msgSimon = DeSensi.Aes(msgSimon);
            log.info( lF.format(msgSimon) );

            JsonObject jo = JsonParse.parse(s);
            String rcPM = Util.safeGetJsonString(jo, "retcode", "");
            String rmPM = Util.safeGetJsonString(jo, "retmsg" , "");
            if(isThisRetcodeAsSuccess(rcPM)){
                String msgRocky = String.format("pm������[%s]֪ͨ�ɹ�", String.valueOf(rcPM) );
                log.info( lF.format(msgRocky) );
                ft.complete(msgRocky);
            }else{
                String msgRocky = String.format("pm������[%s]֪ͨʧ��", String.valueOf(rcPM));
                log.info(lF.format(msgRocky));
                ft.fail(new Throwable(msgRocky));
            }

        });
    }

    public void processZhongBaoXin(String urlOfPm, int timeout, JsonObject kafkaJson, Handler<AsyncResult<String>> resultHandler){
        Future<String> ft = Future.future();
        ft.setHandler(resultHandler);
        String strMonkeyMsg;

        String payBillNumber = Util.safeGetJsonString(kafkaJson, ConstantSYS.JSONKEY_zbxPayBillNO, "");
        strMonkeyMsg = String.format("kafka���ݻ�ȡ���б���֧����������[%s]", String.valueOf(payBillNumber)); strMonkeyMsg = DeSensi.Aes(strMonkeyMsg);
        log.info(lF.format(strMonkeyMsg));

        //region ֧��������Ϊ�ղ�������
        if(Util.isEmptyString(payBillNumber)){
            String smsg = "kafka�������ȡ��֧��������Ϊ�ղ�������";
            log.info(lF.format(smsg));
            ft.fail(new Throwable( smsg ));
            return;
        }
        //endregion

        //region �����Ϣ̫�ɲ�������
        Date nowtime     = Util.timeNow();
        if(!isThisMsgTimeAllowedToProcess(kafkaJson, this.sysConf, nowtime)){
            String msgAdam = "������Ϣ̫�ɲ�������";
            log.info(lF.format(msgAdam));
            ft.fail(new Throwable(msgAdam));
            return;
        }
        //endregion


        kafkaJson.put(ConstantSYS.JSONKEY_zbxAuthed, "authed");
        kafkaJson.put("messageLastSendTime"        , Util.timeNowyyyyMMddHHmmss());

        sendMsg2PM(urlOfPm, timeout, kafkaJson, arpm -> {
            if(arpm.succeeded()){
                String msgRocky = String.format("pm֪ͨ��Ϣ�ɹ�[%s]", String.valueOf(arpm.result()) );
                log.info(lF.format(msgRocky));
                ft.complete(msgRocky);
            }else{
                String msgRocky = String.format("pm֪ͨ��Ϣʧ��[%s]", String.valueOf(arpm.cause().getMessage()) );
                log.info(lF.format(msgRocky));
                ft.fail(new Throwable(msgRocky));

            }
        });




    }


    public void resendMsg2Kafka(JsonObject kafkaJson){
        JsonObject kafkaconf = sysConf.getJsonObject("kafka");
        String kafkaTopic    = Util.safeGetJsonString(sysConf, ConstantSYS.CONF_zhongBaoXinTopic, "");
        String strResend     = kafkaJson.toString();
        FancyKafkaProducer producer = new FancyKafkaProducer(vertx, kafkaconf, logId);
        producer.sendMsg2Kafka(kafkaTopic, strResend, ar->{
            String msgSimon = String.format("��дkafka��Ϣ���[%s], д����[%s]", String.valueOf(ar.succeeded()), String.valueOf(strResend) );
            msgSimon = DeSensi.Aes(msgSimon);
            log.info( lF.format(msgSimon) );
        });
    }
}
