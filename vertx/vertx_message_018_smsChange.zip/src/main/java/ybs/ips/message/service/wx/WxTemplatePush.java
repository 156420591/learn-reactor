package ybs.ips.message.service.wx;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.vertx.core.Handler;
import io.vertx.core.Vertx;
import io.vertx.core.json.JsonObject;
import ybs.ips.message.constant.ConstantSYS;
import ybs.ips.message.handler.HttpHandler;
import ybs.ips.message.util.*;

import java.io.PrintWriter;
import java.io.StringWriter;

/**
* @author zhangjifeng
* @create 2018��1��4�� ����1:26:12
* @email  414512194@qq.com
* @desc  
*/

public class WxTemplatePush {
	// trace log
	private Logger log = LoggerFactory.getLogger(getClass());
	
	private String retryCode,logId,HOST,URI;
	private LogFormat lF;
	private int PORT,TIMEOUT;
	//retryTimePeriod ��λ��
	private Integer retryTimes,retryTimePeriod;
	private String scheme;
	
	public WxTemplatePush(JsonObject jsonConf, String logId) {
		
		this.retryTimes = jsonConf.getInteger("retryTimes", 0);
		this.retryTimePeriod = jsonConf.getInteger("retryTimePeriod",0);
		this.retryCode = jsonConf.getString("retryCode");
		this.TIMEOUT = jsonConf.getInteger("timeout",0);
		this.scheme = jsonConf.getString("scheme");
		this.HOST    = jsonConf.getString("host");
		this.PORT = jsonConf.getInteger("port");
		this.URI = jsonConf.getString("templateMessageUri");
		
		this.logId = logId;
		this.lF = new LogFormat(logId);
	}
	
	private String packReq(JsonObject kafkaJson, JsonObject param) {
		JsonObject json = new JsonObject();

		try{
			json.put("touser", kafkaJson.getString("openid"));
			json.put("template_id", param.getString("template_id"));
			json.put("topcolor", "#FF0000");

			String msgTemplate = param.getString("msg_template");

			JsonObject cJson = new JsonObject();
			cJson.mergeIn(kafkaJson, true);
			cJson.mergeIn(param, true);
			cJson.put("tftxmony", Util.formatAmt(cJson.getString("tftxmony","0"))) ;


			JsonObject joDBTemplate = new JsonObject(msgTemplate);
			JsonObject data = WxtemplateParse.parseTempAndPack(cJson, joDBTemplate );
			json.put("data", data);
		}catch (Exception ex){
			String stackTrace = Util.getStacktrackInfo(ex);
			String msg = String.format("packReq��΢�Ű��쳣[%s]", String.valueOf(stackTrace) );
			this.log.info(lF.format(msg));
		}

		return json.toString();
	}
	

	/**
	 * ΢�Ŵ���
	 * @param msg
	 * @param vertx
	 */
	public void process(JsonObject kafkaJson, JsonObject param, String accessToken, Vertx vertx, Handler<JsonObject> respHandler ){
		log.info(lF.format("΢������ģ����Ϣ"));
		String sendBody = packReq(kafkaJson, param);

		String msg = String.format("΢����������[%s]", DeSensi.Aes(sendBody) );
		log.info(lF.format(msg) );


		HttpUtil httpPost = new HttpUtil(vertx, logId, scheme, HOST, PORT, URI+"?access_token="+accessToken, TIMEOUT, ConstantSYS.UTF8);
		httpPost.post(sendBody, new HttpHandler() {
			@Override
			public void handle(String respStr, HttpHandler httpHandler, Integer cnt) {
				log.info(lF.format("΢���������"));

				JsonObject jsonObject = JsonParse.parse(respStr);
				int errcode = jsonObject.getInteger("errcode",-1);
				String retmsg = jsonObject.getString("errmsg");
				String retcode = "0000";
				retmsg = "���ͳɹ�";
				if (errcode != 0){
					log.info(lF.format("��Ϣ����ʧ��"));
					retcode = "8999";
					retmsg = "��Ϣ����ʧ�ܣ���ȡ΢����Ӧʧ��";
				}
				log.info(lF.format("retcode:"+retcode));
				if ( retryCode.contains(retcode) && cnt <= retryTimes ){
					log.info(lF.format("��� "+ retryTimePeriod +" ms"));
					vertx.setTimer(retryTimePeriod, id -> {
						log.info(lF.format("���Ե�"+cnt+"��"));
						httpPost.post(sendBody, httpHandler);
					});
				}else {
					JsonObject respJson = new JsonObject();
					respJson.put("retcode", retcode);
					respJson.put("retmsg", retmsg);
					respJson.put("msgid", jsonObject.getLong("msgid")+"");
					respHandler.handle(respJson);
				}
			}
		});
	}
}
