package ybs.ips.message.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.vertx.core.AsyncResult;
import io.vertx.core.Future;
import io.vertx.core.Handler;
import io.vertx.core.Vertx;
import io.vertx.core.json.JsonArray;
import io.vertx.core.json.JsonObject;
import io.vertx.ext.asyncsql.MySQLClient;
import io.vertx.ext.sql.SQLClient;
import io.vertx.ext.sql.UpdateResult;
import ybs.ips.message.constant.ConstantSYS;
import ybs.ips.message.util.LogFormat;
import ybs.ips.message.util.Util;

public class JsttSmsMysqlService {

	private Logger logger = LoggerFactory.getLogger(JsttSmsMysqlService.class);
	
	private JsonObject sysConf;
	private LogFormat lF;
	private SQLClient sqlClient;
	
	public JsttSmsMysqlService() {
	}
	
	public JsttSmsMysqlService(JsonObject sysConf, Vertx vertx, String logId) {
		this.sysConf = sysConf;
		this.lF = new LogFormat(logId);

		JsonObject mysqlJsonConf = sysConf.getJsonObject("mysql_jstt");
		sqlClient = MySQLClient.createShared(vertx, mysqlJsonConf, "mysql_jstt");
	}
	
	private int getTid(JsonObject kafkaJson) {
		int tid = 0;
		int tidWhenError = 99999999;
		String tftxcode = Util.safeGetJsonString(kafkaJson, "tftxcode", "00000000");
		
		try {
//			tftxcode = tftxcode.substring(tftxcode.length()-8, tftxcode.length());
			tftxcode = Util.takeRight(tftxcode, 8);
			tid = Integer.parseInt(tftxcode);
		}catch(Exception ex) {
			tid = tidWhenError;
		}
		
		return tid;
	}

	public String getChineseStatus(int iSendStatus){
		String chsStatus = "����֪ͨʧ��";

		if(ConstantSYS.SNDSTATUS_SUCCESS == iSendStatus){
			chsStatus = "����֪ͨ�ɹ�";
		}
		return chsStatus;
	}

	
	public void insertJSTT_NOTIFY_HISTORY(JsonObject kafkaJson, Handler<AsyncResult<String>> resultHandler) {
		Future<String> ft = Future.future();
		ft.setHandler(resultHandler);
		
		String strJieShuan = Util.safeGetJsonString(sysConf, "jieshuanType", "");
		boolean bJieshuan  = Util.isJieShuanTransType(strJieShuan, kafkaJson);
		if(!bJieshuan) {
			String msg = "�ǳ��⳵������ţ������mysql";
			logger.info(lF.format(msg));
			ft.complete(msg);
			return;
		}
		
		int iSendStatus = Util.safeGetJsonInt(kafkaJson, ConstantSYS.JSONKEY_sendStatus, ConstantSYS.SNDSTATUS_FAIL);
		String errormsg = getChineseStatus(iSendStatus);
		errormsg = Util.safeSubString(errormsg, 0, 128);


		String fromuser = Util.safeGetJsonString(kafkaJson, "sms_fromuser", "");
		fromuser = Util.safeSubString(fromuser, 0, 40);

		String desc = String.format("����������ˮΪ%s����Ϣ", Util.safeGetJsonString(kafkaJson, "tftxcode", ""));
		desc = Util.safeSubString(desc, 0, 50);

		int taskid         = getTid(kafkaJson);
		String nowtime     = Util.timeNowyyyyMMddHHmmss();
		String TOUSER      = Util.safeGetJsonString(kafkaJson, "pyeemobno", "");
		String sms_content = Util.safeGetJsonString(kafkaJson, "sms_content", ""); sms_content = Util.safeSubString(sms_content, 0, 512);
		
		String sql = "INSERT INTO `JSTT_NOTIFY_HISTORY` (`TID`,`SENDDT`,`STATUS`,`TOUSER`,`FROMUSER`,`CONTENT`,`ERRORMSG`,`DESC`) VALUES (?,?,?,?,?,?,?,?)";


		JsonArray params = new JsonArray()
				.add(taskid)
				.add(nowtime)
				.add(iSendStatus)
				.add(TOUSER)
				.add(fromuser)
				.add(sms_content)
				.add(errormsg)
				.add(desc)
				;

				
		sqlClient.updateWithParams(sql, params, res -> {
			if(res.succeeded()) {
			    UpdateResult updateResult = res.result();
			    String msg = "���ż�¼��JSTT_NOTIFY_HISTORY�ɹ�";
                logger.info(lF.format(msg+"��Ӱ������:" + updateResult.getUpdated()));
                ft.complete(msg);
			}else {
				String msg = "���ż�¼��JSTT_NOTIFY_HISTORYʧ��";
                logger.error(lF.format(msg));
                ft.fail(msg);
			}
		});
	}
}
