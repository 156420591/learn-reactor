package ybs.ips.message.service.wx;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.vertx.core.Handler;
import io.vertx.core.Vertx;
import io.vertx.core.json.JsonObject;
import ybs.ips.message.constant.ConstantSYS;
import ybs.ips.message.service.FancyService;
import ybs.ips.message.service.FancySms;
import ybs.ips.message.util.LogFormat;
import ybs.ips.message.util.Util;

/**
* @author zhangjifeng
* @create 2017��12��25�� ����11:42:11
* @email  414512194@qq.com
* @desc  
*/

public class WxPushService {

	// trace log
	private Logger log = LoggerFactory.getLogger(getClass());
	
	private String logId;
	private LogFormat lF;
	private JsonObject wxConf;
	
	public WxPushService(JsonObject wxConf, String logId) {
		this.wxConf = wxConf;
		this.logId = logId;
		this.lF = new LogFormat(logId);
	}


}
