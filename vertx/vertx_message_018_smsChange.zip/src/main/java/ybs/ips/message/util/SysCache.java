package ybs.ips.message.util;

import io.vertx.core.Vertx;
import io.vertx.core.json.JsonObject;
import io.vertx.core.shareddata.LocalMap;
import io.vertx.core.shareddata.SharedData;

/**
* @author zhangjifeng
* @create 2018��1��5�� ����2:43:25
* @email  414512194@qq.com
* @desc  
*/

public class SysCache {
	
	private static final String START_TIME = "startTime";
	private static final String VALID_PERIOD = "validPeriod";

	/**
	 * ��ȡ����cache
	 * @param vertx
	 * @param cacheKey
	 * @param valueKey
	 * @return
	 */
	public static JsonObject getCache(Vertx vertx, String cacheKey, String valueKey) {
		SharedData sd = vertx.sharedData();
		LocalMap<String, JsonObject> map = sd.getLocalMap(cacheKey);
		JsonObject cache = map.get(valueKey);
		JsonObject cacheJson = null;
		if (cache != null){
			String startTime = cache.getString(START_TIME);
			int validPeriod = cache.getInteger(VALID_PERIOD);
			String now = Util.getTime("yyyyMMddHHmmssSSS");
			int useTime = Util.calTime(startTime, now);
			if ( useTime > validPeriod ){
				return cacheJson;
			}
			cacheJson = cache;
			cacheJson.remove(START_TIME);
			cacheJson.remove(VALID_PERIOD);
		}
		return cacheJson;
	}
	
	public static LocalMap<String, JsonObject> getKeyMap(Vertx vertx, String cacheKey) {
		SharedData sd = vertx.sharedData();
		LocalMap<String, JsonObject> map = sd.getLocalMap(cacheKey);
		return map;
	}
	
	/**
	 * ���û���
	 * @param vertx
	 * @param cacheKey ����key
	 * @param valueKey ����key
	 * @param value ��������
	 * @param expireTime ������Чʱ��,��λ��
	 */
	public static void setCache(Vertx vertx, String cacheKey, String valueKey, JsonObject value, int expireTime){
		try{
			SharedData sd = vertx.sharedData();
			LocalMap<String, JsonObject> map = sd.getLocalMap( cacheKey );
			value.put(START_TIME, Util.getTime("yyyyMMddHHmmssSSS"));
			value.put(VALID_PERIOD, expireTime);
			map.put(valueKey, value);
		}catch (Exception ex){
		}
	}
}
