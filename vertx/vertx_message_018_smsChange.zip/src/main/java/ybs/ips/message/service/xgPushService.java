package ybs.ips.message.service;

import io.vertx.core.AsyncResult;
import io.vertx.core.Handler;
import io.vertx.core.Vertx;
import io.vertx.core.json.JsonArray;
import io.vertx.core.json.JsonObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ybs.ips.message.constant.ConstantSYS;
import ybs.ips.message.handler.HttpHandler;
import ybs.ips.message.util.*;

import java.util.HashMap;
import java.util.Map;

public class xgPushService {

	private Logger log = LoggerFactory.getLogger(xgPushService.class);

	private JsonObject xgConf;
	private LogFormat lF;
	private Vertx vertx;
	private String logId;
	private String scheme, host, uri;
	private String username, password;
	private int port, timeout;

	private String enKey = "9510598948615840";
	private String iv = "0000000000000000";

	Map channelMap = new HashMap(){{
		put("unionpay", "01");
		put("wechat", "02");
		put("alipay", "03");
	}};

	public xgPushService(JsonObject sysConf, Vertx vertx, String logId) {
		this.xgConf = sysConf.getJsonObject("xg");
		this.logId = logId;
		this.vertx = vertx;

        this.lF = new LogFormat(logId);
        this.scheme = xgConf.getString("scheme");
        this.host = xgConf.getString("host");
        this.port = xgConf.getInteger("port");
        this.uri = xgConf.getString("uri");
        this.timeout = xgConf.getInteger("timeout");
        this.username = xgConf.getString("username");
        this.password = xgConf.getString("password");
	}

	private String packReq(JsonObject data) {

		JsonObject obj = new JsonObject();

		obj.put("platform", "android");
		obj.put("audience_type", "account");
		obj.put("account_list", new JsonArray().add(Util.safeGetJsonString(data, "tftermno", "")));
		obj.put("message_type", "message");

		JsonObject message = new JsonObject();
		JsonObject content = new JsonObject();

		content.put("type", "URLCODE_RESULT");
		content.put("orderId", Util.safeGetJsonString(data, "tfbankrefno", ""));
		content.put("payTime", Util.safeGetJsonString(data, "tfdate", Util.getTime("yyyyMMddHHmmss")).substring(4, 14));
		content.put("mcssn", Util.safeGetJsonString(data, "tftxcode", ""));
		content.put("payType", channelMap.get(Util.safeGetJsonString(data, "tfchannel", "")));
		content.put("txnAmt", Util.amountToFen(Util.safeGetJsonString(data, "tftxmony", "")));
		content.put("extAmount", "0");
		content.put("stan", Util.safeGetJsonString(data, "tftermssn", ""));
		content.put("tid", Util.safeGetJsonString(data, "tftermno", ""));
		content.put("mid", Util.safeGetJsonString(data, "tftmccode", ""));
		try {
			message.put("content", Aes128.encrypt(content.toString(), enKey, iv));
		} catch (Exception e) {
			log.error(lF.format(String.format("msgcontent[%s] encrypt failed: %s", content.toString(), e.getMessage())));
		}

		obj.put("message", message);
        
		return obj.toString();
	}

	public void handle(JsonObject kafkaJson, Handler<AsyncResult<String>> resultHandler) {
		String sendBody = packReq(kafkaJson);

        HttpUtil httpPost = new HttpUtil(vertx, logId, scheme, host, port, uri, timeout, ConstantSYS.UTF8);
        httpPost.postWithAuth(sendBody, new HttpHandler() {
            @Override
            public void handle(String respStr, HttpHandler httpHandler, Integer cnt) {
                log.info(lF.format("�Ÿ룺" + respStr));
            }
        }, username, password);

	}
}
