package ybs.ips.message.util;

import io.vertx.core.json.DecodeException;
import io.vertx.core.json.JsonObject;

/**
* @author zhangjifeng
* @create 2018��1��4�� ����1:44:33
* @email  414512194@qq.com
* @desc  
*/

public class JsonParse {

	public static JsonObject parse(String json){
		try{
			JsonObject obj = new JsonObject(json);
			return obj;
		}catch(DecodeException e){
			return new JsonObject();
		}
	}
}
