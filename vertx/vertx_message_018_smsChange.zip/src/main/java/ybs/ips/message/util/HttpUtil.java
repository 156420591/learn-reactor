package ybs.ips.message.util;

import io.netty.handler.codec.base64.Base64Encoder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.vertx.core.Handler;
import io.vertx.core.Vertx;
import io.vertx.core.buffer.Buffer;
import io.vertx.core.http.HttpClient;
import io.vertx.core.http.HttpClientOptions;
import io.vertx.core.http.HttpClientRequest;
import io.vertx.core.http.HttpClientResponse;
import sun.misc.BASE64Encoder;
import ybs.ips.message.handler.HttpHandler;

import java.util.Base64;


/**
* @author zhangjifeng
* @create 2018��1��4�� ����11:42:12
* @email  414512194@qq.com
* @desc  
*/

public class HttpUtil {

	// trace log
	private Logger log = LoggerFactory.getLogger(getClass());
	private String logId;
	private LogFormat lF;
	private String HOST,URI;
	private int PORT,TIMEOUT,callCnt;
	private final int DEFAULT_TIMEOUT = 30 * 1000;
	private Vertx vertx;
	private String scheme,charset;
	
	/**
	 * post �������ݰ�
	 * @param logId
	 * @param Host ��ַ
	 * @param Port �˿�
	 * @param Timeout ��λ�룬Ĭ�� 30��
	 */
	public HttpUtil(Vertx vertx, String logId, String scheme, String Host, int Port, String uri, int Timeout, String charset) {
		this.logId = logId;
		this.lF = new LogFormat(logId);
		this.HOST = Host;
		this.PORT = Port;
		this.URI = uri;
		int timeout = DEFAULT_TIMEOUT;
		if ( Timeout != 0 ){
			timeout = Timeout * 1000;
		}
		this.TIMEOUT = timeout;
		this.vertx = vertx;
		this.callCnt = 0;
		this.scheme = scheme;
		this.charset = charset;
	}
	
	public void post( String sendBody, HttpHandler httpHandler ){
		this.callCnt ++ ; // ���ô����ۼ�
		HttpClientOptions options = new HttpClientOptions().setKeepAlive(false);
		options.setDefaultHost(HOST).setDefaultPort(PORT);
		options.setConnectTimeout(TIMEOUT);

		
		if (scheme.contains("https")){
			options.setSsl(true).setVerifyHost(false).setTrustAll(true);
		}
		
		HttpClient httpClient = vertx.createHttpClient(options);
		HttpClientRequest request = httpClient.post(URI);

		String sendurl = scheme+"://"+HOST+":"+PORT+URI;
		String msg = String.format("����[%s], timeout[%s]��������[%s]",
				sendurl,
				String.valueOf(TIMEOUT),
				DeSensi.Aes(sendBody)
				);
		log.info(lF.format(msg));

		request.handler(new Handler<HttpClientResponse>() {
			@Override
			public void handle(HttpClientResponse response) {
				log.info("{} ״̬�� {}", logId, response.statusCode());
				response.bodyHandler(new Handler<Buffer>() {
					@Override
					public void handle(Buffer buffer) {
						String gbkStr = buffer.toString("GBK");
						String msgRet = String.format("[%s]����RESP:[%s]",
								sendurl,
								DeSensi.Aes(gbkStr)
								);
						log.info(lF.format( msgRet ));
						httpHandler.handle( gbkStr, httpHandler, callCnt );
					}
				});
			}
		});
		request.exceptionHandler(new Handler<Throwable>() {
			@Override
			public void handle(Throwable event) {
				String msgErrDavid = "ͨѶ�쳣:"+event.getMessage();
				log.info(lF.format(msgErrDavid));
				httpHandler.handle( msgErrDavid, httpHandler, callCnt );
			}
		});
		request.setTimeout(TIMEOUT);
		request.putHeader("content-type", "text/plain;charset="+this.charset);
		log.info(lF.format("REQ:"+ DeSensi.Aes(sendBody)));
		request.end(sendBody, this.charset);
	}

	public void postSetContentType( String sendBody, String contentType, HttpHandler httpHandler ){
		this.callCnt ++ ; // ���ô����ۼ�
		HttpClientOptions options = new HttpClientOptions().setKeepAlive(false);
		options.setDefaultHost(HOST).setDefaultPort(PORT);
		options.setConnectTimeout(TIMEOUT);


		if (scheme.contains("https")){
			options.setSsl(true).setVerifyHost(false).setTrustAll(true);
		}

		HttpClient httpClient = vertx.createHttpClient(options);
		HttpClientRequest request = httpClient.post(URI);

		String sendurl = scheme+"://"+HOST+":"+PORT+URI;
		String msg = String.format("����[%s], timeout[%s]��������[%s]",
				sendurl,
				String.valueOf(TIMEOUT),
				DeSensi.Aes(sendBody)
		);
		log.info(lF.format(msg));

		request.handler(new Handler<HttpClientResponse>() {
			@Override
			public void handle(HttpClientResponse response) {
				log.info("{} ״̬�� {}", logId, response.statusCode());
				response.bodyHandler(new Handler<Buffer>() {
					@Override
					public void handle(Buffer buffer) {
						String gbkStr = buffer.toString("GBK");
						String msgRet = String.format("[%s]����RESP:[%s]",
								sendurl,
								DeSensi.Aes(gbkStr)
						);
						log.info(lF.format( msgRet ));
						httpHandler.handle( gbkStr, httpHandler, callCnt );
					}
				});
			}
		});
		request.exceptionHandler(new Handler<Throwable>() {
			@Override
			public void handle(Throwable event) {
				String msgErrDavid = "ͨѶ�쳣:"+event.getMessage();
				log.info(lF.format(msgErrDavid));
				httpHandler.handle( msgErrDavid, httpHandler, callCnt );
			}
		});
		request.setTimeout(TIMEOUT);

		String setContentType = "text/plain;charset="+this.charset;
		if(contentType != null && !contentType.isEmpty()){
			setContentType = contentType + ";charset="+this.charset;
		}
		request.putHeader("content-type", setContentType);
		log.info(lF.format("REQ:"+ DeSensi.Aes(sendBody)));
		request.end(sendBody, this.charset);
	}

	public void postWithAuth( String sendBody, HttpHandler httpHandler, String username, String password ){
		this.callCnt ++ ; // ���ô����ۼ�
		HttpClientOptions options = new HttpClientOptions().setKeepAlive(false);
		options.setDefaultHost(HOST).setDefaultPort(PORT);
		options.setConnectTimeout(TIMEOUT);


		if (scheme.contains("https")){
			options.setSsl(true).setVerifyHost(false).setTrustAll(true);
		}

		HttpClient httpClient = vertx.createHttpClient(options);
		HttpClientRequest request = httpClient.post(URI);

		String sendurl = scheme+"://"+HOST+":"+PORT+URI;
		String msg = String.format("����[%s], timeout[%s]��������[%s]",
				sendurl,
				String.valueOf(TIMEOUT),
				DeSensi.Aes(sendBody)
		);
		log.info(lF.format(msg));

		request.handler(new Handler<HttpClientResponse>() {
			@Override
			public void handle(HttpClientResponse response) {
				log.info("{} ״̬�� {}", logId, response.statusCode());
				response.bodyHandler(new Handler<Buffer>() {
					@Override
					public void handle(Buffer buffer) {
						String gbkStr = buffer.toString("GBK");
						String msgRet = String.format("[%s]����RESP:[%s]",
								sendurl,
								DeSensi.Aes(gbkStr)
						);
						log.info(lF.format( msgRet ));
						httpHandler.handle( gbkStr, httpHandler, callCnt );
					}
				});
			}
		});
		request.exceptionHandler(new Handler<Throwable>() {
			@Override
			public void handle(Throwable event) {
//				log.error(lF.format("StackTrace"), event);
				String msgErrDavid = "ͨѶ�쳣:"+event.getMessage();
				log.info(lF.format(msgErrDavid));
				httpHandler.handle( msgErrDavid, httpHandler, callCnt );
			}
		});
		request.setTimeout(TIMEOUT);
		request.putHeader("content-type", "text/plain;charset="+this.charset);
		request.putHeader("Authorization", "Basic " + Base64.getEncoder().encodeToString((username + ":" + password).getBytes()));
		log.info(lF.format("REQ:"+ DeSensi.Aes(sendBody)));
		request.end(sendBody, this.charset);
	}

	public void get( HttpHandler httpHandler ){
		this.callCnt ++ ; // ���ô����ۼ�
		HttpClientOptions options = new HttpClientOptions().setKeepAlive(false);
		options.setDefaultHost(HOST).setDefaultPort(PORT);
		options.setConnectTimeout(TIMEOUT);
		
		if (scheme.contains("https")){
			options.setSsl(true).setVerifyHost(false).setTrustAll(true);
		}
		
		HttpClient httpClient = vertx.createHttpClient(options);
		HttpClientRequest request = httpClient.get(URI);
		
		log.info(lF.format("TIMEOUT:")+TIMEOUT);
		log.info(lF.format(scheme+"://"+HOST+":"+PORT+URI));

		request.handler(new Handler<HttpClientResponse>() {
			@Override
			public void handle(HttpClientResponse response) {
				log.info("{} ״̬�� {}", logId, response.statusCode());
				response.bodyHandler(new Handler<Buffer>() {
					@Override
					public void handle(Buffer buffer) {
						String gbkStr = buffer.toString("GBK");
						log.info(lF.format("RESP:"+gbkStr));
						httpHandler.handle( gbkStr, httpHandler, callCnt );
					}
				});
			}
		});
		request.exceptionHandler(new Handler<Throwable>() {
			@Override
			public void handle(Throwable event) {
				log.info(lF.format("ͨѶ�쳣:"+event.getMessage()));
				log.error(lF.format("StackTrace"), event);
				httpHandler.handle( null, httpHandler, callCnt );
			}
		});
		request.setTimeout(TIMEOUT);
		request.putHeader("content-type", "text/plain;charset="+this.charset);
		request.end("",this.charset);
	}
}
