package ybs.ips.message.demo;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.atomic.AtomicInteger;

/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements. See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import org.apache.kafka.clients.producer.Callback;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;

import io.vertx.core.json.JsonObject;

public class FileJson extends Thread {
    private final KafkaProducer<String, String> producer;
    private final String topic;
    private final Boolean isAsync;
    private List<String> dataList;
    private int size;
    private int CNT = 10;
    private AtomicInteger atomicInteger;

    public FileJson(String topic, Boolean isAsync, List<String> list, int workerId, AtomicInteger atomicInteger, int onc) {
        Properties props = new Properties();
      //  props.put("bootstrap.servers", KafkaProperties.KAFKA_SERVER_URL + ":" + KafkaProperties.KAFKA_SERVER_PORT);
        props.put("bootstrap.servers", KafkaProperties.KAFKA_SERVERS);
        props.put("client.id", "DemoProducer"+workerId);
        props.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
        props.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer");
        producer = new KafkaProducer<>(props);
        this.topic = topic;
        this.isAsync = isAsync;
        this.dataList = list;
        this.size     = list.size();
        this.atomicInteger = atomicInteger;
        this.CNT = onc;
    }

    public void run() {
        int messageNo = 1;
        while (true) {
        	
        	List<Integer> rand = Util.rand(CNT, size);
        	
        	for ( int i=0; i<rand.size(); ++i){
        		
        		
        		String PyeeAcctId = dataList.get(rand.get(i));
        		atomicInteger.compareAndSet(100000, 0);
        		int cns = atomicInteger.incrementAndGet();
        		String messageStr = "Message_" + cns;
        		
                Map<String, Object> mp = new HashMap<>();
                mp.put("tfcardno", "6228480000001234567");
                mp.put("tftermid", "888888889");
                mp.put("tftxmony", String.format("%d", cns));
                mp.put("tftmccode", "000861000000123456");
                mp.put("MrchntPltfrmNm", "�װ��²����̻�");
                mp.put("tfmccode", "666666");
              //  mp.put("PayeeAccId", "86100000012345672");
                SimpleDateFormat sdf = new SimpleDateFormat("MMddHHmmss");
            	String time = sdf.format(new Date());
                mp.put("tftxcode", time+String.format("%06d", cns));
                mp.put("tfcardtype", "CE");
                mp.put("PyeeAcctId", PyeeAcctId);
                mp.put("password", "123456");
                mp.put("PyerNm", "����"+messageNo);
                mp.put("IDTp", "01");
                mp.put("IDNo", "183456999999997896");
                mp.put("phoneno", "18812341234");
                mp.put("PyeeNm", "����");
                mp.put("tfacmony",String.format("%d", cns));
                
                messageStr = new JsonObject(mp).toString();
              
                long startTime = System.currentTimeMillis();
                if (isAsync) { // Send asynchronously
                    producer.send(new ProducerRecord<>(topic,
                    		cns+"",
                        messageStr), new DemoCallBackFile(startTime, cns+"", messageStr));
                }
                ++messageNo;
        	}
        	
            try {
				Thread.sleep(1*1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
        }
    }
}

class DemoCallBackFile implements Callback {

    private final long startTime;
    private final String key;
    private final String message;

    public DemoCallBackFile(long startTime, String key, String message) {
        this.startTime = startTime;
        this.key = key;
        this.message = message;
    }

    /**
     * A callback method the user can implement to provide asynchronous handling of request completion. This method will
     * be called when the record sent to the server has been acknowledged. Exactly one of the arguments will be
     * non-null.
     *
     * @param metadata  The metadata for the record that was sent (i.e. the partition and offset). Null if an error
     *                  occurred.
     * @param exception The exception thrown during processing of this record. Null if no error occurred.
     */
    public void onCompletion(RecordMetadata metadata, Exception exception) {
        long elapsedTime = System.currentTimeMillis() - startTime;
        if (metadata != null) {
            System.out.println(
                "message(" + key + ", " + message + ") sent to partition(" + metadata.partition() +
                    "), " +
                    "offset(" + metadata.offset() + ") in " + elapsedTime + " ms");
        } else {
            exception.printStackTrace();
        }
    }
}