package ybs.ips.message.service;

import io.vertx.core.AsyncResult;
import io.vertx.core.Handler;
import io.vertx.core.Vertx;
import io.vertx.core.json.JsonArray;
import io.vertx.core.json.JsonObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ybs.ips.message.constant.ConstantSYS;
import ybs.ips.message.handler.HttpHandler;
import ybs.ips.message.util.Aes128;
import ybs.ips.message.util.HttpUtil;
import ybs.ips.message.util.LogFormat;
import ybs.ips.message.util.Util;

import java.util.HashMap;
import java.util.Map;

public class JiguangPushService {

	private Logger log = LoggerFactory.getLogger(JiguangPushService.class);

	private JsonObject jiguangConf;
	private LogFormat lF;
	private Vertx vertx;
	private String logId;
	private String scheme, host, uri;
	private String username, password;
	private int port, timeout;

	private String enKey = "9510598948615840";
	private String iv = "0000000000000000";

	Map channelMap = new HashMap(){{
		put("unionpay", "01");
		put("wechat", "02");
		put("alipay", "03");
	}};

	public JiguangPushService(JsonObject sysConf, Vertx vertx, String logId) {
		this.jiguangConf = sysConf.getJsonObject("jiguang");
		this.logId = logId;
		this.vertx = vertx;

        this.lF = new LogFormat(logId);
        this.scheme = jiguangConf.getString("scheme");
        this.host = jiguangConf.getString("host");
        this.port = jiguangConf.getInteger("port");
        this.uri = jiguangConf.getString("uri");
        this.timeout = jiguangConf.getInteger("timeout");
        this.username = jiguangConf.getString("username");
        this.password = jiguangConf.getString("password");
	}

	private String packReq(JsonObject data) {

		JsonObject obj = new JsonObject();

		obj.put("platform", "android");

		JsonObject audience = new JsonObject();

		audience.put("alias", new JsonArray().add(Util.safeGetJsonString(data, "tftermno", "")));

		obj.put("audience", audience);

		JsonObject message = new JsonObject();

		JsonObject msg_content = new JsonObject();

		msg_content.put("type", "URLCODE_RESULT");
		msg_content.put("orderId", Util.safeGetJsonString(data, "tfbankrefno", ""));
		msg_content.put("payTime", Util.safeGetJsonString(data, "tfdate", Util.getTime("yyyyMMddHHmmss")).substring(4, 14));
		msg_content.put("mcssn", Util.safeGetJsonString(data, "tftxcode", ""));
		msg_content.put("payType", channelMap.get(Util.safeGetJsonString(data, "tfchannel", "")));
		msg_content.put("txnAmt", Util.amountToFen(Util.safeGetJsonString(data, "tftxmony", "")));
		msg_content.put("extAmount", "0");
		msg_content.put("stan", Util.safeGetJsonString(data, "tftermssn", ""));
		msg_content.put("tid", Util.safeGetJsonString(data, "tftermno", ""));
		msg_content.put("mid", Util.safeGetJsonString(data, "tftmccode", ""));


		try {
			message.put("msg_content", Aes128.encrypt(msg_content.toString(), enKey, iv));
		} catch (Exception e) {
			log.error(lF.format(String.format("msgcontent[%s] encrypt failed: %s",msg_content.toString(), e.getMessage())));
		}
		obj.put("message", message);

		return obj.toString();
	}

	/*
	curl --insecure -X POST -v https://bjapi.push.jiguang.cn/v3/push -H "Content-Type: application/json" -u "2361a5dcc57f0c5ca4aefa2b:6fb3319b1fbc035cedc2a554" -d '{"platform":"android","audience":{"alias":["98271720412442"]},"message":{"msg_content":"hHtTDmOMrUo5yN+W0BDSrKOVG19yzO9vQDNyZkMPydI="}}'
	 */

	public void handle(JsonObject kafkaJson, Handler<AsyncResult<String>> resultHandler) {

		String sendBody = packReq(kafkaJson);

        HttpUtil httpPost = new HttpUtil(vertx, logId, scheme, host, port, uri, timeout, ConstantSYS.UTF8);
        httpPost.postWithAuth(sendBody, new HttpHandler() {
            @Override
            public void handle(String respStr, HttpHandler httpHandler, Integer cnt) {
                log.info(lF.format("������Ӧ��" + respStr));
            }
        }, username, password);

	}
}
