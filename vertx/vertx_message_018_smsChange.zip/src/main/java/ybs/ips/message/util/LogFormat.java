package ybs.ips.message.util;

/**
* @author zhangjifeng
* @create 2017��12��25�� ����5:04:52
* @email  414512194@qq.com
* @desc  
*/

public class LogFormat {
	
	private String logId;

	public LogFormat(String logId) {
		this.logId = logId;
	}
	
	public String format( String str ) {
		String strnew = String.format("%s", String.valueOf(str) );
		String[] arrLines = strnew.split("\n");
		StringBuffer sb = new StringBuffer();
		for( String line : arrLines ){
			String anewline = String.format("%s %s\n", this.logId, String.valueOf(line) );
			sb.append(anewline);
		}

		String fStr = sb.toString();
		return fStr;
	}

	public String getLogId() {
		return logId;
	}

	public void setLogId(String logId) {
		this.logId = logId;
	}
	
}
