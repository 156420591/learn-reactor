package ybs.ips.message.handler;

/**
* @author zhangjifeng
* @create 2018��1��4�� ����11:56:59
* @email  414512194@qq.com
* @desc  
*/
public interface HttpHandler {

	public void handle(String respStr, HttpHandler httpHandler, Integer cnt);
}
