package ybs.ips.message.util;

import com.ybs.util.Aes128;

/**
* @author zhangjifeng
* @create 2018��1��11�� ����8:22:38
* @email  414512194@qq.com
* @desc  
*/

public class DeSensi {

	public static String Aes( String str ){
		try {
			if ( str == null){
				str = "";
			}
			return Aes128.encrypt(str);
		} catch (Exception e) {
			e.printStackTrace();
			return "";
		}
	}

	public static String decrypt(String strEncrypt) {
		String strPlain = strEncrypt;
		try{
			strPlain = Aes128.decrypt(strEncrypt);
		}catch (Exception e){
		}

		return strPlain;
	}
}
