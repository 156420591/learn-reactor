package ybs.ips.message.demo;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.ExecutionException;

/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements. See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import org.apache.kafka.clients.producer.Callback;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;

import io.vertx.core.json.JsonObject;

public class ProducerJson extends Thread {
    private final KafkaProducer<String, String> producer;
    private final String topic;
    private final Boolean isAsync;

    public ProducerJson(String topic, Boolean isAsync) {
        Properties props = new Properties();
      //  props.put("bootstrap.servers", KafkaProperties.KAFKA_SERVER_URL + ":" + KafkaProperties.KAFKA_SERVER_PORT);
        props.put("bootstrap.servers", KafkaProperties.KAFKA_SERVERS);
        props.put("client.id", "DemoProducer");
        props.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
        props.put("key.serializer.encoding", "GBK");
        props.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer");
        props.put("value.serializer.encoding", "GBK");
        producer = new KafkaProducer<>(props);
        this.topic = topic;
        this.isAsync = isAsync;
    }

    public void run() {
        int messageNo = 1;
        while (true) {
        	if(messageNo >=10000){
        		return;
        	}
            String messageStr = "Message_" + messageNo;
//            JsonObject jsonObject = new JsonObject();
//            jsonObject.put("cardno", "000"+messageNo);
//            jsonObject.put("ssn", UUID.randomUUID().toString().replaceAll("-", "")+ "_"+messageNo);
//            
//            messageStr = jsonObject.toString() ;
            
            Map<String, Object> mp = new HashMap<>();
            mp.put("tfcardno", "6228480000001234567");
            mp.put("tftermid", "888888889");
            mp.put("tftxmony", String.format("%d.01", messageNo));
            mp.put("tftmccode", "000861000000123456");
            
            mp.put("mrchntpltfrmnm", "�װ��²����̻�");
          
          //  mp.put("PayeeAccId", "86100000012345672");
            SimpleDateFormat sdf = new SimpleDateFormat("MMddHHmmss");
        	String time = sdf.format(new Date());
            mp.put("tftxcode", time+String.format("%06d", messageNo));
            SimpleDateFormat sdf2 = new SimpleDateFormat("yyyyMMddHHmmss");
        	String time2 = sdf2.format(new Date());
            mp.put("tfdate", time2);
            //mp.put("tfcardtype", "CE");
            mp.put("pyeeacctid", "ybs020171213008351159");
            mp.put("password", "123456");
            mp.put("pyernm", "����"+messageNo);
            mp.put("idtp", "01");
            mp.put("idno", "183456999999997896");
            mp.put("phoneno", "18812341234");
            mp.put("pyeenm", "����");
            mp.put("tfacmony",String.format("%d", messageNo));
            mp.put("tfcardtype","WX");
            mp.put("tfmccode", "666666");
            mp.put("openid","o8A8iuKw_zNGquomLy7_3vczgs0A");
//            mp.put("openid", "ogmilwRJHjFy8rN1ho1QjPKHpEEc");
//            mp.put("tfmccode", "888888");
//            mp.put("openid", "omUElw_qy92d3e4nMDwcxyW_l1Ag");
//            mp.put("tfmccode", "000484");
            
            messageStr = new JsonObject(mp).toString();
            //messageStr = "{\"PyerAcctId\":\"861440300000000000\",\"InstgAcctNm\":\"�������װ��³��⳵ҵ�񱸸���\",\"tfacmony\":\"0.34\",\"tfmemo\":\"299007182-20171221164505.212\",\"tftxfnc\":\"3001\",\"tftermssn\":\"000002\",\"tfmerstu\":\"2\",\"bankauthcode\":\"\",\"InstgAcctId\":\"105440300000000000\",\"ResfdAcctIssrId\":\"861440300000000000\",\"tfcardsq\":\"\",\"tftxdeta\":\"0.34|0.0|0.00|0|\",\"tfbankstu\":\"\",\"banktradedate\":\"\",\"tfrlmony\":\"0.34\",\"PyeeAcctIssrId\":\"0800965840\",\"bankterminalttc\":\"\",\"PyerNm\":\"�������װ��³��⳵ҵ�񱸸���\",\"tfbalance\":\"\",\"discount_amt\":\"0\",\"tftermno\":\"299007182\",\"PyerAcctTp\":\"0\",\"tfonlinesq\":\"\",\"PyeeAcctId\":\"8610001034500000012\",\"tftrk3\":\"\",\"tfreqtno\":\"861\",\"tftxbatch\":\"\",\"tfmemo1\":\"0000000000000333333\",\"tfalgver\":\"\",\"tfcustno\":\"0|403792|\",\"tfsamid\":\"60007182\",\"bankterminalid\":\"\",\"tfteacct\":\"0000000000000333333\",\"tfofflinesq\":\"\",\"bankrefttc\":\"\",\"tfsamsq\":62261,\"tfic_tc\":\"\",\"tfcharge\":\"0.00\",\"tftxmony\":\"0.34\",\"tfcardno\":\"330000004\",\"tfafmony\":186.32,\"tfmertcc\":\"\",\"bankid\":\"\",\"tftxcode\":\"2017122116336866\",\"tfbizinfo\":\"35\",\"tftermttc\":\"000002\",\"bankcardno\":\"\",\"datafrom\":\"ICSAS\",\"tfcardtype\":\"33\",\"tflocstu\":\"2\",\"tfkeyver\":\"\",\"tfic_info\":\"464130394430443038343636414231333233453530313030303043453743443231313030303030313341304332423437303230303030303032323030303030303232303030303030433834383030303030353432303030303030303043453743443231313233333730423242343730433030303030303030303030303030303030303030303034323030303030303030303030303030333546333030303030303630303037313832353138303030303038343636414231333231464433344535\",\"tftmccode\":\"999999999999000485\",\"tftermid\":\"299007182|0000000039\",\"PyeeNm\":\"��ʦ��\",\"tftrk2\":\"\",\"tfacctdt\":\"20171221\",\"tfdate\":\"2017-12-21 16:49:14\",\"tfmerdate\":\"20171221164858\",\"tficc\":\"\",\"tfmccode\":\"666666\"}";
           // messageStr = "{\"PyerAcctId\":\"861440300000000000\",\"InstgAcctNm\":\"�������װ��³��⳵ҵ�񱸸���\",\"tfbackno\":\"0000\",\"tftermssn\":\"000843\",\"PyeeAcctIssrId\":\"0800965840\",\"requestsn\":\"2017122116337012\",\"tfdistcode\":\"\",\"discount_amt\":\"100\",\"tftermno\":\"42155423\",\"tftxfee\":\"0\",\"tfbnussn\":\"000843\",\"PyeeAcctId\":\"8610001034500000012\",\"tftxdeta\":\"\",\"tfcardtype\":\"WX\",\"tfteacct\":\"0000000000000555724\",\"old_uuid\":\"\",\"uuid\":\"2cdb4823-9b4a-4949-b06e-e36e3374e76f\",\"ResfdAcctIssrId\":\"861440300000000000\",\"tfbncode\":\"960075\",\"tffwdinsid\":\"0861111113\",\"tftxmony\":\"100\",\"tfcardno\":\"0000000000000000\",\"PyerNm\":\"�������װ��³��⳵ҵ�񱸸���\",\"tfdate\":\"20171221\",\"mersettcode\":\"\",\"tftxcode\":\"2017122116337012\",\"tfreqtno\":\"061\",\"tftermttc\":\"000843\",\"PyerAcctTp\":\"0\",\"datafrom\":\"NSERVER\",\"tfperdata\":\"\",\"tfmercdt\":\"20171221\",\"tfmemo_2bank\":\"\",\"tftermid\":\"42155423|000843\",\"tftmccode\":\"202019914297338\",\"tfrcvinsid\":\"0\",\"PyeeNm\":\"��ʦ��\",\"tfacqinsid\":\"0861111113\",\"tfacctdt\":\"20171221\",\"tfmccode\":\"010345\",\"InstgAcctId\":\"105440300000000000\",\"tfintype\":\"67\",\"tfacmony\":\"0010.00\"}";
            long startTime = System.currentTimeMillis();
            if (isAsync) { // Send asynchronously
                producer.send(new ProducerRecord<>(topic,
                    messageNo+"",
                    messageStr), new DemoCallBack2(startTime, messageNo+"", messageStr));
            } else { // Send synchronously
                try {
                    producer.send(new ProducerRecord<>(topic,
                        messageNo+"",
                        messageStr)).get();
                    System.out.println("Sent message: (" + messageNo + ", " + messageStr + ")");
                } catch (InterruptedException | ExecutionException e) {
                    e.printStackTrace();
                }
            }
            ++messageNo;
            try {
				Thread.sleep(5*1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
        }
    }
}

class DemoCallBack2 implements Callback {

    private final long startTime;
    private final String key;
    private final String message;

    public DemoCallBack2(long startTime, String key, String message) {
        this.startTime = startTime;
        this.key = key;
        this.message = message;
    }

    /**
     * A callback method the user can implement to provide asynchronous handling of request completion. This method will
     * be called when the record sent to the server has been acknowledged. Exactly one of the arguments will be
     * non-null.
     *
     * @param metadata  The metadata for the record that was sent (i.e. the partition and offset). Null if an error
     *                  occurred.
     * @param exception The exception thrown during processing of this record. Null if no error occurred.
     */
    public void onCompletion(RecordMetadata metadata, Exception exception) {
        long elapsedTime = System.currentTimeMillis() - startTime;
        if (metadata != null) {
            System.out.println(
                "message(" + key + ", " + message + ") sent to partition(" + metadata.partition() +
                    "), " +
                    "offset(" + metadata.offset() + ") in " + elapsedTime + " ms");
        } else {
            exception.printStackTrace();
        }
    }
}