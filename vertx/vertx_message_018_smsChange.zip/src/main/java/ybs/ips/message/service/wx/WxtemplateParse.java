package ybs.ips.message.service.wx;

import java.util.List;

import io.vertx.core.json.JsonObject;
import ybs.ips.message.util.Util;

/**
* @author zhangjifeng
* @create 2018��1��11�� ����6:00:34
* @email  414512194@qq.com
* @desc  
*/

public class WxtemplateParse {
	
	public static JsonObject parseTempAndPack(JsonObject kafkaJson,JsonObject obj) {
		JsonObject data = new JsonObject();
		
		JsonObject first = obj.getJsonObject("first");
		JsonObject firstPack = parse(kafkaJson, first);
		data.put("first", firstPack);
		
		JsonObject keywords = obj.getJsonObject("keywords");
		for(String key : keywords.fieldNames()){
			data.put(key, parse(kafkaJson, keywords.getJsonObject(key)));
		}
		
		JsonObject remark = obj.getJsonObject("remark");
		data.put("remark", parse(kafkaJson, remark));
		
		for(String key : data.fieldNames()){
			JsonObject rObj = data.getJsonObject(key, new JsonObject());
			String value = rObj.getString("value");
			List<String> rKey = Util.getQStr(value);
			for(int i=0; i< rKey.size(); ++i){
				String pKey = rKey.get(i);
				String pvalue = kafkaJson.getString(pKey,"");
				value = Util.formatReplace(value, pKey, pvalue);
			}
			data.getJsonObject(key, new JsonObject()).put("value", value);
		}
		return data;
	}

	private static JsonObject parse(JsonObject data ,JsonObject obj ){
		JsonObject ret = new JsonObject();
		if(obj == null || obj.size() == 0){
			return ret;
		}
		
		String value = obj.getString("value","");
		String color = obj.getString("color","#173177");
		JsonObject format = obj.getJsonObject("keyformat");
		if(format != null ) {
			for(String key : format.getMap().keySet()){
				String formatStr = (String) format.getMap().get(key);
				String tdate = data.getString(key);
				String formatDate = Util.formatDate(tdate, formatStr);
				value = Util.formatReplace(value, key, formatDate);
			}
		}
		ret.put("value", value);
		ret.put("color", color);
		return ret;
	}
}
