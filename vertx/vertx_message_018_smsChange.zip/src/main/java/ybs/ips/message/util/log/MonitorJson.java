package ybs.ips.message.util.log;

import java.io.UnsupportedEncodingException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.vertx.core.json.JsonObject;
import ybs.ips.message.constant.ConstantSYS;
import ybs.ips.message.util.Util;

/**
* @author zhangjifeng
* @create 2018��1��8�� ����11:25:36
* @email  414512194@qq.com
* @desc  
*/

public class MonitorJson {

	private static Logger log = LoggerFactory.getLogger("monitor-json");
	
	public static void writeJson(JsonObject kafkaJson, JsonObject respJson ){
		try {
			JsonObject data = new JsonObject();
			data.put("mcssn",              Util.safeGetJsonString(kafkaJson, "tftxcode"  , ""));
			data.put("ybs_term_id",        Util.safeGetJsonString(kafkaJson, "tftermid"    , ""));
			data.put("term_sn",            Util.safeGetJsonString(kafkaJson, "tftermttc"   , ""));
			data.put("term_sn",            Util.safeGetJsonString(kafkaJson, "tftermssn"   , ""));
			data.put("teacct" ,            Util.safeGetJsonString(kafkaJson, "tfteacct"    , ""));
			data.put("trace_no",           Util.safeGetJsonString(kafkaJson, "tfbnussn"    , ""));
			data.put("old_trace_no",       Util.safeGetJsonString(kafkaJson, "tfbnossn"    , ""));
			data.put("old_mcssn",          Util.safeGetJsonString(kafkaJson, "tfodcode"    , ""));
			data.put("ybs_mer_code",       Util.safeGetJsonString(kafkaJson, "tfmccode"    , ""));
			data.put("ext_mer_code",       Util.safeGetJsonString(kafkaJson, "tftmccode"   , ""));
			data.put("payer_bank_code",    Util.safeGetJsonString(kafkaJson, "tfbncode"    , ""));
			data.put("in_type",            Util.safeGetJsonString(kafkaJson, "tfintype"    , ""));
			data.put("pay_amt",            Util.safeGetJsonString(kafkaJson, "tftxmony"    , ""));
			data.put("payer_card_no",      Util.safeGetJsonString(kafkaJson, "tfcardno"    , ""));
			data.put("front_trans_type",   Util.safeGetJsonString(kafkaJson, "tfreqtno"    , ""));
			data.put("retcode",            Util.safeGetJsonString(kafkaJson, "tfbackno"    , ""));
			data.put("sett_date",          Util.safeGetJsonString(kafkaJson, "tfacctdt"    , ""));
			data.put("req_date_time",      Util.safeGetJsonString(kafkaJson, "tfdate"      , ""));
			data.put("ext_term_id",        Util.safeGetJsonString(kafkaJson, "tftermno"    , ""));
			data.put("acq_ins_id" ,        Util.safeGetJsonString(kafkaJson, "tfacqinsid"  , ""));
			data.put("sett_ins_id",        Util.safeGetJsonString(kafkaJson, "tffwdinsid"  , ""));
			data.put("rcv_ins_id" ,        Util.safeGetJsonString(kafkaJson, "tfrcvinsid"  , ""));
			data.put("pm_sett_date",       Util.safeGetJsonString(kafkaJson, "tfmercdt"    , ""));
			data.put("payer_card_type",    Util.safeGetJsonString(kafkaJson, "tfcardtype"  , ""));
			data.put("request_ssn",        Util.safeGetJsonString(kafkaJson, "requestsn"   , ""));
			data.put("trans_fee",          Util.safeGetJsonString(kafkaJson, "tftxfee"     , ""));
			data.put("uuid",               Util.safeGetJsonString(kafkaJson, "uuid"        , ""));
			data.put("old_uuid",           Util.safeGetJsonString(kafkaJson, "old_uuid"    , ""));
			data.put("pm_memo",            Util.safeGetJsonString(kafkaJson, "tfmemo"      , ""));
			data.put("pm_memo1",           Util.safeGetJsonString(kafkaJson, "tfmemo1"     , ""));
			data.put("tfperdata",          Util.safeGetJsonString(kafkaJson, "tfperdata"   , ""));
			data.put("transaction_id",     Util.safeGetJsonString(kafkaJson, "transaction_id"     , ""));
			data.put("out_transaction_id", Util.safeGetJsonString(kafkaJson, "out_transaction_id" , ""));
			data.put("discount_amt",       Util.safeGetJsonString(kafkaJson, "discount_amt"       , ""));

			data.put("retcode", Util.safeGetJsonString(respJson, "retcode" , ""));
			data.put("retmsg" , Util.safeGetJsonString(respJson, "retmsg"  , ""));
			String s = java.util.Base64.getEncoder().encodeToString(data.toString().getBytes(ConstantSYS.GBK));
			log.info(s);
		} catch (Exception e) {
		}
	}
}
