package ybs.ips.message.constant;

public class ConstantSYS {
	
	public static final String GBK = "GBK";
	public static final String UTF8 = "UTF-8";
	public static final String SYSCACHEMAP = "sys_cache_map";
	public static final String SUCCESS = "0000";

	public static final String PYS_WX   = "WX";
	public static final String PYS_AL   = "AL";
	public static final String PYS_ST   = "ST";
	public static final String PYS_LG   = "LG";

	public static final String SHUNT_k  = "K";
	public static final String ISYES    = "1";

	public static final String CONF_zhongBaoXinTopic            = "zhongBaoXinTopic";
	public static final String CONF_zhongBaoXinNcaspURL         = "zhongBaoXinNcaspURL";
	public static final String CONF_zhongBaoXinMccode           = "zhongBaoXinMccode";
	public static final String CONF_commonTopic                 = "commonTopic";
	public static final String CONF_sztJiguangTopic             = "sztJiguangTopic";

	public static final String CONF_paNotifyUrlOfPM             = "paNotifyUrlOfPM";
	public static final String CONF_paNotifyTimeout             = "paNotifyTimeout";

	public static final String JSONKEY_paNotifyMaxCount         = "paNotifyMaxCount";
	public static final String JSONKEY_timeStart                = "settdate";
	public static final String JSONKEY_paTimeToLive             = "paNotifyTimeToLive";
	public static final String JSONKEY_paNotifySpan             = "paNotifySpan";

	//����������ϢAES����KEY��IV
	public static final String JG_AESKEY                        = "9510598948615840";
	public static final String JG_AESIV                         = "0000000000000000";

	//�б���֧��������key
	public static final String JSONKEY_zbxPayBillNO             = "payno";
	public static final String JSONKEY_zbxAuthed                = "JSONKEY_zbxAuthed";

	public static final String JSONKEY_sendStatus               = "wxOrSmsSendStatus";
	public static final int    SNDSTATUS_SUCCESS                = 1;
	public static final int    SNDSTATUS_FAIL                   = 2;
}
