
package ybs.ips.message.demo;

public class Demo {

	public static void main(String[] args) {
        boolean isAsync = args.length == 0 || !args[0].trim().equalsIgnoreCase("sync");
        isAsync = true;
//        Producer producerThread = new Producer(KafkaProperties.TOPIC, isAsync);
//        producerThread.start();
        
        ProducerJson producerThread = new ProducerJson(KafkaProperties.TOPIC, isAsync);
        producerThread.start();
    }
}
