package ybs.ips.message.service.wx;

import io.vertx.core.Vertx;
import io.vertx.core.json.JsonObject;
import io.vertx.core.shareddata.LocalMap;
import io.vertx.core.shareddata.SharedData;
import ybs.ips.message.constant.ConstantWX;
import ybs.ips.message.util.Util;

/**
* @author zhangjifeng
* @create 2018��1��5�� ����2:43:25
* @email  414512194@qq.com
* @desc  
*/

public class AccTokenCache {

	private final static int validPeriod = 110 * 60;// 110 * 60; //�� 1Сʱ50������Чʱ�䣬΢����Чʱ��2Сʱ
	
	public static String getCacheToken(Vertx vertx, String appid) {
		SharedData sd = vertx.sharedData();
		LocalMap<String, JsonObject> map = sd.getLocalMap(ConstantWX.WXACCTOKENKEY);
		JsonObject cache = map.get(appid);
		String token = "";
		if (cache != null){
			String startTime = cache.getString("startTime");
			String now = Util.getTime("yyyyMMddHHmmssSSS");
			int useTime = Util.calTime(startTime, now);
			if ( useTime > validPeriod ){
				return token;
			}
			token = cache.getString("token");
		}
		return token;
	}
	
	public static void setCacheToken(Vertx vertx, String appId, String appSecret, String token){
		SharedData sd = vertx.sharedData();
		LocalMap<String, JsonObject> map = sd.getLocalMap(ConstantWX.WXACCTOKENKEY);
		JsonObject cache = new JsonObject();
		cache.put("appId", appId);
		cache.put("appSecret", appSecret);
		cache.put("token", token);
		cache.put("startTime", Util.getTime("yyyyMMddHHmmssSSS"));
		map.put(appId, cache);
	}
}
