package ybs.ips.message.service.wx;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.vertx.core.Handler;
import io.vertx.core.Vertx;
import io.vertx.core.json.JsonObject;
import io.vertx.core.shareddata.LocalMap;
import ybs.ips.message.constant.ConstantWX;
import ybs.ips.message.util.LogFormat;
import ybs.ips.message.util.SysCache;
import ybs.ips.message.util.Util;

/**
* @author zhangjifeng
* @create 2018��1��5�� ����12:26:33
* @email  414512194@qq.com
* @desc  
*/

public class IntAccTokenCache {
	private Logger log = LoggerFactory.getLogger(getClass());
	private Vertx vertx;
	private Integer refreshPeriod = 50*60*1000;// 50*60*1000; // ��λ���룬 50 ����ˢ��һ��
	private JsonObject wxConf;
	private LogFormat lf;
	
	public IntAccTokenCache(Vertx vertx, JsonObject wxConf ) {
		this.vertx = vertx;
		this.wxConf = wxConf;
	}
	
	private void initParam(JsonObject conf) {
		log.info("ԭ����"+wxConf.toString());
		if (conf !=null){
			wxConf = conf;
			log.info("�²���"+wxConf.toString());
		}
	}
	
	public void start(){
		initParam(null);
		log.info("����΢��tokenˢ��, ˢ�¼��"+ refreshPeriod + " ms");
		this.vertx.setPeriodic(refreshPeriod, id -> {
				lf = new LogFormat(Util.getUid());
				log.info(lf.format("����ˢ��Wx access token"));
				refresh();
		});
	}
	
	public void restart(JsonObject newConf){
		if( wxConf.equals(newConf) ){
			log.info("wx�¾ɲ���һ��");
			return;
		}
		log.info("�¾ɲ�����һ�£�ˢ�²���");
		initParam( newConf );
	}
	
	private void refresh() {
		LocalMap<String, JsonObject> map = SysCache.getKeyMap(vertx, ConstantWX.WXACCTOKENKEY);
		if(map.size() == 0){
			log.info(lf.format("����wx token��������"));
		}
		for(String key: map.keySet()){
			log.info(lf.format("ˢ�� APPID "+key+" token"));
			WxAccToken wxAccToken = new WxAccToken(wxConf, lf.getLogId());
			JsonObject p = map.get(key);
			log.info(lf.format(p.toString()));
			String appId = p.getString("appId");
			String appSecret = p.getString("appSecret");
			wxAccToken.process(appId, appSecret, vertx, new Handler<JsonObject>() {
				@Override
				public void handle(JsonObject event) {
					if ("0000".equals(event.getString("retcode"))){
						String accessToken = event.getString("accessToken");
						log.info(lf.format("����token����"));
						JsonObject cacheObj = new JsonObject();
						cacheObj.put("appId", appId);
						cacheObj.put("appSecret", appSecret);
						cacheObj.put("accessToken", accessToken);
						SysCache.setCache(vertx, ConstantWX.WXACCTOKENKEY, appId, cacheObj, ConstantWX.WXACCTOKENKEY_EXPIRETIME);
					}else{
						log.error(lf.format("ˢ��ʧ��"));
					}
				}
			});
		}
	}
}
