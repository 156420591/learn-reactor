package ybs.ips.message.service;

import io.vertx.core.AsyncResult;
import io.vertx.core.Future;
import io.vertx.core.json.JsonArray;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.vertx.core.Handler;
import io.vertx.core.Vertx;
import io.vertx.core.json.JsonObject;
import ybs.ips.message.constant.ConstantError;
import ybs.ips.message.constant.ConstantMYSQL;
import ybs.ips.message.constant.ConstantSYS;
import ybs.ips.message.handler.IpsMessageHandler;
import ybs.ips.message.service.commontopic.NotifyBase;
import ybs.ips.message.service.commontopic.NotifyGetter;
import ybs.ips.message.tddl.TddlMongo;
import ybs.ips.message.tddl.TddlService;
import ybs.ips.message.util.*;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
* @author zhangjifeng
* @create 2017��12��25�� ����11:42:11
* @email  414512194@qq.com
* @desc  
*/

public class IpsMessageService {

	// trace log
	private Logger log = LoggerFactory.getLogger(IpsMessageService.class);
	
	private JsonObject wxJsonConf,tddlJsonConf,sysConf;
	private String logId;
	private LogFormat lF;
	
	public IpsMessageService() {
	}
	
	public IpsMessageService(JsonObject sysConf, String logId) {
		this.sysConf = sysConf;
		this.wxJsonConf  = sysConf.getJsonObject("wx");
		this.tddlJsonConf = sysConf.getJsonObject("tddl");
		this.logId = logId;
		this.lF = new LogFormat(logId);
	}


	public void processKafkaMsg(ConsumerRecord<String, String> msg, Vertx vertx, IpsMessageHandler ipsMessageHandler ){
		logKafkaData(msg);
		JsonObject kafkaJson = JsonParse.parse(msg.value());
		if (kafkaJson.size() == 0){
			log.error(lF.format("����kafka����ʧ��"));
			ipsMessageHandler.handle(new JsonObject(), ConstantError.PARSE_KAFKA_MSG_ERROR);
			return;
		}

		safeProcessKafka(msg, kafkaJson, vertx, ipsMessageHandler);
	}

	public void safeProcessKafka(ConsumerRecord<String, String> msg, JsonObject kafkaJson, Vertx vertx, IpsMessageHandler ipsMessageHandler) {
		try {
			addMoreInfo2KafkaJson(kafkaJson);

			String strKafkaTopicName = msg.topic();

			processKafkaLogic(kafkaJson, vertx, strKafkaTopicName, ipsMessageHandler);

		} catch (Exception e) {
			String smsg = String.format("ips message�ڲ��쳣[%s]", e.getMessage() );
			log.info(lF.format(smsg ) );
			log.info(lF.format( Util.getStacktrackInfo(e) ) );

			JsonObject jo = new JsonObject().put("retcode", "IM08").put("retmsg", smsg);
			ipsMessageHandler.handle(kafkaJson, jo);
		}
	}


	public boolean isNServerMsgTooOld(Date nowtime, String tfdate){
		boolean bTooOld = false;

		Date dtNServerTfdate = Util.timeGetDateFromString(tfdate, "yyyyMMddHHmmss");

		long allowedTwoDays = 86400 * 2;
		if(null != dtNServerTfdate && Util.timeGetDateDiffSecs(dtNServerTfdate, nowtime) > allowedTwoDays ){
			bTooOld = true;
		}

		return bTooOld;
	}


	public JsonObject getZhongBaoXinMonitorJson(JsonObject kafkaJson){
		JsonObject joZbx = new JsonObject();
		joZbx.put("hwgChsDesc"         , "�б���");
		joZbx.put("dataFrom"           , "zbx");
		joZbx.put("tftxcode"           , Util.safeGetJsonString(kafkaJson, "mccode", "_"));
		joZbx.put("tranamt"            , Util.safeGetJsonString(kafkaJson, "tranamt", "_"));
		joZbx.put("tfteacct"           , Util.safeGetJsonString(kafkaJson, "billid", "_"));
		joZbx.put("tfmccode"           , Util.safeGetJsonString(kafkaJson, "mccode", "_"));
		joZbx.put("termid"             , Util.safeGetJsonString(kafkaJson, "termid", "_"));

		return joZbx;
	}


	public void processKafkaLogic(JsonObject kafkaJson, Vertx vertx, String strKafkaTopicName, IpsMessageHandler ipsMessageHandler) {

		if( isCommonTopic(sysConf, strKafkaTopicName)){
			log.info(lF.format("commonTopic������ʼ"));
			String pkg_type = Util.safeGetJsonString(kafkaJson, "pkg_type", "");
			kafkaJson.put("hwgChsDesc", pkg_type);

			NotifyBase cpu = new NotifyGetter().getProcessor(pkg_type, this.logId, this.sysConf, vertx);
			cpu.process(kafkaJson, ipsMessageHandler);

		} else if( isSztJiguangTopic(sysConf, strKafkaTopicName) ){

			log.info(lF.format("sztJiguang topic������ʼ"));
			processSztJiguang(kafkaJson, vertx, ipsMessageHandler);

		} else if( isPingAnNotification(sysConf, strKafkaTopicName) ){
			kafkaJson.put("hwgChsDesc", "ƽ��֪ͨ");

			//ƽ��֪ͨ��������⳵һ������ȥ�ش�������Ϊƽ��֪ͨʧ�ܵĻ�����kafkaҪ�ظ�����

			processPANotification(kafkaJson, vertx, ipsMessageHandler);

		}else if( isZhongBaoXin(sysConf, strKafkaTopicName) ){
			kafkaJson.put("hwgChsDesc", "�б���");

			processZhongBaoXin(kafkaJson, vertx, ipsMessageHandler);

		}else if( isNoFeeling(sysConf, kafkaJson) ){
			kafkaJson.put("hwgChsDesc", "�޸�");

			processNoFeelingWrapper(kafkaJson, vertx, strKafkaTopicName, ipsMessageHandler);

		}else {
			kafkaJson.put("hwgChsDesc", "���⳵");

			processOfficialAccountWrapper(kafkaJson, vertx, strKafkaTopicName, ipsMessageHandler);

		}
	}

	public void processZhongBaoXin(JsonObject kafkaJson, Vertx vertx, IpsMessageHandler ipsMessageHandler){
		log.info(lF.format("�б���kafka��Ϣ����"));

		FancyZhongBaoXin zbx = new FancyZhongBaoXin(vertx, logId, sysConf);
		String urlOfPm       = Util.safeGetJsonString(sysConf, ConstantSYS.CONF_paNotifyUrlOfPM, "");
		int timeout          = Util.safeGetJsonInt(sysConf, ConstantSYS.CONF_paNotifyTimeout, 35);
		zbx.processZhongBaoXin(urlOfPm, timeout, kafkaJson, ar->{
			JsonObject joZbx = getZhongBaoXinMonitorJson(kafkaJson);

			if(ar.failed()){
				String smsg = String.format("�б���pm֪ͨʧ��[%s]", ar.cause().getMessage() );
				log.info(lF.format(smsg) );

				JsonObject jo = new JsonObject().put("retcode", "IM08").put("retmsg", smsg);
				ipsMessageHandler.handle(joZbx, jo);

			}else{
				log.info(lF.format( "�б���pm��Ϣ���ͳɹ�" ) );

				JsonObject jo = new JsonObject().put("retcode", "0000").put("retmsg", "�б���pm��Ϣ���ͳɹ�");
				ipsMessageHandler.handle(joZbx, jo);
			}
		});
	}

	public void processSztJiguang(JsonObject kafkaJson, Vertx vertx, IpsMessageHandler ipsMessageHandler) {

		FancyCommonJiGuang worker = new FancyCommonJiGuang(sysConf, vertx, logId);

		String audience = Util.safeGetJsonString(kafkaJson, "tfJgAudience", "");
		String msgBase64= Util.safeGetJsonString(kafkaJson, "tfJgMessage" , "");
		log.info("get tfJgAudience is [{}]", audience);
		log.info("get tfJgMessage is [{}]", msgBase64);

		JsonObject joMonitorReq = getJiguangMonitorJson(kafkaJson);

		String message  = "";
		byte[] byDecoded  = Util.base64decode(msgBase64);
		String strDecoded = new String(byDecoded);
		try{
			message = Aes128.encrypt(strDecoded, ConstantSYS.JG_AESKEY, ConstantSYS.JG_AESIV);
		}catch (Exception e){}
		log.info("final send jiguang msg is [{}]", message);


		String platform = "android";
		worker.send2JiGuang(audience, platform, message, ar -> {
			if(ar.failed()){
				String smsg = String.format("��������ʧ��[%s]", ar.cause().getMessage() );
				log.info(lF.format(smsg) );

				JsonObject jo = new JsonObject().put("retcode", "IM08").put("retmsg", smsg);
				ipsMessageHandler.handle(joMonitorReq, jo);
			}else{
				JsonObject jo = new JsonObject().put("retcode", "0000").put("retmsg", "�������ͳɹ�");
				ipsMessageHandler.handle(joMonitorReq, jo);
			}

		});
	}

    public void processPANotification(JsonObject kafkaJson, Vertx vertx, IpsMessageHandler ipsMessageHandler) {
        log.info(lF.format("ƽ��֪ͨ��Ϣ") );

        FancyPaNotify pa = new FancyPaNotify(vertx, logId, sysConf);
        String urlOfPm   = Util.safeGetJsonString(sysConf, ConstantSYS.CONF_paNotifyUrlOfPM, "");
        int timeout      = Util.safeGetJsonInt(sysConf, ConstantSYS.CONF_paNotifyTimeout, 35);

        pa.sendNotification2PingAn(urlOfPm, timeout, kafkaJson, ar-> {
            if(ar.failed()){
                String smsg = String.format("ƽ��֪ͨʧ��[%s]", ar.cause().getMessage() );
                log.info(lF.format(smsg) );

                JsonObject jo = new JsonObject().put("retcode", "IM08").put("retmsg", smsg);
                ipsMessageHandler.handle(kafkaJson, jo);
            }else{
                log.info(lF.format( "ƽ��֪ͨ���ͳɹ�" ) );

                JsonObject jo = new JsonObject().put("retcode", "0000").put("retmsg", "ƽ��֪ͨ���ͳɹ�");
                ipsMessageHandler.handle(kafkaJson, jo);
            }
        });
    }

	public boolean isPingAnNotification(JsonObject sysConf, String strKafkaTopicName){
		String paNotifyTopic   = Util.safeGetJsonString(sysConf, "paNotifyTopic", "");
		Set<String> setPaTopic = getSepSets(paNotifyTopic);
		if(Util.isNotEmptyString(strKafkaTopicName) && setPaTopic.contains(strKafkaTopicName)){
			return true;
		}

		return false;
	}

	protected JsonObject getJiguangMonitorJson(JsonObject kafkaJson){
		/**
		 *�˴�ͨ����kafka����
		 * �ɹ�֧���������(����)

		 ��������
		 (�ɹ�֧�����)ҵ��ϵͳ -> kafka -> ips-message -> ���� -> ��ý���ն�
		 ҵ��ϵͳ����kafka˵��
		 topic
		 ��Ϣ��ʽ
		 ���	�ֶ���������	��ʶ��	���ݸ�ʽ	˵��
		 1	�������Ͷ���	tfJgAudience	128	�������͵Ķ���(����⳵ҵ����Ϊ�ն˺ţ��˴�ͨ��ֵ����Ϊmid+tid)
		 2	����������Ϣ	tfJgMessage	256	��Ϣ��ʽΪ base64.encode(json�ִ�)
		 ������Ϣ-���ĸ�ʽ
		 json��ʽ��������˵������
		 ����
		 ���	�ֶ���	�ֶ�����	�ֶ�����	����	����	��ʽ˵��
		 1	tid	�ն˺�	String	8	M	�䳤
		 2	mid	�̻���	String	15	M	�䳤
		 3	paytype	֧����ʽ	String	8	M	�䳤��wechat/alipay/unionpay
		 4	reqssn	������ˮ	String	8	M	�䳤���ѻ�������ʱ��yyyymmddhhmmss
		 5	octopus_cardno	�˴�ͨ����	String	16	M	�䳤
		 6	octopus_balance	�˴�ͨ���	String	6	M	�䳤����Ϊ��λ�������1ǧԪ
		 7	mccode	ҵ�����	String	6	M	�䳤
		 8	hkd_amt	��ֵ���	String	12	M	�۱ң���Ϊ��λ
		 9	cny_amt	֧�����	String	12	M	����ң���Ϊ��λ
		 10	paytime	֧��ʱ��	String	14	M	�䳤��yyyymmddhhmmss
		 11	ref_no	ϵͳ�ο���	String	12	M	֧���ɹ���12λϵͳ�ο��ţ����ڷ����ֵ����ʱʹ��
		 12	transaction_id	֧��ƽ̨���׺�	String	32	M	�䳤
		 13	sign	ǩ��	String	32	M	MD5ǩ��
		 */

		/**
		 * ����ͨ����kafka����
		 * �ɹ�֧���������(����)

		 ��������
		 (�ɹ�֧�����)ҵ��ϵͳ -> kafka -> ips-message -> ���� -> ��ý���ն�
		 ҵ��ϵͳ����kafka˵��
		 topic
		 ��Ϣ��ʽ
		 ���	�ֶ���������	��ʶ��	���ݸ�ʽ	˵��
		 1	�������Ͷ���	tfJgAudience	128	�������͵Ķ���(����⳵ҵ����Ϊ�ն˺ţ�����ͨ��ֵ����Ϊmid+tid)
		 2	����������Ϣ	tfJgMessage	256	��Ϣ��ʽΪ base64.encode(json�ִ�)
		 ������Ϣ-���ĸ�ʽ
		 json��ʽ��������˵������
		 ����
		 ���	�ֶ���	�ֶ�����	�ֶ�����	����	����	��ʽ˵��
		 1	tid	�ն˺�	String	8	M	�䳤
		 2	mid	�̻���	String	15	M	�䳤
		 3	paytype	֧����ʽ	String	8	M	�䳤��wechat/alipay/unionpay
		 4	reqssn	������ˮ	String	8	M	�䳤���ѻ�������ʱ��yyyymmddhhmmss
		 5	szt_cardno	����ͨ����	String	16	M	�䳤
		 6	szt_balance	����ͨ���	String	6	M	�䳤����Ϊ��λ�������1ǧԪ
		 7	mccode	ҵ�����	String	6	M	�䳤
		 8	txamt	֧�����	String	12	M	�䳤����Ϊ��λ
		 9	paytime	֧��ʱ��	String	14	M	�䳤��yyyymmddhhmmss
		 10	ref_no	ϵͳ�ο���	String	12	M	֧���ɹ���12λϵͳ�ο��ţ����ڷ����ֵ����ʱʹ��
		 11	transaction_id	֧��ƽ̨���׺�	String	32	M	�䳤
		 12	sign	ǩ��	String	32	M	MD5ǩ��
		 */


		JsonObject joMonitorRequest = new JsonObject();
		joMonitorRequest.put("hwgChsDesc"    , "jiguang");

		try{
			String msgBase64     = Util.safeGetJsonString(kafkaJson, "tfJgMessage" , "");
			byte[] byDecoded     = Util.base64decode(msgBase64);
			String strDecoded    = new String(byDecoded);
			JsonObject joContent = Util.parseJsonString(strDecoded);

			String tid             = Util.safeGetJsonString(joContent,"tid", "");
			String mid             = Util.safeGetJsonString(joContent,"mid", "");
			String paytype         = Util.safeGetJsonString(joContent,"paytype", "");
			String reqssn          = Util.safeGetJsonString(joContent,"reqssn", "");
			String mccode          = Util.safeGetJsonString(joContent,"mccode", ""); //�ڲ��̻���
			String paytime         = Util.safeGetJsonString(joContent,"mccode", ""); //֧��ʱ��
			String ref_no          = Util.safeGetJsonString(joContent,"ref_no", ""); //֧���ɹ���12λϵͳ�ο��ţ����ڷ����ֵ����ʱʹ��
			String transaction_id  = Util.safeGetJsonString(joContent,"transaction_id", ""); //������

			String octopus_cardno  = Util.safeGetJsonString(joContent,"octopus_cardno", ""); //�˴�ͨ����
			String octopus_balance = Util.safeGetJsonString(joContent,"octopus_balance", ""); //�˴�ͨ���
			String szt_cardno      = Util.safeGetJsonString(joContent,"szt_cardno", ""); //����ͨ����
			String szt_balance     = Util.safeGetJsonString(joContent,"szt_balance", ""); //����ͨ���
			String tfcardno        = Util.getFirstNotEmpty(octopus_cardno, szt_cardno);

			String txamt           = Util.safeGetJsonString(joContent,"txamt", ""); //֧�����
			String cny_amt         = Util.safeGetJsonString(joContent,"cny_amt", ""); //֧�����
			String tftxmony        = Util.getFirstNotEmpty(txamt, cny_amt);

			joMonitorRequest.put("tftermid"         , tid);
			joMonitorRequest.put("tftxmony"         , tftxmony);
			joMonitorRequest.put("tfmccode"         , mccode);
			joMonitorRequest.put("tfcardno"         , tfcardno);
			joMonitorRequest.put("tftxcode"         , reqssn);
			joMonitorRequest.put("tfteacct"         , ref_no);
			joMonitorRequest.put("transaction_id"   , transaction_id);
		}catch (Exception e){
		}

		return joMonitorRequest;
	}

	protected boolean isSztJiguangTopic(JsonObject sysConf, String strKafkaTopicName){
		String confSztJiguangTopic = Util.safeGetJsonString(sysConf, ConstantSYS.CONF_sztJiguangTopic, "");
		Set<String> setTopic = getSepSets(confSztJiguangTopic);
		if(Util.isNotEmptyString(strKafkaTopicName) && setTopic.contains(strKafkaTopicName)){
			return true;
		}
		return false;
	}

	protected boolean isCommonTopic(JsonObject sysConf, String strKafkaTopicName){
		String confCommonTopic = Util.safeGetJsonString(sysConf, ConstantSYS.CONF_commonTopic, "");
		Set<String> setTopic = getSepSets(confCommonTopic);
		if(Util.isNotEmptyString(strKafkaTopicName) && setTopic.contains(strKafkaTopicName)){
			return true;
		}
		return false;
	}

	public boolean isZhongBaoXin(JsonObject sysConf, String strKafkaTopicName){
		String zhongBaoXingTopic = Util.safeGetJsonString(sysConf, ConstantSYS.CONF_zhongBaoXinTopic, "");
		Set<String> setTopic = getSepSets(zhongBaoXingTopic);
		if(Util.isNotEmptyString(strKafkaTopicName) && setTopic.contains(strKafkaTopicName)){
			return true;
		}

		return false;
	}

	public void addMoreInfo2KafkaJson(JsonObject kafkaJson){
        String paytypeString = Util.myGetPayTypeString(kafkaJson);

        //Ϊ������⳵��΢����׼��
        kafkaJson.put("tfcardtypdesc", paytypeString);
    }



    public void processNoFeelingWrapper(JsonObject kafkaJson, Vertx vertx, String strKafkaTopicName, IpsMessageHandler ipsMessageHandler){
        log.info(lF.format("���̻��������޸�֧���̻�") );

        processNoFeeling(kafkaJson, vertx, strKafkaTopicName, ar->{
            if(ar.failed()){
                String msgApple = ar.cause().getMessage();
                JsonObject jo = new JsonObject().put("retcode", "IM08").put("retmsg", msgApple);
                ipsMessageHandler.handle(kafkaJson, jo);
            }else{
                JsonObject jo = new JsonObject().put("retcode", "0000").put("retmsg", "�޸�֧�����ŷ��ͳɹ�");
                ipsMessageHandler.handle(kafkaJson, jo);
            }
        });

    }

    public void processNoFeeling(JsonObject kafkaJson, Vertx vertx, String strKafkaTopicName, Handler<AsyncResult<String>> resultHandler){
        Future<String> ft = Future.future();
        ft.setHandler(resultHandler);

        String tfdate = Util.safeGetJsonString(kafkaJson, "tfdate", "");
        Date dtnow    = Util.timeNow();
        boolean bOld  = isNServerMsgTooOld(dtnow, tfdate);
        if(bOld){
            String msgAlbert = "���ݷǽ���������,������";
            log.info(lF.format(msgAlbert));
            ft.fail(new Throwable(msgAlbert));
            return;
        }

        String noFeelingAllowedTopic = Util.safeGetJsonString(sysConf, "noFeelingAllowedTopic", "");
        if(! isTopicAllowedByNoFeeling(noFeelingAllowedTopic, strKafkaTopicName)){
            String smsg = String.format("�޸�֧��ֻ��������topic[%s]��ǰtopic[%s]", String.valueOf(noFeelingAllowedTopic), String.valueOf(strKafkaTopicName) );
            ft.fail(new Throwable(smsg));
        }else{
            noFeelingSmsLogic(kafkaJson, vertx, ar->{
                if(ar.failed()){
                    String msgApple = String.format("�޸�֧�����ŷ���ʧ��[%s]", ar.cause().getMessage() );
                    log.info(lF.format(msgApple));

                    ft.fail(new Throwable(msgApple));
                }else{
                    String msgApple = "�޸�֧�����ŷ��ͳɹ�";
                    log.info(lF.format(msgApple));
                    ft.complete(msgApple);
                }
            });
        }
    }

    public boolean isTopicAllowedByNoFeeling(String noFeelingAllowedTopic, String strKafkaTopicName){
        noFeelingAllowedTopic =  noFeelingAllowedTopic==null ? "" : noFeelingAllowedTopic;
        strKafkaTopicName     = strKafkaTopicName==null ? "" : strKafkaTopicName;

        Set<String> setAllowed= getSepSets(noFeelingAllowedTopic);
        if(setAllowed.contains(strKafkaTopicName)){
            return true;
        }
        return false;
    }

    public Set<String> getSepSets(String strWhole){
        strWhole = strWhole==null ? "" : strWhole;
        Set<String> myset = new HashSet<>();
        String[] arr = strWhole.split(",");
        for(String item : arr){
            if(Util.isNotEmptyString(item)){
                myset.add(item);
            }
        }

        return myset;
    }

	public void processOfficialAccountWrapper(JsonObject kafkaJson, Vertx vertx, String strKafkaTopicName, IpsMessageHandler ipsMessageHandler){
		processOfficialAccount(kafkaJson, vertx, strKafkaTopicName, ar->{
			if(ar.succeeded()){
				String smsg = String.format("���⳵��Ϣ�Ѿ��ɹ��ʹ�[%s]", ar.result() ) ;
				log.info(lF.format(smsg ) );
				JsonObject jo = new JsonObject().put("retcode", "0000").put("retmsg", smsg);
				ipsMessageHandler.handle(kafkaJson, jo);
			}else {
				String smsg = ar.cause().getMessage();
				JsonObject jo = new JsonObject().put("retcode", "IM08").put("retmsg", smsg);
				ipsMessageHandler.handle(kafkaJson, jo);
			}

			//�ǵ�jstt��mysql�ı�JSTT_NOTIFY_HISTORY
			JsttSmsMysqlService jsttSmsMysqlService = new JsttSmsMysqlService(sysConf, vertx, logId);
			jsttSmsMysqlService.insertJSTT_NOTIFY_HISTORY(kafkaJson, result -> {});
		});
	}

	public void processOfficialAccount(JsonObject kafkaJson, Vertx vertx, String strKafkaTopicName, Handler<AsyncResult<String>> resultHandler){
		Future<String> ft = Future.future();
		ft.setHandler(resultHandler);
		String smsg = "";

		if(!isKafkaMessageAllowedFuncTypeInTopic(sysConf, strKafkaTopicName, kafkaJson)){
			smsg = String.format("����kafka��Ϣ��������(�������Ͳ�����)");
			log.info(lF.format(smsg));
			ft.fail(new Throwable(smsg));
			return;
		}

		if(!isKafkaMessageAllowedMccodeInTopic(sysConf, strKafkaTopicName, kafkaJson)){
			smsg = String.format("����kafka��Ϣ��������(�ڲ��̻��Ų�����)");
			log.info(lF.format(smsg));
			ft.fail(new Throwable(smsg));
			return;
		}


		String tfdate = Util.safeGetJsonString(kafkaJson, "tfdate", "");
		Date dtnow    = Util.timeNow();
		boolean bOld  = isNServerMsgTooOld(dtnow, tfdate);
		if(bOld){
			String msgAlbert = "���ݷǽ���������,������";
			log.info(lF.format(msgAlbert));
			ft.fail(new Throwable(msgAlbert));
			return;
		}

		String strJieShuan = Util.safeGetJsonString(sysConf, "jieshuanType", "");

		//����kafka ֻ����shunt_flagΪK�����
		if(Util.isJieShuanTransType(strJieShuan, kafkaJson)){
			String shunt_flag = Util.safeGetJsonString(kafkaJson, "shunt_flag", "");
			if( !ConstantSYS.SHUNT_k.equals(shunt_flag)) {
				smsg = String.format("����kafka��Ϣ��������(�������ֻ����K����)");
				log.info(lF.format(smsg));
				ft.fail(new Throwable(smsg));
				return;
			}
		}else{
			//����kafka ����ֻ����0000�ɹ�����
			if( ! isSuccessKafkaData(kafkaJson)){
				smsg = String.format("����kafka��Ϣ��������(���ѽ���ֻ�����ɹ�����)");
				log.info(lF.format(smsg));
				ft.fail(new Throwable(smsg));
				return;
			}
		}

		processTaxiMessage(kafkaJson, vertx, ft);
	}

	private void mongoInsertRecord(JsonObject kafkaJson, Vertx vertx){
		TddlMongo tddlMongo = new TddlMongo(sysConf.getJsonObject("tddl"), logId);

//		String collection = TddlMongo.collection + Util.getTime("yyyyMMdd");
		String collection = TddlMongo.collection + Util.myGetMongoDate(kafkaJson);

		tddlMongo.insert(kafkaJson, collection, vertx, (joResp) -> {
			String retcode = Util.safeGetJsonString(joResp, "retcode", "");
			String smsg    = String.format("tddl mongo insert���[%s]", String.valueOf(retcode) );
			log.info(lF.format(smsg));
		});
	}

	public void taxiSmsLogic(JsonObject kafkaJson, Vertx vertx, Handler<AsyncResult<String>> resultHandler){
		Future<String> ft = Future.future();
		ft.setHandler(resultHandler);
		String smsg = "";

		if(!Util.isTaxiSmsAllowed(kafkaJson)){
			smsg = String.format("kafka sms_flag��־Ϊ�����Ͷ���");
			log.info(lF.format( smsg ));
			ft.fail(new Throwable(smsg));
		}else{

			String strUrlOfSms   = Util.safeGetJsonString(wxJsonConf, "ipsSMSsendURL", "");
			int timeout          = Util.safeGetJsonInt(wxJsonConf, "ipsTimout", 30);
			String mobilephone   = Util.safeGetJsonString(kafkaJson, "pyeemobno", "");
			String strJieShuan   = Util.safeGetJsonString(sysConf, "jieshuanType", "");
			String smsPromptUrl  = Util.safeGetJsonString(sysConf, "smsPromptUrl", "");

			String strSmsContent = new FancySms().myFormatSmsContent(strJieShuan, kafkaJson, smsPromptUrl);
			kafkaJson.put("sms_content", strSmsContent);
			kafkaJson.put("sms_fromuser", "ips_message_sms");

			new FancyService(vertx, logId).ipsSendSMS(strUrlOfSms, timeout, mobilephone, strSmsContent, ar->{
				if(ar.failed()){
					kafkaJson.put(ConstantSYS.JSONKEY_sendStatus, ConstantSYS.SNDSTATUS_FAIL);

					ft.fail(ar.cause());
				}else{
					kafkaJson.put(ConstantSYS.JSONKEY_sendStatus, ConstantSYS.SNDSTATUS_SUCCESS);

					String msgApple = String.format("���ŷ��ͳɹ�");
					ft.complete(msgApple);
				}
			});
		}
	}


	//�޸�֧�������߼�
	public void noFeelingSmsLogic(JsonObject kafkaJson, Vertx vertx, Handler<AsyncResult<String>> resultHandler){
		Future<String> ft = Future.future();
		ft.setHandler(resultHandler);
		String smsg = "";

		isMessageProcessedAlready(kafkaJson, vertx, ar -> {
			if(ar.succeeded() && ar.result() ){
				String msgSimon = "������¼�Ѿ�������";
				ft.fail(new Throwable(msgSimon));
			}else{
				noFeelingSmsLogicInternal(kafkaJson, vertx, ft);

				mongoInsertRecord(kafkaJson, vertx);
			}
		});
	}


	public void noFeelingSmsLogicInternal(JsonObject kafkaJson, Vertx vertx, Handler<AsyncResult<String>> resultHandler){
		Future<String> ft = Future.future();
		ft.setHandler(resultHandler);
		String smsg = "";

		if(!Util.isTaxiSmsAllowed(kafkaJson)){
			smsg = String.format("kafka�޸�֧�� sms_flag��־Ϊ�����Ͷ���");
			log.info(lF.format( smsg ));
			ft.fail(new Throwable(smsg));
		}else{

			String strUrlOfSms   = Util.safeGetJsonString(wxJsonConf, "ipsSMSsendURL", "");
			int timeout          = Util.safeGetJsonInt(wxJsonConf, "ipsTimout", 10);
			String mobilephone   = Util.safeGetJsonString(kafkaJson, "pyeemobno", "");
			String strSmsContent = new FancySms().formatNoFeelingSmsContent(kafkaJson);

			new FancyService(vertx, logId).ipsSendSMS(strUrlOfSms, timeout, mobilephone, strSmsContent, ar->{
				if(ar.failed()){
					ft.fail(ar.cause());
				}else{
					String msgApple = String.format("�޸�֧�����ŷ��ͳɹ�");
					ft.complete(msgApple);
				}
			});
		}
	}



	public void isMessageProcessedAlready(JsonObject kafkaJson, Vertx vertx, Handler<AsyncResult<Boolean>> resultHandler){
		Future<Boolean> ft = Future.future();
		ft.setHandler(resultHandler);

		try{
			String collectionName = TddlMongo.collection + Util.myGetMongoDate(kafkaJson);
			JsonObject tddlconf   = this.sysConf.getJsonObject("tddl");
			TddlMongo tddlMongo   = new TddlMongo(tddlconf, this.logId);

			String tftxcode       = Util.safeGetJsonString(kafkaJson, "tftxcode", ""); //������ˮ
			String tfmccode       = Util.safeGetJsonString(kafkaJson, "tfmccode", ""); //�ڲ��̻���
			JsonObject condition  = new JsonObject().put("tftxcode", tftxcode).put("tfmccode", tfmccode);
			tddlMongo.query(condition, collectionName, vertx, (jo) -> {
				String retcode = Util.safeGetJsonString(jo, "retcode", "");
				JsonArray rs   = jo.getJsonArray("rs");
				if(ConstantSYS.SUCCESS.equals(retcode) && null != rs){
					ft.complete(true);
				}else{
					ft.complete(false);
				}
			});

		}catch (Exception e){
			ft.complete(false);
		}

	}


	public void processTaxiMessageInternal(JsonObject kafkaJson, Vertx vertx, Handler<AsyncResult<String>> resultHandler){
		Future<String> ft = Future.future();
		ft.setHandler(resultHandler);
		String smsg = "";

		String openid = Util.safeGetJsonString(kafkaJson, "openid", "");
		if(Util.isEmptyString(openid)){
			log.info(lF.format("openidΪ�տ�ʼ���Ͷ���"));
			//openidΪ���򷢶���

			taxiSmsLogic(kafkaJson, vertx, ar->{
				if(ar.failed()){
					ft.fail(ar.cause());
				}else{
					ft.complete("openidΪ�տ�ʼ���Ͷ��ųɹ�");
				}
			});

		}else{
			log.info(lF.format("openid���ڿ�ʼ��������΢��"));
			pushOfficialAccountMessage(kafkaJson, vertx, ar -> {

				if(ar.succeeded()){
					String msgApple = "����΢�ųɹ�";
					log.info(lF.format(msgApple ));
					ft.complete(msgApple);
				}else{
					String msgApple = String.format("����΢��ʧ�ܳ��Է��Ͷ��ţ�΢��ʧ��ԭ��[%s]", ar.cause().getMessage());
					log.info(lF.format( msgApple ));

					taxiSmsLogic(kafkaJson, vertx, arSms->{
						if(arSms.failed()){
							ft.fail(arSms.cause());
						}else{
							ft.complete("����΢��ʧ�ܺ��Ͷ��ųɹ�");
						}
					});
				}

			});
		}

	}

	public void processTaxiMessage(JsonObject kafkaJson, Vertx vertx, Handler<AsyncResult<String>> resultHandler){
		Future<String> ft = Future.future();
		ft.setHandler(resultHandler);

		// �ж��Ƿ��Ѿ��д�����
		isMessageProcessedAlready(kafkaJson, vertx, ar -> {
			if(ar.succeeded() && ar.result() ){
				String msgSimon = "������¼�Ѿ�������";
				ft.fail(new Throwable(msgSimon));
			}else{
				processTaxiMessageInternal(kafkaJson, vertx, ft);


				String strJieShuan = Util.safeGetJsonString(sysConf, "jieshuanType", "");
				boolean bJieshuan  = Util.isJieShuanTransType(strJieShuan, kafkaJson);

				if ( !bJieshuan ){
					if (Util.safeGetJsonString(kafkaJson, "tfmccode", "").equals("010345")) {
						JiguangPushService jiguangService = new JiguangPushService(sysConf, vertx, logId);
						jiguangService.handle(kafkaJson, result -> {});

						xgPushService xgService = new xgPushService(sysConf, vertx, logId);
						xgService.handle(kafkaJson, result -> {});
					}
				}
				mongoInsertRecord(kafkaJson, vertx);
			}
		});
	}

	public String replacePatternWithDateValue(String strDate/*20180101102030*/, String fmtWhole/*YYYYMMDDhhmmss*/, String fmtToTake/*YYYY*/){
		String value = strDate;
		int findpos  = fmtWhole.indexOf(fmtToTake);
		int NOTFOUND = -1;
		if(NOTFOUND != findpos){
			value = Util.safeSubString(strDate, findpos, fmtToTake.length());
		}

		return value;
	}
	public String replaceDatePattern(String strWithPattern, JsonObject kafkaJson){
		String newString= strWithPattern;
		Pattern pattern = Pattern.compile("<<(.*?):(.*?):(.*?)>>");
		Matcher mt = pattern.matcher(strWithPattern);
		while (mt.find()){
			String strBraceWithKey = mt.group(0);
			String strOnlyKey      = mt.group(1);
			String strDateValue    = Util.safeGetJsonString(kafkaJson, strOnlyKey, "");
			String fmtWhole        = mt.group(2);
			String fmtToTake       = mt.group(3);
			String str2replace     = replacePatternWithDateValue(strDateValue, fmtWhole, fmtToTake);

			newString = newString.replaceAll(strBraceWithKey, str2replace);
		}

		return newString;
	}

	public String replaceNormalPattern(String strWithPattern, JsonObject kafkaJson){
		String newString= strWithPattern;
//		Pattern pattern = Pattern.compile("\\{(\\w+)\\}");
//		Pattern pattern = Pattern.compile("<(\\w+)>");
		Pattern pattern = Pattern.compile("<(.*?)>");
		Matcher mt = pattern.matcher(strWithPattern);
		while (mt.find()){
			String strBraceWithKey = mt.group(0);
			String strOnlyKey      = mt.group(1);
			String strValue        = Util.safeGetJsonString(kafkaJson, strOnlyKey, "");
			newString = newString.replaceAll(strBraceWithKey, strValue);
		}

		return newString;
	}

	public JsonObject getWxAppMsgJsonObject(JsonObject dbConfJson, JsonObject kafkaJson){
		//region �������΢������ע��
		// {
//			"touser": "OPENID",
//			"template_id": "TEMPLATE_ID",
//			"page": "index",
//			"form_id": "FORMID",
//			"data": {
//			"keyword1": {
//				"value": "339208499",
//						"color": "#173177"
//			},
//			"keyword2": {
//				"value": "2015��01��05�� 12:30",
//						"color": "#173177"
//			},
//			"keyword3": {
//				"value": "����ϲ���ǾƵ�",
//						"color": "#173177"
//			} ,
//			"keyword4": {
//				"value": "��������������·208��",
//						"color": "#173177"
//			}
//		},
//			"emphasis_keyword": "keyword1.DATA"
//		}
		//endregionע��


		JsonObject joWxSend = new JsonObject();
		try{
			String strTmplInDB = Util.safeGetJsonString(dbConfJson, "msg_template", "");
			String template_id = Util.safeGetJsonString(dbConfJson, "template_id", "");

			JsonObject joKafkaCopy = new JsonObject(kafkaJson.toString());
			joKafkaCopy.put("template_id", template_id);


			String strNewJson  = replaceDatePattern(strTmplInDB, joKafkaCopy);
			strNewJson         = replaceNormalPattern(strNewJson, joKafkaCopy);

			joWxSend           = new JsonObject(strNewJson);

		}catch (Exception ex){
			String fmtError = Util.getStacktrackInfo(ex);
			String msg = String.format("��΢�ŷ�����Ϣʱ����[%s]", fmtError);
			log.info(lF.format(msg) );
		}

		return joWxSend;
	}




//	����΢�Ź��ں���Ϣ
	public void pushOfficialAccountMessage(JsonObject kafkaJson, Vertx vertx, Handler<AsyncResult<Void>> resultHandler){
		Future<Void> ft = Future.future();
		ft.setHandler(resultHandler);

		String strUrlOfWxApp        = Util.safeGetJsonString(wxJsonConf, "officialAccountUrl", "");
		int timeoutWx               = Util.safeGetJsonInt(wxJsonConf, "timeout", 30);

		String mccode        = Util.safeGetJsonString(kafkaJson, "tfmccode", "");
		if(! Util.isSuccessKafkaData(kafkaJson)){
			mccode = Util.myHashMccode(mccode);
		}

		dbGetWxTemplate(kafkaJson, vertx, mccode, arDBConf -> {
			if(arDBConf.failed()){
				ft.fail(arDBConf.cause());
			}else{
				JsonObject joDBConf     = arDBConf.result();

				String strUrlOfIpsToken = Util.safeGetJsonString(wxJsonConf, "ipsTokenURL", "");
				int ipsTimout           = Util.safeGetJsonInt(wxJsonConf, "ipsTimout", 10);
				String appid            = Util.safeGetJsonString(joDBConf, "appid", "");
				Future<String> ftAccessToken = Future.future();
				new FancyService(vertx, logId).ipsGetAccessToken(strUrlOfIpsToken, ipsTimout, appid, ftAccessToken);

				ftAccessToken.compose(accessToken -> {
					JsonObject joWxSend   = getWxAppMsgJsonObject(joDBConf, kafkaJson);
					
					JsonObject jo = Util.safeGetJsonObject(Util.safeGetJsonObject(joWxSend,"data"), "first");
					kafkaJson.put("sms_content", Util.safeGetJsonString(jo, "value", ""));
					kafkaJson.put("sms_fromuser", "ips_message_wx");
					
					String strSendWx      = joWxSend.toString();
					new FancyService(vertx, logId).pushWxAppMessage(strUrlOfWxApp, timeoutWx, accessToken, strSendWx, kafkaJson, ft.completer());
				}, ft);
			}
		});
	}

	public void dbGetWxTemplate(JsonObject kafkaJson, Vertx vertx, String mccode, Handler<AsyncResult<JsonObject>> resultHandler){
		//String mccode        = kafkaJson.getString("tfmccode","");
		JsonObject joCache   = new JsonObject();
		String MYSQLCACHEKEY = ConstantMYSQL.MYSQLCACHEKEY;
		Future<JsonObject> ft = Future.future();
		ft.setHandler(resultHandler);
		try{
			joCache = SysCache.getCache(vertx, MYSQLCACHEKEY, mccode);
		}catch (Exception ex){ }

		if( ! Util.isEmptyJsonObject(joCache) ){
			ft.complete(joCache);
		}else{
			log.info(lF.format("��cacheû��ȡ��ֵ��ʼȥmysql tddlȡ����") );

			TddlService tddlService = new TddlService(tddlJsonConf, logId);
			JsonObject condition = new JsonObject().put("mccode", mccode);
			tddlService.process(condition, vertx, v -> {
				String retcode = Util.safeGetJsonString(v, "retcode", "");
				if(!ConstantSYS.SUCCESS.equals(retcode)){
					String msg = String.format("mysql tddl���ز��ǳɹ�,tddl retcode[%s]", String.valueOf(retcode));
					log.info(lF.format(msg) );
					ft.fail(new Throwable(msg));
				}else {
					JsonArray arrRes = Util.safeGetJsonArray(v, "res");
					if(arrRes.isEmpty()){
						String msg = "mysql tddl���ظ�ʽ����,��res����";
						log.info(lF.format(msg) );
						ft.fail(new Throwable(msg));
					}else {
						JsonObject joRes = arrRes.getJsonObject(0);
						String msg = String.format("��cache��û��ȡ�����ݣ���tddl mysql���ص�����ֵ�ǲ�����cache[%s]", String.valueOf(joRes) );
						log.info(lF.format( DeSensi.Aes( msg ) ) );

						SysCache.setCache(vertx, MYSQLCACHEKEY, mccode, joRes, ConstantMYSQL.MYSQLCACHEKEY_EXPIRETIME);
						ft.complete(joRes);
					}


				}
			});

		}
	}


	public boolean isNoFeeling(JsonObject sysConf, JsonObject kafkaJson){
		String mercno = Util.safeGetJsonString(kafkaJson, "tfmccode", "");
		Set<String> appMerchants = getNoFeelingMerchants(sysConf);

		if(!appMerchants.isEmpty() && appMerchants.contains(mercno)){
			return true;
		}

		return false;
	}

	public Set<String> getNoFeelingMerchants(JsonObject sysConf){
		String strMerc = Util.safeGetJsonString(sysConf, "smallAppMerc", "");

		Set<String> appMerchants = getSepSets(strMerc);

		return appMerchants;
	}

    public boolean isKafkaMessageAllowedFuncTypeInTopic(JsonObject sysConf, String strKafkaTopicName, JsonObject kafkaJson){
        //1.1 topic = ksett_clear
        //1.2 kafka.tfmccode in ('000484','000485','010345')
        //1.3 kafka.tfbackno == "0000"
        //1.5 �����ף���kafka.tftranstype in ('120', '175', '330', '127')��

        JsonObject jsonChildAllowed = sysConf.getJsonObject("funcTypeAllowed", new JsonObject());
        if(jsonChildAllowed.isEmpty()){
            return true;
        }
        Set<String> allowedTopicNames = jsonChildAllowed.fieldNames();
        if( !allowedTopicNames.contains(strKafkaTopicName) ){
            return false;
        }

        String strDataFuncType = kafkaJson.getString("tftranstype");
        for( String strTopicName : allowedTopicNames ){
            String strAllowedFuncTypeUnderTopic = jsonChildAllowed.getString(strTopicName);

            String[] arrFuncTypes = strAllowedFuncTypeUnderTopic.split(",");
            List<String> lstFuncTypes = Arrays.asList(arrFuncTypes);
            if(lstFuncTypes.contains(strDataFuncType)){
                return true;
            }
        }

        return false;
    }

    public boolean isKafkaMessageAllowedMccodeInTopic(JsonObject sysConf, String strKafkaTopicName, JsonObject kafkaJson){
        JsonObject jsonChildAllowed = sysConf.getJsonObject("mccodeAllowed", new JsonObject());
        if(jsonChildAllowed.isEmpty()){
            return true;
        }
        Set<String> allowedTopicNames = jsonChildAllowed.fieldNames();
        if( !allowedTopicNames.contains(strKafkaTopicName) ){
            return false;
        }

        String strDataMccode = kafkaJson.getString("tfmccode");
        for( String strTopicName : allowedTopicNames ){
            String strAllowedMccode = jsonChildAllowed.getString(strTopicName);

            String[] arrMccode = strAllowedMccode.split(",");
            List<String> lstMccode = Arrays.asList(arrMccode);
            if(lstMccode.contains(strDataMccode)){
                return true;
            }
        }


        return false;
    }

    public boolean isSuccessKafkaData(JsonObject kafkaJson){
        String errorcode = kafkaJson.getString("tfbackno");
        if ("0000".equals(errorcode)){
            return true;
        }
        return false;
    }




	
	/**
	 * ��ӡkafka ����
	 * @param msg
	 */
	private void logKafkaData(ConsumerRecord<String, String> msg){
		try {
			log.info(lF.format("topic "     +  msg.topic()));
			log.info(lF.format("partition " +  msg.partition()));
			log.info(lF.format("offset "    +  msg.offset()));
			log.info(lF.format("key "       +  msg.key()));
			log.info(lF.format("value "     +  DeSensi.Aes(msg.value())));
			String sDateTime = Util.getTime(msg.timestamp(), "yyyy-MM-dd HH:mm:ss.SSS");
			log.info(lF.format("time "      +  sDateTime));
		} catch (Exception e) {
			String smsg = String.format("logKafkaData�쳣�����˳�[%s]", Util.getStacktrackInfo(e) );
			log.info(smsg);
		}
	}
	
}
