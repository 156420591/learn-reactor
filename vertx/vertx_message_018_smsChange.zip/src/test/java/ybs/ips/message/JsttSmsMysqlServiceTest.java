package ybs.ips.message;

import io.vertx.core.Future;
import io.vertx.core.Vertx;
import io.vertx.core.json.JsonObject;
import io.vertx.ext.asyncsql.MySQLClient;
import io.vertx.ext.sql.SQLClient;
import junit.framework.TestCase;
import ybs.ips.message.service.JsttSmsMysqlService;
import ybs.ips.message.util.Util;
import ybs.ips.message.util.log.MonitorJson;

public class JsttSmsMysqlServiceTest extends TestCase {

	public void testInsert() {
		JsonObject sysConf = new JsonObject();
		sysConf.put("mysql_jstt", new JsonObject()
				.put("host", "175.10.100.14")
				.put("port", 3306)
				.put("maxPoolSize", 10)
				.put("username", "jstt")
				.put("password", "123456")
				.put("database", "jstt")
				.put("queryTimeout", 1000));
		sysConf.put("jieshuanType", "122");
		
		Vertx vertx = Vertx.vertx();
		
		JsonObject kafkaJson = new JsonObject("{\"resfdacctissrid\":\"8610000000000000180\",\"shunt_flag\":\"K\",\"tfbackno\":\"0000\",\"tftxcount\":\"4\",\"idtp\":\"01\",\"tffwdinsid\":\"0880158489\",\"tfbncode\":\"627706\",\"pyeeacctid\":\"6212264000023662394\",\"tfbankrefno\":\"\",\"tfintype\":\"02\",\"instgacctnm\":\"�������װ��³��⳵ҵ�񱸸���\",\"tfbnussn\":\"009240\",\"pyeenm\":\"����\",\"uuid\":\"c06d7a98-8ca3-4b76-abff-70e5e112a82f\",\"tfteacct\":\"0000000000000234567\",\"tfdistcode\":\"\",\"pyeemobno\":\"13026620212\",\"tftermno\":\"60023403\",\"pyeemarkid\":\"0000000000000234567\",\"tftermid\":\"60023403|\",\"idno\":\"440582199401167026\",\"tftxdeta\":\"\",\"pyeraccttp\":\"0\",\"batch_startdate\":\"20180801\",\"taskid\":\"2c501f88ef7c4276ab8f05c0e9755165\",\"tftxfee\":\"0.00\",\"tftxcode\":\"0802TX1740009240\",\"tftxbatch\":\"000231\",\"tftranstype\":\"122\",\"tfcardtype\":\"DE\",\"old_uuid\":\"\",\"pyernm\":\"����\",\"pyeeacctissrid\":\"0800965840\",\"tftmccode\":\"000210440360519112\",\"tfcharge\":\"0.04\",\"tftxmony\":\"0.10\",\"datafrom\":\"jstt_taxi\",\"batchSettDate\":\"20180802\",\"tfacmony\":\"0.10\",\"mersettcode\":\"\",\"pyeracctid\":\"8610000033900441154\",\"tfmccode\":\"000339\",\"openid\":\"oTyEL1tHo89JQDiZfAKH2dLbiFc8\",\"logid\":\"e7eb0e19\",\"tfacctdt\":\"20180802\",\"tfperdata\":\"\",\"tfmemo_2bank\":\"\",\"sms_flag\":\"1\",\"mobno\":\"13026620212\",\"tfrcvinsid\":\"0800965840\",\"discount_amt\":\"0.00\",\"pyeeidno\":\"440582199401167026\",\"tfacqinsid\":\"0800965840\",\"bizstsdesc\":\"00:�ɹ�\",\"tfdate\":\"20180806172945\",\"instgacctid\":\"8610000000000000180\",\"pyeeidtp\":\"01\",\"sms_content\":\"˾������20180803����100.00Ԫ\",\"sms_flag\":\"1\",\"sms_fromuser\":\"ips_message_sms\"}");
		
		Future<String> ft = Future.future();
		ft.setHandler(result -> {
			System.out.println("result:"+result.result());
			assertEquals("���ż�¼��JSTT_NOTIFY_HISTORY�ɹ�", result.result());
		});
		
		JsttSmsMysqlService jsttSmsMysqlService = new JsttSmsMysqlService(sysConf, vertx, "");
		jsttSmsMysqlService.insertJSTT_NOTIFY_HISTORY(kafkaJson, ft);

/*		while(true) {
			if(ft.isComplete()) break;
		}*/
		
	}
}
