package ybs.ips.message;

import io.vertx.core.Future;
import io.vertx.core.Vertx;
import io.vertx.core.json.JsonObject;
import junit.framework.TestCase;
import ybs.ips.message.service.JiguangPushService;

public class JiguangPushServiceTest extends TestCase {

	public void testInsert() {
		JsonObject sysConf = new JsonObject();


		sysConf.put("jiguang", new JsonObject()
				.put("scheme", "https")
				.put("host", "bjapi.push.jiguang.cn")
				.put("port", 443)
				.put("uri", "/v3/push")
				.put("timeout", 60)
				.put("username", "41b7bcc8bd078992a09b970f")
				.put("password", "0e56e53df4414649cb850f10")
		);

		Vertx vertx = Vertx.vertx();
		
		JsonObject kafkaJson = new JsonObject("{\"tfacmony\":\"0.00\",\"tftermssn\":\"000002\",\"pyeesettacctid\":\"6212264000023662394\",\"pyeenm\":\"����\",\"tfbankstu\":\"\",\"instgacctnm\":\"�������װ��³��⳵ҵ�񱸸���\",\"tfrlmony\":\"10.01\",\"tfbalance\":\"\",\"pyeemobno\":\"13026620212\",\"tftermid\":\"294004050|0000000497\",\"tftxdeta\":\"10.01|0.0|0.00|0|\",\"tftxbatch\":\"000223\",\"tfchannel\":\"szt\",\"bankid\":\"\",\"tfreqtno\":\"861\",\"pyernm\":\"�������װ��³��⳵ҵ�񱸸���\",\"tfsamsq\":\"141\",\"tfcharge\":\"0.00\",\"tftxmony\":\"10.01\",\"tfpaytype\":\"shenzhentong\",\"pyeeidno\":\"440582199401167026\",\"tftmccode\":\"999999999999000485\",\"instgacctid\":\"8610000000000000180\",\"tfbizinfo\":\"35\",\"resfdacctissrid\":\"8610000000000000180\",\"tfmemo\":\"294004050-20180713203745.212\",\"tftxfnc\":\"3001\",\"tfbackno\":\"0000\",\"tfmerstu\":\"2\",\"bankauthcode\":\"\",\"tfappendmony\":\"0.00\",\"pyeeacctid\":\"8610000033900441154\",\"tfrealforinst\":\"0899999955\",\"tfcustno\":\"0|000223|\",\"banktradedate\":\"\",\"bankterminalttc\":\"\",\"tftrk2\":\"\",\"discount_amt\":\"0\",\"tfcardsq\":\"1084\",\"pyeemarkid\":\"0000000000000234567\",\"tfonlinesq\":\"\",\"tfafmony\":\"94.53\",\"tftrk3\":\"\",\"pyeraccttp\":\"0\",\"pyeeidtp\":\"01\",\"tftranstype\":\"120\",\"tfkeyver\":\"\",\"openid\":\"oTyEL1tHo89JQDiZfAKH2dLbiFc8\",\"tfsamid\":\"60016921\",\"bankterminalid\":\"\",\"tfcardtype\":\"ST\",\"pyeeacctissrid\":\"0800965840\",\"tficc\":\"\",\"installment\":\"0\",\"fee_mccode\":\"000485\",\"tfmccode\":\"000485\",\"datafrom\":\"icsas\",\"tfcardno\":\"685032169\",\"tfic_info\":\"303238373339393345394332443432383233453530313030303035323235383631313030303030314436343545313439303230303030303030313030303030303031303030303030454432343030303033433034303030303030303036434133384530463136463439394530343931443031303030303030303030303030303030303030303034323030303030303030303030303030384430303030303030303630303136393231353138303030303045394332443432383434464439414531\",\"tfmertcc\":\"\",\"tfdate\":\"20180716202332\",\"pyeracctid\":\"8610000000000000180\",\"tfteacct\":\"0000000000000234567\",\"tftermttc\":\"000002\",\"bankcardno\":\"\",\"tfacctdt\":\"20180716\",\"tftermno\":\"98271720412442\",\"tflocstu\":\"2\",\"sms_flag\":\"1\",\"tftxcode\":\"2018071640000350\",\"bankrefttc\":\"\",\"tfic_tc\":\"\",\"tfofflinesq\":\"\",\"tfalgver\":\"\",\"tfmemo1\":\"0000000000000234567\",\"tfsouthcard\":\"0\",\"tfmerdate\":\"20180716202322\",\"sett_mccode\":\"000485\"}");
		
		Future<String> ft = Future.future();
		ft.setHandler(result -> {
			System.out.println("result:"+result.result());
			assertEquals("���ż�¼��JSTT_NOTIFY_HISTORY�ɹ�", result.result());
		});

		JiguangPushService jsttSmsMysqlService = new JiguangPushService(sysConf, vertx, "");
		jsttSmsMysqlService.handle(kafkaJson, ft);

/*		while(true) {
			if(ft.isComplete()) break;
		}*/

	}
}
