package ybs.ips.message.service;

import io.vertx.core.Vertx;
import io.vertx.core.http.HttpServer;
import io.vertx.core.json.JsonObject;
import io.vertx.ext.unit.Async;
import io.vertx.ext.unit.TestContext;
import io.vertx.ext.unit.junit.VertxUnitRunner;
import io.vertx.ext.web.Router;
import io.vertx.ext.web.RoutingContext;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.runners.Enclosed;
import org.junit.runner.RunWith;

import java.net.ServerSocket;

import static org.junit.Assert.*;

/**
 * �����[  �����[�����[    �����[ �������������[
 * �����U  �����U�����U    �����U�����X�T�T�T�T�a
 * ���������������U�����U ���[ �����U�����U  �������[
 * �����X�T�T�����U�����U�������[�����U�����U   �����U
 * �����U  �����U�^�������X�������X�a�^�������������X�a
 * �^�T�a  �^�T�a �^�T�T�a�^�T�T�a  �^�T�T�T�T�T�a
 * Created by huwenguang on 2018/11/26.
 */

@RunWith(Enclosed.class)
public class FancyZhongBaoXinTest {

    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }

    public static class isThisRetcodeAsSuccess{
        @Test
        public void test000() throws Exception{
            JsonObject sysConf = new JsonObject();
            FancyZhongBaoXin sut = new FancyZhongBaoXin(Vertx.vertx(), "logid", sysConf);
            boolean bResult = sut.isThisRetcodeAsSuccess("0000");
            assertTrue(bResult);

            bResult = sut.isThisRetcodeAsSuccess("");
            assertFalse(bResult);
        }
    }

    public static class testJsonObjectTostring{
        @Test
        public void testToString() throws Exception{
            JsonObject jo = new JsonObject().put("retcode", "").put("retmsg", "test");
            System.out.println(jo.toString());
        }
    }

    public static class getZbxPMString{
        @Test
        public void testNormal() throws Exception{
            FancyZhongBaoXin sut;
            Vertx vertx = Vertx.vertx();
            JsonObject sysConf = new JsonObject();
            sysConf.put("zhongBaoXinMccode", "000001");

            sut = new FancyZhongBaoXin(vertx, "logid", sysConf);

            JsonObject kafkaJson = new JsonObject();
            kafkaJson.put("func", "002")
                    .put("mcssn", "2019010409174949")
                    .put("mccode", "888333")
                    .put("tranamt", "921684")
                    .put("billid", "622908333028851268-0006")
                    .put("payno", "payno")
                    .put("termid", "10550067")
                    .put("intype", "02")
                    .put("settdate", "20190104091749")
                    .put("cardno", "6217007200041023923")
                    .put("bankno", "656703")
                    ;
            String strSend = sut.getZbxPMString(kafkaJson);
            System.out.println(strSend);

        }
    }

    @RunWith(VertxUnitRunner.class)
    public static class payBillNumberNcaspQuery{
        Vertx vertx;
        HttpServer myserver;
        int port;
        FancyZhongBaoXin sut;


        public void handlerWxNormal(RoutingContext routingContext){
            JsonObject jo = new JsonObject().put("retcode", "0000").put("retmsg", "ok");
            routingContext.response().end(jo.toString());
        }

        public void handlerWxFail(RoutingContext routingContext){
            JsonObject jo = new JsonObject().put("retcode", "0001").put("retmsg", "ok");
            routingContext.response().end(jo.toString());
        }

        public void handlerWxTimeout(RoutingContext routingContext){
            vertx.setTimer(5000, ar -> {
                JsonObject jo = new JsonObject().put("retcode", "0000").put("retmsg", "ok");
                routingContext.response().end(jo.toString());

            });
        }

        public void handlerWxServerError(RoutingContext routingContext){
            JsonObject jo = new JsonObject().put("retcode", "0000").put("retmsg", "ok");
            routingContext.response().setStatusCode(500).end("<html>Server internal error</html>");
        }

        @Before
        public void setUp(TestContext context) throws Exception{
            ServerSocket socket = new ServerSocket(0);
            port = socket.getLocalPort();
            socket.close();

            vertx = Vertx.vertx();
            Router myrouter = Router.router(vertx);

            myrouter.route("/test/ncasp/normal").handler(this::handlerWxNormal);
            myrouter.route("/test/ncasp/fail").handler(this::handlerWxFail);
            myrouter.route("/test/ncasp/error").handler(this::handlerWxServerError);
            myrouter.route("/test/ncasp/timeout").handler(this::handlerWxTimeout);

            myserver = vertx.createHttpServer()
                    .requestHandler(myrouter::accept)
                    .listen(port, context.asyncAssertSuccess());
            JsonObject sysConf = new JsonObject();
            sut = new FancyZhongBaoXin(vertx, "logid", sysConf);
        }
        @After
        public void tearDown(TestContext context) throws Exception{
            vertx.close(context.asyncAssertSuccess());
        }


        @Test
        public void urlError(TestContext context) throws Exception{
            Async async = context.async();
            String url = String.format("http://localhost:%s/test/ncasp/normal", port+1);
            JsonObject kafkaJson = new JsonObject();
            sut.payBillNumberNcaspQuery("billnumber", url, 4, kafkaJson, ar->{
                context.assertTrue(ar.failed());
                async.complete();
            });

        }

        @Test
        public void timeout(TestContext context) throws Exception{

            Async async = context.async();
            String url = String.format("http://localhost:%s/test/ncasp/timeout", port);
            JsonObject kafkaJson = new JsonObject();
            sut.payBillNumberNcaspQuery("billnumber", url, 1, kafkaJson, ar->{
                context.assertTrue(ar.failed());
                async.complete();
            });
        }

        @Test
        public void serverError(TestContext context) throws Exception{

            Async async = context.async();
            String url = String.format("http://localhost:%s/test/ncasp/error", port);
            JsonObject kafkaJson = new JsonObject();
            sut.payBillNumberNcaspQuery("billnumber", url, 10, kafkaJson, ar->{
                context.assertTrue(ar.failed());
                async.complete();
            });
        }

        @Test
        public void test0000Success(TestContext context) throws Exception{
            Async async = context.async();
            String url = String.format("http://localhost:%s/test/ncasp/normal", port);
            JsonObject kafkaJson = new JsonObject();
            sut.payBillNumberNcaspQuery("billnumber", url, 1, kafkaJson, ar->{
                context.assertTrue(ar.succeeded());
                boolean bResult = ar.result();
                context.assertTrue(bResult);
                async.complete();
            });

        }

        @Test
        public void failRetcode(TestContext context) throws Exception{

            Async async = context.async();
            String url = String.format("http://localhost:%s/test/ncasp/fail", port);
            JsonObject kafkaJson = new JsonObject();
            sut.payBillNumberNcaspQuery("billnumber", url, 1, kafkaJson, ar->{
                context.assertTrue(ar.succeeded());
                boolean bResult = ar.result();
                context.assertFalse(bResult);
                async.complete();
            });
        }

    }

    @RunWith(VertxUnitRunner.class)
    public static class sendMsg2PM{

        Vertx vertx;
        HttpServer myserver;
        int port;
        FancyZhongBaoXin sut;


        public void handlerWxNormal(RoutingContext routingContext){
            JsonObject jo = new JsonObject().put("retcode", "0000").put("retmsg", "ok");
            routingContext.response().end(jo.toString());
        }

        public void handlerWxFail(RoutingContext routingContext){
            JsonObject jo = new JsonObject().put("retcode", "0001").put("retmsg", "ok");
            routingContext.response().end(jo.toString());
        }

        public void handlerWxTimeout(RoutingContext routingContext){
            vertx.setTimer(5000, ar -> {
                JsonObject jo = new JsonObject().put("retcode", "0000").put("retmsg", "ok");
                routingContext.response().end(jo.toString());

            });
        }

        public void handlerWxServerError(RoutingContext routingContext){
            JsonObject jo = new JsonObject().put("retcode", "0000").put("retmsg", "ok");
            routingContext.response().setStatusCode(500).end("<html>Server internal error</html>");
        }

        @Before
        public void setUp(TestContext context) throws Exception{
            ServerSocket socket = new ServerSocket(0);
            port = socket.getLocalPort();
            socket.close();

            vertx = Vertx.vertx();
            Router myrouter = Router.router(vertx);

            myrouter.route("/test/ncasp/normal").handler(this::handlerWxNormal);
            myrouter.route("/test/ncasp/fail").handler(this::handlerWxFail);
            myrouter.route("/test/ncasp/error").handler(this::handlerWxServerError);
            myrouter.route("/test/ncasp/timeout").handler(this::handlerWxTimeout);

            myserver = vertx.createHttpServer()
                    .requestHandler(myrouter::accept)
                    .listen(port, context.asyncAssertSuccess());
            JsonObject sysConf = new JsonObject();
            sut = new FancyZhongBaoXin(vertx, "logid", sysConf);
        }
        @After
        public void tearDown(TestContext context) throws Exception{
            vertx.close(context.asyncAssertSuccess());
        }


        @Test
        public void serverError(TestContext context) throws Exception{

            Async async = context.async();
            String url = String.format("http://localhost:%s/test/ncasp/error", port);
            JsonObject kafkaJson = new JsonObject();
            sut.sendMsg2PM(url, 5, kafkaJson, ar->{
                context.assertTrue(ar.failed());
                async.complete();

            });
        }

        @Test
        public void test0000Success(TestContext context) throws Exception{
            Async async = context.async();
            String url = String.format("http://localhost:%s/test/ncasp/normal", port);
            JsonObject kafkaJson = new JsonObject();
            sut.sendMsg2PM(url, 5, kafkaJson, ar->{
                context.assertTrue(ar.succeeded());
                async.complete();
            });

        }

        @Test
        public void failRetcode(TestContext context) throws Exception{

            Async async = context.async();
            String url = String.format("http://localhost:%s/test/ncasp/fail", port);
            JsonObject kafkaJson = new JsonObject();
            sut.sendMsg2PM(url, 5, kafkaJson, ar->{
                context.assertTrue(ar.failed());
                async.complete();
            });
        }
    }
}