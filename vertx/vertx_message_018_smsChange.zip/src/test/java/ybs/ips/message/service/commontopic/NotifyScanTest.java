package ybs.ips.message.service.commontopic;

import io.vertx.core.Vertx;
import io.vertx.core.http.HttpServer;
import io.vertx.core.json.JsonObject;
import io.vertx.ext.unit.Async;
import io.vertx.ext.unit.TestContext;
import io.vertx.ext.unit.junit.VertxUnitRunner;
import io.vertx.ext.web.Router;
import io.vertx.ext.web.RoutingContext;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.runners.Enclosed;
import org.junit.runner.RunWith;
import ybs.ips.message.constant.ConstantSYS;
import ybs.ips.message.util.Util;

import java.net.ServerSocket;
import java.util.*;

import static org.junit.Assert.*;

/**
 * �����[  �����[�����[    �����[ �������������[
 * �����U  �����U�����U    �����U�����X�T�T�T�T�a
 * ���������������U�����U ���[ �����U�����U  �������[
 * �����X�T�T�����U�����U�������[�����U�����U   �����U
 * �����U  �����U�^�������X�������X�a�^�������������X�a
 * �^�T�a  �^�T�a �^�T�T�a�^�T�T�a  �^�T�T�T�T�T�a
 * Created by huwenguang on 2019/5/21.
 */
@RunWith(Enclosed.class)
public class NotifyScanTest {

    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void test() throws Exception {
    }

    public static class java8OptionalUsage{
        protected Optional<String> getAppleColor(String name){
            if("hongfushi".equalsIgnoreCase(name)){
                return Optional.of("red");
            }
            return Optional.empty();
        }

        @Test
        public void test() throws Exception {
            Optional<String> color = getAppleColor("yuanshuai");
            assertEquals("green", color.orElse("green"));

            color = getAppleColor("hongfushi");
            assertEquals("red", color.orElse("green"));
        }
    }

    public static class getRemoteSendMsg{
        @Test
        public void testNormal() throws Exception {
            byte[] bytes = "Hello".getBytes();
            String encoded = Base64.getEncoder().encodeToString(bytes);
            JsonObject kafkaJson = new JsonObject().put("notify_buff", encoded);

            NotifyScan sut = new NotifyScan("logid", new JsonObject(), Vertx.vertx());
            String strSend = sut.getRemoteSendMsg(kafkaJson);
            assertEquals("Hello", strSend);
        }
    }


    @RunWith(VertxUnitRunner.class)
    public static class process{
        Vertx vertx;
        HttpServer myserver;
        int port;
        NotifyScan sut;

        public void handlerWxServerError(RoutingContext routingContext){
            JsonObject jo = new JsonObject().put("retcode", "0000").put("retmsg", "ok");
            routingContext.response().setStatusCode(500).end("<html>Server internal error</html>");
        }
        public void handlerWxServerSuccess(RoutingContext routingContext){
            JsonObject jo = new JsonObject().put("retcode", "0000").put("retmsg", "ok");
            routingContext.response().setStatusCode(200).end("SUCCESS");
        }

        public void handlerWxTimeout(RoutingContext routingContext){
            vertx.setTimer(5000, ar -> {
                JsonObject jo = new JsonObject().put("retcode", "0000").put("retmsg", "ok");
                routingContext.response().end(jo.toString());

            });
        }

        @Before
        public void setUp(TestContext context) throws Exception{
            ServerSocket socket = new ServerSocket(0);
            port = socket.getLocalPort();
            socket.close();

            vertx = Vertx.vertx();
            Router myrouter = Router.router(vertx);

            myrouter.route("/test/error").handler(this::handlerWxServerError);
            myrouter.route("/test/success").handler(this::handlerWxServerSuccess);
            myrouter.route("/test/timeout").handler(this::handlerWxTimeout);

            myserver = vertx.createHttpServer()
                    .requestHandler(myrouter::accept)
                    .listen(port, context.asyncAssertSuccess());
            JsonObject sysConf = new JsonObject();
            sut = new NotifyScan("logid", sysConf, vertx);
        }
        @After
        public void tearDown(TestContext context) throws Exception{
            vertx.close(context.asyncAssertSuccess());
        }

        @Test
        public void testTimeout(TestContext context) throws Exception {
            JsonObject kafkaJson = new JsonObject();
            String url = String.format("http://localhost:%s/test/timeout", String.valueOf(port) );
            kafkaJson.put("notify_url"         , url);
            kafkaJson.put("notify_buff"        , "sendbuffer");
            kafkaJson.put("sentTimes"          , "1");
            kafkaJson.put("notify_timeout"     , "2");

            JsonObject joMonitor = sut.getMonitorRequestJson(kafkaJson);

            Async async = context.async();
            sut.process(kafkaJson, (joAlbert, joResult) -> {
                String retcode = joResult.getString("retcode");
                String retmsg  = joResult.getString("retmsg");

                String expected_retmsg = "�Է���Ӧʧ�ܻز�";

                context.assertEquals("IM08", retcode);
                context.assertEquals(expected_retmsg, retmsg);

                context.assertEquals(joMonitor, joAlbert);
                async.complete();
            });
        }

        @Test
        public void testExceedMaxTimes(TestContext context) throws Exception {
            JsonObject kafkaJson = new JsonObject();
            String url = String.format("http://localhost:%s/test/success", String.valueOf(port) );
            kafkaJson.put("notify_url"    , url);
            kafkaJson.put("notify_buff"   , "sendbuffer");
            kafkaJson.put("sentTimes"     , "10");

            JsonObject joMonitor = sut.getMonitorRequestJson(kafkaJson);

            Async async = context.async();
            sut.process(kafkaJson, (joAlbert, joResult) -> {
                String retcode = joResult.getString("retcode");
                String retmsg  = joResult.getString("retmsg");

                String expected_retmsg = "��ǰ����[10]>����ʹ���[5],������";

                context.assertEquals("IM08", retcode);
                context.assertEquals(expected_retmsg, retmsg);

                context.assertEquals(joMonitor, joAlbert);
                async.complete();
            });
        }

        @Test
        public void testSuccess(TestContext context) throws Exception {
            JsonObject kafkaJson = new JsonObject();
            String url = String.format("http://localhost:%s/test/success", String.valueOf(port) );
            kafkaJson.put("notify_url"    , url);
            kafkaJson.put("notify_buff"   , "sendbuffer");
            kafkaJson.put("sentTimes"     , "1");

            JsonObject joMonitor = sut.getMonitorRequestJson(kafkaJson);

            Async async = context.async();
            sut.process(kafkaJson, (joAlbert, joResult) -> {
                String retcode = joResult.getString("retcode");
                String retmsg  = joResult.getString("retmsg");

                String expected_retmsg = "�Է���Ӧ�ɹ�";

                context.assertEquals("0000", retcode);
                context.assertEquals(expected_retmsg, retmsg);

                int nowTimes = Util.safeGetJsonInt(kafkaJson, "sentTimes", 0);
                context.assertEquals(2, nowTimes);

                context.assertEquals(joMonitor, joAlbert);
                async.complete();
            });
        }

        @Test
        public void testFail(TestContext context) throws Exception {
        }
    }

    public static class getPostCharset{
        @Test
        public void test() throws Exception {
            NotifyScan sut = new NotifyScan("logid", new JsonObject(), Vertx.vertx());
            assertEquals(ConstantSYS.GBK, sut.getPostCharset());
        }
    }
    public static class isReplySuccessful{
        @Test
        public void testIsSuccessful() throws Exception {
            NotifyScan sut = new NotifyScan("logid", new JsonObject(), Vertx.vertx());
            boolean bResult = sut.isReplySuccessful("SUCCESS");
            assertTrue(bResult);
        }
        @Test
        public void testIsFailure() throws Exception {
            NotifyScan sut = new NotifyScan("logid", new JsonObject(), Vertx.vertx());
            boolean bResult = sut.isReplySuccessful("OK");
            assertFalse(bResult);
        }
    }


    public static class JsonTest{
        @Test
        public void testReference1() throws Exception {
            JsonObject joApple = new JsonObject().put("name", "apple");

            JsonObject joAlias = joApple;
            assertEquals("apple", joAlias.getString("name"));

            joApple.put("name", "pear");
            assertEquals("pear", joAlias.getString("name"));
        }

        @Test
        public void testReference2() throws Exception {
            JsonObject joApple = new JsonObject().put("name", "apple");

            JsonObject joAlias = joApple;
            assertEquals("apple", joAlias.getString("name"));

            joAlias.put("name", "pear");
            assertEquals("pear", joApple.getString("name"));
        }

        @Test
        public void testCopy() throws Exception {
            JsonObject joApple = new JsonObject().put("name", "apple");

            JsonObject joAlias = joApple.copy();
            assertEquals("apple", joAlias.getString("name"));

            joAlias.put("name", "pear");
            assertEquals("pear", joAlias.getString("name"));
            assertEquals("apple", joApple.getString("name"));
        }
    }
}