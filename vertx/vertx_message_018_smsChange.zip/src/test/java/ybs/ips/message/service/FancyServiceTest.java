package ybs.ips.message.service;

import io.vertx.core.Vertx;
import io.vertx.core.http.HttpServer;
import io.vertx.core.json.JsonObject;
import io.vertx.ext.unit.Async;
import io.vertx.ext.unit.TestContext;
import io.vertx.ext.unit.junit.VertxUnitRunner;
import io.vertx.ext.web.Router;
import io.vertx.ext.web.RoutingContext;
import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.experimental.runners.Enclosed;
import org.junit.runner.RunWith;

import java.net.ServerSocket;

import static org.junit.Assert.*;

/**
 * �����[  �����[�����[    �����[ �������������[
 * �����U  �����U�����U    �����U�����X�T�T�T�T�a
 * ���������������U�����U ���[ �����U�����U  �������[
 * �����X�T�T�����U�����U�������[�����U�����U   �����U
 * �����U  �����U�^�������X�������X�a�^�������������X�a
 * �^�T�a  �^�T�a �^�T�T�a�^�T�T�a  �^�T�T�T�T�T�a
 * Created by huwenguang on 2018/5/9.
 */
@RunWith(Enclosed.class)
public class FancyServiceTest {

    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }

    @RunWith(VertxUnitRunner.class)
    public static class ipsGetAccessToken{
        Vertx vertx;
        HttpServer myserver;
        int port;
        FancyService sut;

        protected void handlerIpsTokenNormal(RoutingContext routingContext){
            JsonObject jo = new JsonObject().put("retcode", "0000").put("retmsg", "ok").put("access_token", "access_token");
            routingContext.response().end(jo.toString());
        }
        protected void handlerIpsTokenFail(RoutingContext routingContext){
            JsonObject jo = new JsonObject().put("retcode", "8000").put("retmsg", "ok").put("access_token", "access_token");
            routingContext.response().end(jo.toString());
        }
        protected void handlerIpsTokenFailTimeout(RoutingContext routingContext){
            vertx.setTimer(5000, ar -> {
                JsonObject jo = new JsonObject().put("retcode", "0000").put("retmsg", "ok").put("access_token", "access_token");
                routingContext.response().end(jo.toString());;

            });

//            vertx.<String>executeBlocking(ft -> {
//                try{ Thread.sleep(5000); }catch (Exception ex){ ex.printStackTrace(); }
//                JsonObject jo = new JsonObject().put("retcode", "0000").put("retmsg", "ok").put("access_token", "access_token");
//                ft.complete(jo.toString());
//            }, ar -> {
//                routingContext.response().end( ar.result() );
//            });

        }

        @Before
        public void setUp(TestContext context) throws Exception{
            ServerSocket socket = new ServerSocket(0);
            port = socket.getLocalPort();
            socket.close();

            vertx = Vertx.vertx();
            Router myrouter = Router.router(vertx);
            myrouter.route("/test/token/normal").handler(this::handlerIpsTokenNormal);
            myrouter.route("/test/token/failRetcode").handler(this::handlerIpsTokenFail);
            myrouter.route("/test/token/timeout").handler(this::handlerIpsTokenFailTimeout);
            myserver = vertx.createHttpServer()
                    .requestHandler(myrouter::accept)
                    .listen(port, context.asyncAssertSuccess());
            sut = new FancyService(vertx, "logId");

        }
        @After
        public void tearDown(TestContext context) throws Exception{
            vertx.close(context.asyncAssertSuccess());
        }
        @Test
        public void normalTest(TestContext context) throws Exception{
            Async async = context.async();
            String strUrlOfIpsToken = String.format("http://localhost:%s/test/token/normal", port);
            sut.ipsGetAccessToken(strUrlOfIpsToken, 5, "appid", ar -> {
                context.assertTrue(ar.succeeded());
                context.assertEquals("access_token", ar.result());
                async.complete();
            });
        }

        @Test
        public void normalFail_expect_fail(TestContext context) throws Exception{
            Async async = context.async();
            String strUrlOfIpsToken = String.format("http://localhost:%s/test/token/failRetcode", port);
            sut.ipsGetAccessToken(strUrlOfIpsToken, 5, "appid", ar -> {
                context.assertTrue(ar.failed());
                async.complete();
            });
        }

        @Test
        public void normalFail_expect_fail_usingAssertFail(TestContext context) throws Exception{
            String strUrlOfIpsToken = String.format("http://localhost:%s/test/token/failRetcode", port);
//            sut.ipsGetAccessToken(strUrlOfIpsToken, 5, "appid", context.asyncAssertFailure(ar -> {
//                context.assertTrue( ar.getCause() instanceof Throwable );
//            }));
            sut.ipsGetAccessToken(strUrlOfIpsToken, 5, "appid", context.asyncAssertFailure( ar -> {
//                System.out.println( ar.getMessage() );
            } ));
        }


        @Test
        public void timeout_expect_fail(TestContext context) throws Exception{
            Async async = context.async();
            String strUrlOfIpsToken = String.format("http://localhost:%s/test/token/timeout", port);
            sut.ipsGetAccessToken(strUrlOfIpsToken, 2, "appid", ar -> {
                context.assertTrue(ar.failed());
                async.complete();
            });

        }
    }


    @RunWith(VertxUnitRunner.class)
    public static class ipsSendSMS{
        @Test
        public void mobilePhoneWrong_expect_fail() throws Exception{

        }
    }

    @RunWith(VertxUnitRunner.class)
    public static class pushWxAppMessage{
        Vertx vertx;
        HttpServer myserver;
        int port;
        FancyService sut;


        public void handlerWxNormal(RoutingContext routingContext){
            JsonObject jo = new JsonObject().put("errcode", 0).put("retmsg", "ok");
            routingContext.response().end(jo.toString());
        }

        public void handlerWxFail(RoutingContext routingContext){
            JsonObject jo = new JsonObject().put("errcode", 10).put("retmsg", "fail");
            routingContext.response().end(jo.toString());
        }

        public void handlerWxTimeout(RoutingContext routingContext){
            vertx.setTimer(5000, ar -> {
                JsonObject jo = new JsonObject().put("errcode", 0).put("retmsg", "longtime");
                routingContext.response().end(jo.toString());

            });
        }

        @Before
        public void setUp(TestContext context) throws Exception{
            ServerSocket socket = new ServerSocket(0);
            port = socket.getLocalPort();
            socket.close();

            vertx = Vertx.vertx();
            Router myrouter = Router.router(vertx);
            myrouter.route("/test/wx/normal").handler(this::handlerWxNormal);
            myrouter.route("/test/wx/fail").handler(this::handlerWxFail);
            myrouter.route("/test/wx/timeout").handler(this::handlerWxTimeout);
            myserver = vertx.createHttpServer()
                    .requestHandler(myrouter::accept)
                    .listen(port, context.asyncAssertSuccess());
            sut = new FancyService(vertx, "logId");

        }
        @After
        public void tearDown(TestContext context) throws Exception{
            vertx.close(context.asyncAssertSuccess());
        }


        @Test
        public void normal_expect_ok(TestContext context) throws Exception{
            JsonObject kafkaJson = new JsonObject();
            Async async = context.async();
            String url = String.format("http://localhost:%s/test/wx/normal", port);
            sut.pushWxAppMessage(url, 3, "accessToken", "sendmsg", kafkaJson, ar->{
                context.assertTrue(ar.succeeded());
                async.complete();
            });

        }


        @Test
        public void fail_expect_false(TestContext context) throws Exception{
            JsonObject kafkaJson = new JsonObject();
            Async async = context.async();
            String url = String.format("http://localhost:%s/test/wx/fail", port);
            sut.pushWxAppMessage(url, 3, "accessToken", "sendmsg", kafkaJson, ar->{
                context.assertTrue(ar.failed());
                async.complete();
            });
        }


        @Test
        public void fail_expect_false2(TestContext context) throws Exception{
            JsonObject kafkaJson = new JsonObject();
            String url = String.format("http://localhost:%s/test/wx/fail", port);
            sut.pushWxAppMessage(url, 3, "accessToken", "sendmsg", kafkaJson, context.asyncAssertFailure());
        }





        @Test
        public void timeout_expect_false(TestContext context) throws Exception{
            JsonObject kafkaJson = new JsonObject();
            Async async = context.async();
            String url = String.format("http://localhost:%s/test/wx/timeout", port);
            sut.pushWxAppMessage(url, 1, "accessToken", "sendmsg", kafkaJson, ar->{
                context.assertTrue(ar.failed());
                async.complete();
            });
        }

        @Test
        public void longtime_butNotTimeout_expect_ok(TestContext context) throws Exception{
            JsonObject kafkaJson = new JsonObject();
            Async async = context.async();
            String url = String.format("http://localhost:%s/test/wx/timeout", port);
            sut.pushWxAppMessage(url, 10, "accessToken", "sendmsg", kafkaJson, ar->{
                context.assertTrue(ar.succeeded());
                async.complete();
            });
        }
    }
}