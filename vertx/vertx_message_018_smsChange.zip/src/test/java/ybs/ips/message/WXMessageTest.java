package ybs.ips.message;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import io.vertx.core.json.JsonObject;
import junit.framework.TestCase;
import ybs.ips.message.util.Util;

public class WXMessageTest extends TestCase {

	private String replacePatternWithDateValue(String strDate/*20180101102030*/, String fmtWhole/*YYYYMMDDhhmmss*/, String fmtToTake/*YYYY*/){
		String value = strDate;
		int findpos  = fmtWhole.indexOf(fmtToTake);
		int NOTFOUND = -1;
		if(NOTFOUND != findpos){
			value = Util.safeSubString(strDate, findpos, fmtToTake.length());
		}

		return value;
	}
	
	private String replaceDatePattern(String strWithPattern, JsonObject kafkaJson){
		String newString= strWithPattern;
		Pattern pattern = Pattern.compile("<<(.*?):(.*?):(.*?)>>");
		Matcher mt = pattern.matcher(strWithPattern);
		while (mt.find()){
			String strBraceWithKey = mt.group(0);
			String strOnlyKey      = mt.group(1);
			String strDateValue    = Util.safeGetJsonString(kafkaJson, strOnlyKey, "");
			String fmtWhole        = mt.group(2);
			String fmtToTake       = mt.group(3);
			String str2replace     = replacePatternWithDateValue(strDateValue, fmtWhole, fmtToTake);

			newString = newString.replaceAll(strBraceWithKey, str2replace);
		}

		return newString;
	}

	private String replaceNormalPattern(String strWithPattern, JsonObject kafkaJson){
		String newString= strWithPattern;
//		Pattern pattern = Pattern.compile("\\{(\\w+)\\}");
//		Pattern pattern = Pattern.compile("<(\\w+)>");
		Pattern pattern = Pattern.compile("<(.*?)>");
		Matcher mt = pattern.matcher(strWithPattern);
		while (mt.find()){
			String strBraceWithKey = mt.group(0);
			String strOnlyKey      = mt.group(1);
			String strValue        = Util.safeGetJsonString(kafkaJson, strOnlyKey, "");
			newString = newString.replaceAll(strBraceWithKey, strValue);
		}

		return newString;
	}

	
	private JsonObject getWxAppMsgJsonObject(JsonObject dbConfJson, JsonObject kafkaJson){
		//region �������΢������ע��
		// {
//			"touser": "OPENID",
//			"template_id": "TEMPLATE_ID",
//			"page": "index",
//			"form_id": "FORMID",
//			"data": {
//			"keyword1": {
//				"value": "339208499",
//						"color": "#173177"
//			},
//			"keyword2": {
//				"value": "2015��01��05�� 12:30",
//						"color": "#173177"
//			},
//			"keyword3": {
//				"value": "����ϲ���ǾƵ�",
//						"color": "#173177"
//			} ,
//			"keyword4": {
//				"value": "��������������·208��",
//						"color": "#173177"
//			}
//		},
//			"emphasis_keyword": "keyword1.DATA"
//		}
		//endregionע��


		JsonObject joWxSend = new JsonObject();
		try{
			String strTmplInDB = Util.safeGetJsonString(dbConfJson, "msg_template", "");
			String template_id = Util.safeGetJsonString(dbConfJson, "template_id", "");

			JsonObject joKafkaCopy = new JsonObject(kafkaJson.toString());
			joKafkaCopy.put("template_id", template_id);


			String strNewJson  = replaceDatePattern(strTmplInDB, joKafkaCopy);
			strNewJson         = replaceNormalPattern(strNewJson, joKafkaCopy);

			joWxSend           = new JsonObject(strNewJson);

		}catch (Exception ex){
			String fmtError = Util.getStacktrackInfo(ex);
			String msg = String.format("��΢�ŷ�����Ϣʱ����[%s]", fmtError);
		}

		return joWxSend;
	}
	
	public void testJsonObject() {
		JsonObject kafkaJson = new JsonObject("{\"resfdacctissrid\":\"8610000000000000180\",\"shunt_flag\":\"K\",\"tfbackno\":\"0000\",\"tftxcount\":\"4\",\"idtp\":\"01\",\"tffwdinsid\":\"0880158489\",\"tfbncode\":\"627706\",\"pyeeacctid\":\"6212264000023662394\",\"tfbankrefno\":\"\",\"tfintype\":\"02\",\"instgacctnm\":\"�������װ��³��⳵ҵ�񱸸���\",\"tfbnussn\":\"009240\",\"pyeenm\":\"����\",\"uuid\":\"c06d7a98-8ca3-4b76-abff-70e5e112a82f\",\"tfteacct\":\"0000000000000234567\",\"tfdistcode\":\"\",\"pyeemobno\":\"13026620212\",\"tftermno\":\"60023403\",\"pyeemarkid\":\"0000000000000234567\",\"tftermid\":\"60023403|\",\"idno\":\"440582199401167026\",\"tftxdeta\":\"\",\"pyeraccttp\":\"0\",\"batch_startdate\":\"20180801\",\"taskid\":\"2c501f88ef7c4276ab8f05c0e9755165\",\"tftxfee\":\"0.00\",\"tftxcode\":\"0802TX1740009240\",\"tftxbatch\":\"000231\",\"tftranstype\":\"122\",\"tfcardtype\":\"DE\",\"old_uuid\":\"\",\"pyernm\":\"����\",\"pyeeacctissrid\":\"0800965840\",\"tftmccode\":\"000210440360519112\",\"tfcharge\":\"0.04\",\"tftxmony\":\"0.10\",\"datafrom\":\"jstt_taxi\",\"batchSettDate\":\"20180802\",\"tfacmony\":\"0.10\",\"mersettcode\":\"\",\"pyeracctid\":\"8610000033900441154\",\"tfmccode\":\"000339\",\"openid\":\"oTyEL1tHo89JQDiZfAKH2dLbiFc8\",\"logid\":\"e7eb0e19\",\"tfacctdt\":\"20180802\",\"tfperdata\":\"\",\"tfmemo_2bank\":\"\",\"sms_flag\":\"1\",\"mobno\":\"13026620212\",\"tfrcvinsid\":\"0800965840\",\"discount_amt\":\"0.00\",\"pyeeidno\":\"440582199401167026\",\"tfacqinsid\":\"0800965840\",\"bizstsdesc\":\"00:�ɹ�\",\"tfdate\":\"20180806172945\",\"instgacctid\":\"8610000000000000180\",\"pyeeidtp\":\"01\",\"sms_content\":\"˾������20180803����100.00Ԫ\",\"sms_flag\":\"1\",\"sms_fromuser\":\"ips_message_sms\"}");
		JsonObject joDBConf   = new JsonObject("{\"update_time\":\"2018-07-04 14:33:40\",\"appid\":\"wx72207983ae3fe629\",\"id\":10,\"msg_template\":\"{    \\\"touser\\\": \\\"<openid>\\\",    \\\"template_id\\\": \\\"<template_id>\\\",    \\\"form_id\\\": \\\"<tftxcode>\\\",    \\\"data\\\": {        \\\"first\\\": {            \\\"value\\\": \\\"�𾴵Ŀͻ�����<<tfdate:YYYYMMDDhhmmss:YYYY>>��<<tfdate:YYYYMMDDhhmmss:MM>>��<<tfdate:YYYYMMDDhhmmss:DD>>�� <<tfdate:YYYYMMDDhhmmss:hh>>:<<tfdate:YYYYMMDDhhmmss:mm>> ���������װ��³��⳵֧��ƽ̨���㽻�ף��ϼƽ���<tftxcount>�ʣ��ܼ�:<tftxmony>Ԫ����ˮ�ţ�<tftxbatch>��\\\"        },        \\\"keyword1\\\": {            \\\"value\\\": \\\"<<tfdate:YYYYMMDDhhmmss:YYYY>>��<<tfdate:YYYYMMDDhhmmss:MM>>��<<tfdate:YYYYMMDDhhmmss:DD>>��\\\"        },        \\\"keyword2\\\": {            \\\"value\\\": \\\"���㽻��\\\"        },        \\\"keyword3\\\": {            \\\"value\\\": \\\"<tftxcode>\\\"        },        \\\"keyword4\\\": {            \\\"value\\\": \\\"RMB <tftxmony>Ԫ\\\",            \\\"color\\\": \\\"#FF0000\\\"        },        \\\"remark\\\": {            \\\"value\\\": \\\"\\\"        }    }}\",\"create_time\":\"2018-05-16 11:34:34\",\"url\":null,\"msg_color\":\"#173177\",\"template_id\":\"rkOWhNP-0DRAdXs-LWkvHGEun82rHt6xDtjxJWGPVB0\",\"appsecret\":\"\",\"push_type\":\"PA\",\"mccode\":\"000339\"}");
		
		JsonObject joWxSend   = getWxAppMsgJsonObject(joDBConf, kafkaJson);
		System.out.println(joWxSend);
		JsonObject jo = Util.safeGetJsonObject(Util.safeGetJsonObject(joWxSend,"data"), "first");
		String value = Util.safeGetJsonString(jo, "value", "");
		System.out.println(value);
		
		assertEquals("�𾴵Ŀͻ�����2018��08��06�� 17:29 ���������װ��³��⳵֧��ƽ̨���㽻�ף��ϼƽ���4�ʣ��ܼ�:0.10Ԫ����ˮ�ţ�000231��", value);
	}
}
