package ybs.ips.message.util;

import io.vertx.core.json.JsonObject;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.runners.Enclosed;
import org.junit.runner.RunWith;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.Collections;
import java.util.Date;

import static org.junit.Assert.*;

/**
 * �����[  �����[�����[    �����[ �������������[
 * �����U  �����U�����U    �����U�����X�T�T�T�T�a
 * ���������������U�����U ���[ �����U�����U  �������[
 * �����X�T�T�����U�����U�������[�����U�����U   �����U
 * �����U  �����U�^�������X�������X�a�^�������������X�a
 * �^�T�a  �^�T�a �^�T�T�a�^�T�T�a  �^�T�T�T�T�T�a
 * Created by huwenguang on 2018/4/28.
 */
@RunWith(Enclosed.class)
public class UtilTest {

    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void test() throws Exception {
    }


    public static class getFirstNotEmpty{
        @Test
        public void stringsAllEmpty1() throws Exception {
            String first = null;
            String result = Util.getFirstNotEmpty(first);
            assertEquals("", result);
        }

        @Test
        public void stringsAllEmpty3() throws Exception {
            String first = null;
            String second = null;
            String third = null;
            String result = Util.getFirstNotEmpty(first, second, third);
            assertEquals("", result);
        }
        @Test
        public void firstIsEmpty() throws Exception {
            String first = null;
            String second = "second";
            String third = null;
            String result = Util.getFirstNotEmpty(first, second, third);
            assertEquals("second", result);
        }
        @Test
        public void allNotEmpty() throws Exception {
            String first = "first";
            String second = "second";
            String third = "third";
            String result = Util.getFirstNotEmpty(first, second, third);
            assertEquals("first", result);
        }
    }

    public static class parseJsonString{
        @Test
        public void notJsonString() throws Exception {
            String strjson = "{\"name\":\"test\",\"color\":\"black\"";
            JsonObject result = Util.parseJsonString(strjson);
            assertEquals(0, result.size());
        }

        @Test
        public void isJsonString() throws Exception {
            String strjson = "{\"name\":\"test\",\"color\":\"black\"}";
            JsonObject result = Util.parseJsonString(strjson);
            assertEquals(2, result.size());
            assertEquals("test", result.getString("name"));
        }
    }

    public static class JsonObjectParseTest{
        @Test
        public void getJsonObjectFromString() throws Exception {
            String strTest = "{\"first\": {\"value\": \"�𾴵Ŀͻ���\\r\\n  \\r\\n��{tfdate}���������װ��³��⳵֧��ƽ̨���㽻�ף��ϼƽ���{tftxcount}�ʣ��ܼ�:{tfacmony}Ԫ����ˮ�ţ�{tftxbatch}��\\r\\n\",\"keyformat\": {\"tfdate\": \"yyyy��MM��dd��\"}},\"keywords\": {\"keyword1\": {\"value\": \"{tfdate}\",\"keyformat\": {\"tfdate\": \"yyyy��MM��dd��\"}},\"keyword2\": {\"value\": \"���㽻��\"},\"keyword3\": {\"value\": \"{tftxcode}\"},\"keyword4\": {\"value\": \"RMB{tftxmony}Ԫ\",\"color\": \"#FF0000\"}},\"remark\": {\"value\": \"\"}}";
            JsonObject jo = new JsonObject(strTest);
            assertNotNull(jo);
            assertNotNull(jo.getJsonObject("first"));
        }
    }

    public static class textTest{
        interface Text{
            public String read();
        }

        class TextInFile implements Text{
            private final File file;
            public TextInFile(final File file){
                this.file = file;
            }
            @Override
            public String read() {
                String content = "";

                try{
                    content = new String( Files.readAllBytes(file.toPath()), "GBK");
                }catch (IOException e){}

                return content;
            }
        }

        class TextInString implements Text{
            private final String text;
            public TextInString(final String text){
                this.text = text;
            }
            @Override
            public String read() {
                return this.text;
            }
        }

        class PrintableText implements Text{
            private final Text original;
            public PrintableText(final Text text){
                this.original = text;
            }
            @Override
            public String read() {
                return original.read().replaceAll("[^\\p{Print}]", "");
            }

        }

        class AllCapsText implements Text{
            private final Text original;
            public AllCapsText(final Text text){
                original = text;
            }
            @Override
            public String read() {
                return original.read().toUpperCase();
            }
        }

        class TrimmedText implements Text{
            private final Text original;
            public TrimmedText(final Text text){
                original = text;
            }
            @Override
            public String read() {
                return original.read().trim();
            }
        }

        @Test
        public void test() throws Exception {
            String result = new AllCapsText( new TrimmedText( new TextInString(" test ") ) ).read();
            assertEquals("TEST", result);
        }
    }

    public static class timeGetDateFromString{
        @Test
        public void format_error_return_null_date() throws Exception{
//            Date result = Util.timeGetDateFromString("20180713160100", "yyyyMMddHHmmss");
            Date result = Util.timeGetDateFromString("2018071316", "yyyyMMddHHmm");
            assertNull(result);
            assertTrue(null == result);
        }

        @Test
        public void good_format_expect_true() throws Exception{
            Date result = Util.timeGetDateFromString("20180713160100", "yyyyMMddHHmmss");
            assertNotNull(result);
            assertTrue(null != result);
            assertEquals(2018-1900, result.getYear());
            assertEquals(7-1, result.getMonth());
            assertEquals(13, result.getDate());
            assertEquals(16, result.getHours());
            assertEquals(1, result.getMinutes());
            assertEquals(0, result.getSeconds());
        }
    }




    public static class timeGetDateDiffSecs{
        @Test
        public void future_is_small_than_now() throws Exception{
            Date now = new Date(2018, 7, 1, 2, 3, 10);
            Date future = new Date(2018, 7, 1, 2, 3, 9);
            long timespan = Util.timeGetDateDiffSecs(now, future);
            assertEquals(-1, timespan);
        }

        @Test
        public void future_and_now_equal() throws Exception{
            Date now = new Date(2018, 7, 1, 2, 3, 10);
            Date future = new Date(2018, 7, 1, 2, 3, 10);
            long timespan = Util.timeGetDateDiffSecs(now, future);
            assertEquals(0, timespan);
        }

        @Test
        public void future_is_bigger_than_now() throws Exception{
            Date now = new Date(2018, 7, 1, 2, 3, 10);
            Date future = new Date(2018, 7, 1, 2, 3, 11);
            long timespan = Util.timeGetDateDiffSecs(now, future);
            assertEquals(1, timespan);
        }
    }

    public static class timeGetDateString{
        @Test
        public void normal() throws Exception{
            Date now = new Date(2018-1900, 0, 1, 6, 0, 0);
            String strDate = Util.timeGetDateString(now, "yyyyMMddHHmmss");
            assertEquals("20180101060000", strDate);
        }
    }

    public static class safeStringEquals{
        @Test
        public void null_equal_null_expect_false() throws Exception{
            String strDavid = null;
            String strAlbert = null;
            boolean bResult = Util.safeStringEquals(strDavid, strAlbert);
            assertFalse(bResult);
        }
        @Test
        public void null_notNull_expect_false() throws Exception{
            String strDavid = null;
            String strAlbert = "test";
            boolean bResult = Util.safeStringEquals(strDavid, strAlbert);
            assertFalse(bResult);
        }

    }

    public static class json2KeyValue{
        @Test
        public void jsonIsNull() throws Exception{
            JsonObject jo = null;
            String result = Util.json2KeyValue(jo);
            assertEquals("", result);
        }
        @Test
        public void jsonIsEmpty() throws Exception{
            JsonObject jo = new JsonObject();
            String result = Util.json2KeyValue(jo);
            assertEquals("", result);
        }
        @Test
        public void jsonIsNormal() throws Exception{
            JsonObject jo = new JsonObject().put("k1", "v1").put("k2", "v2").put("a1", "a1");
            String result = Util.json2KeyValue(jo);
            assertEquals("a1=a1&k1=v1&k2=v2", result);
        }
    }

    public static class myHashMccode{

        @Test
        public void abnormal_null_empty() throws Exception{
            String mccode, result;

            mccode = null;
            result = Util.myHashMccode(mccode);
            assertEquals("", result);

            mccode = "";
            result = Util.myHashMccode(mccode);
            assertEquals("", result);
        }

        @Test
        public void normal_single() throws Exception{
            String mccode, result;

            // "0" dec:48 hex: 0x30
            result = Util.myHashMccode("0");
            assertEquals("w", result);
        }

        @Test
        public void normal_000000() throws Exception{
            String mccode, result;

            // "0" dec:48 hex: 0x30
            result = Util.myHashMccode("000000");
            assertEquals("c00000", result);


            result = Util.myHashMccode("000339");
            System.out.println(result);
        }
    }

    public static class takeRight{
        @Test
        public void takeRight() throws Exception {
            String strSource, strResult;
            int right;

            strSource = null;
            strResult = Util.takeRight(strSource, 2);
            assertNull(strResult);

            strSource = "test";
            strResult = Util.takeRight(strSource, 5);
            assertEquals("test", strResult);
            strResult = Util.takeRight(strSource, 4);
            assertEquals("test", strResult);
            strResult = Util.takeRight(strSource, 2);
            assertEquals("st", strResult);
        }
    }

    public static class safeSubString{
        @Test
        public void testNormal() throws Exception{
            String strInput, result;
            int startindex, length;

            result = Util.safeSubString("hello", 0, 2);
            assertEquals("he", result);

            result = Util.safeSubString("hello", 0, 5);
            assertEquals("hello", result);

            result = Util.safeSubString("hello", 0, 6);
            assertEquals("hello", result);
        }

        @Test
        public void startIndexBeyond() throws Exception{
            String strInput, result;
            int startindex, length;

            result = Util.safeSubString("hello", 6, 2);
            assertEquals("", result);
        }
    }

    public static class strRepeat{
        @Test
        public void normal() throws Exception{
            String result;

            result = Util.strRepeat(2, ' ');
            assertEquals("  ", result);

            result = Util.strRepeat(2, '@');
            assertEquals("@@", result);

            result = Util.strRepeat(2, '?');
            assertEquals("??", result);
        }
        @Test
        public void abnormal() throws Exception{
            String result;

            result = Util.strRepeat(0, ' ');
            assertEquals("", result);

            result = Util.strRepeat(-2, ' ');
            assertEquals("", result);

        }
    }

    public static class trimPaddingRight{
        @Test
        public void normal_equal() throws Exception{
            String result;

            result = Util.trimPaddingRight("hello", 5, ' ');
            assertEquals("hello", result);
        }

        @Test
        public void less_padding() throws Exception{
            String result;

            result = Util.trimPaddingRight("hello", 6, ' ');
            assertEquals("hello ", result);
        }


        @Test
        public void more_trim() throws Exception{
            String result;

            result = Util.trimPaddingRight("hello", 2, ' ');
            assertEquals("he", result);
        }

        @Test
        public void abnormal_maxlen_is_negative() throws Exception{
            String result;

            result = Util.trimPaddingRight("hello", -2, ' ');
            assertEquals("", result);
        }

        @Test
        public void input_is_null() throws Exception{
            String result, strInput;

            strInput = null;
            result = Util.trimPaddingRight(strInput, 2, ' ');
            assertEquals("  ", result);
        }
    }

    public static class safeGetJsonString{
        @Test
        public void jsonObjectIsNull() throws Exception{
            JsonObject jo = null;
            String key, defvalue, strResult;

            strResult = Util.safeGetJsonString(jo, "notexist", "myvalue");
            assertEquals("myvalue", strResult);
        }

        @Test
        public void keyNotExist() throws Exception {
            JsonObject jo;
            String key, defvalue, strResult;

            jo = new JsonObject().put("key1", "value1");
            strResult = Util.safeGetJsonString(jo, "notexist", "myvalue");
            assertEquals("myvalue", strResult);

        }

        @Test
        public void valueIsNotString() throws Exception {
            JsonObject jo;
            String key, defvalue, strResult;

            jo = new JsonObject().put("key1", 50);
            strResult = Util.safeGetJsonString(jo, "key1", "myvalue");
            assertEquals("50", strResult);

        }

        @Test
        public void normalTest() throws Exception {
            JsonObject jo;
            String key, defvalue, strResult;

            jo = new JsonObject().put("key1", "50");
            strResult = Util.safeGetJsonString(jo, "key1", "myvalue");
            assertEquals("50", strResult);

        }
    }

    public static class safeGetJsonInt{
        @Test
        public void normalTest() throws Exception {
            JsonObject jo;
            String key, defvalue, strResult;
            int iResult;

            jo = new JsonObject().put("key1", 50);
            iResult = Util.safeGetJsonInt(jo, "key1", 0);
            assertEquals(50, iResult);

        }

        @Test
        public void valueIsNotInt_isString_canconvertToInt() throws Exception {
            JsonObject jo;
            String key, defvalue, strResult;
            int iResult;

            jo = new JsonObject().put("key1", "50");
            iResult = Util.safeGetJsonInt(jo, "key1", 0);
            assertEquals(50, iResult);
        }


        @Test
        public void valueIsNotInt_isString_canNotConvertInt() throws Exception {
            JsonObject jo;
            String key, defvalue, strResult;
            int iResult;

            jo = new JsonObject().put("key1", "50null");
            iResult = Util.safeGetJsonInt(jo, "key1", 0);
            assertEquals(0, iResult);
        }

        @Test
        public void keyNotExist() throws Exception {
            JsonObject jo;
            String key, defvalue, strResult;
            int iResult;

            jo = new JsonObject().put("key1", "50");
            iResult = Util.safeGetJsonInt(jo, "keyNotExist", 0);
            assertEquals(0, iResult);
        }
    }

}