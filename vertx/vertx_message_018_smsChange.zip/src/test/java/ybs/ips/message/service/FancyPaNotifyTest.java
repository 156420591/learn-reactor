package ybs.ips.message.service;

import io.vertx.core.Vertx;
import io.vertx.core.json.JsonObject;
import io.vertx.ext.unit.junit.VertxUnitRunner;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.runners.Enclosed;
import org.junit.runner.RunWith;
import ybs.ips.message.constant.ConstantSYS;
import ybs.ips.message.util.Util;

import java.util.Date;

import static org.junit.Assert.*;

/**
 * �����[  �����[�����[    �����[ �������������[
 * �����U  �����U�����U    �����U�����X�T�T�T�T�a
 * ���������������U�����U ���[ �����U�����U  �������[
 * �����X�T�T�����U�����U�������[�����U�����U   �����U
 * �����U  �����U�^�������X�������X�a�^�������������X�a
 * �^�T�a  �^�T�a �^�T�T�a�^�T�T�a  �^�T�T�T�T�T�a
 * Created by huwenguang on 2018/6/26.
 */
@RunWith(Enclosed.class)
public class FancyPaNotifyTest {

    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void testJsonPutKeyMultipleTimes() throws Exception {
        JsonObject jo = new JsonObject();
        jo.put("key1", "test");
        jo.put("key1", 10);
        assertEquals(10, jo.getInteger("key1").intValue());

        jo.put("key1", 20);
        assertEquals(20, jo.getInteger("key1").intValue());

        jo.put("key1", "test");
        assertEquals("test", jo.getString("key1"));
    }

    public static class isThisMsgTimeAllowedToProcess{
        @Test
        public void message_not_allowed_to_process_Notconfigured() throws Exception{
            JsonObject kafkaJson, sysConf;

            kafkaJson = new JsonObject().put(ConstantSYS.JSONKEY_timeStart, "20180715110000");
            sysConf = new JsonObject();
            FancyPaNotify sut = new FancyPaNotify(Vertx.vertx(), "logid", sysConf);

//            Date nowtime = new Date(2018-1900, 7, 16, 14, 0, 0);
            Date nowtime = Util.timeGetDateFromString("20180717110000", "yyyyMMddHHmmss");
            boolean result = sut.isThisMsgTimeAllowedToProcess(kafkaJson, sysConf, nowtime);
            assertFalse(result);
        }
        @Test
        public void message_allowed_to_process_Notconfigured() throws Exception{
            JsonObject kafkaJson, sysConf;

            kafkaJson = new JsonObject().put(ConstantSYS.JSONKEY_timeStart, "20180715110000");
            sysConf = new JsonObject();
            FancyPaNotify sut = new FancyPaNotify(Vertx.vertx(), "logid", sysConf);

            Date nowtime = Util.timeGetDateFromString("20180715170000", "yyyyMMddHHmmss");
            boolean result = sut.isThisMsgTimeAllowedToProcess(kafkaJson, sysConf, nowtime);
            assertTrue(result);
        }
        @Test
        public void message_allowed_to_process_configured() throws Exception{
            JsonObject kafkaJson, sysConf;

            kafkaJson = new JsonObject().put(ConstantSYS.JSONKEY_timeStart, "20180715110000");
            sysConf = new JsonObject().put(ConstantSYS.JSONKEY_paTimeToLive, 86400*2);
            FancyPaNotify sut = new FancyPaNotify(Vertx.vertx(), "logid", sysConf);

            Date nowtime = Util.timeGetDateFromString("20180717110000", "yyyyMMddHHmmss");
            boolean result = sut.isThisMsgTimeAllowedToProcess(kafkaJson, sysConf, nowtime);
            assertTrue(result);
        }

        @Test
        public void message_not_allowed_to_process_configured() throws Exception{
            JsonObject kafkaJson, sysConf;

            kafkaJson = new JsonObject().put(ConstantSYS.JSONKEY_timeStart, "20180715110000");
            sysConf = new JsonObject().put(ConstantSYS.JSONKEY_paTimeToLive, 2);
            FancyPaNotify sut = new FancyPaNotify(Vertx.vertx(), "logid", sysConf);

            Date nowtime = Util.timeGetDateFromString("20180715110007", "yyyyMMddHHmmss");
            boolean result = sut.isThisMsgTimeAllowedToProcess(kafkaJson, sysConf, nowtime);
            assertFalse(result);
        }
    }

    public static class isMsgLastSendTimeBigThanSpan{
        @Test
        public void first_kafka_msg_is_bigger_than_span() throws Exception{
            JsonObject kafkaJson, sysConf;

            kafkaJson = new JsonObject();
            sysConf   = new JsonObject();
            FancyPaNotify sut = new FancyPaNotify(Vertx.vertx(), "logid", sysConf);

            Date nowtime = Util.timeGetDateFromString("2018071316", "yyyyMMddHHmm");
            boolean isBigger = sut.isMsgLastSendTimeBigThanSpan(kafkaJson, sysConf, nowtime);
            boolean isSmaller = sut.isMsgLastSendTimeSmallThanSpan(kafkaJson, sysConf, nowtime);
            assertTrue(isBigger);
            assertFalse(isSmaller);
        }

        @Test
        public void nowtime_minus_kafkaLastSendTime_is_bigger_than_span() throws Exception{
            JsonObject kafkaJson, sysConf;

            kafkaJson = new JsonObject().put("paMessageLastSendTime", "20180713141000");
            sysConf   = new JsonObject();
            FancyPaNotify sut = new FancyPaNotify(Vertx.vertx(), "logid", sysConf);

            Date nowtime = Util.timeGetDateFromString("20180713141300", "yyyyMMddHHmmss");
            boolean isBigger = sut.isMsgLastSendTimeBigThanSpan(kafkaJson, sysConf, nowtime);
            boolean isSmaller = sut.isMsgLastSendTimeSmallThanSpan(kafkaJson, sysConf, nowtime);
            assertTrue(isBigger);
            assertFalse(isSmaller);

        }

        @Test
        public void nowtime_minus_kafkaLastSendTime_is_bigger_than_span_configured() throws Exception{
            JsonObject kafkaJson, sysConf;

            kafkaJson = new JsonObject().put("paMessageLastSendTime", "20180713141000");
            sysConf   = new JsonObject().put("paNotifySpan", 120);
            FancyPaNotify sut = new FancyPaNotify(Vertx.vertx(), "logid", sysConf);

            Date nowtime = Util.timeGetDateFromString("20180713141200", "yyyyMMddHHmmss");
            boolean isBigger = sut.isMsgLastSendTimeBigThanSpan(kafkaJson, sysConf, nowtime);
            boolean isSmaller = sut.isMsgLastSendTimeSmallThanSpan(kafkaJson, sysConf, nowtime);
            assertTrue(isBigger);
            assertFalse(isSmaller);

        }

        @Test
        public void nowtime_minus_kafkaLastSendTime_is_smaller_than_span_configured() throws Exception{
            JsonObject kafkaJson, sysConf;

            kafkaJson = new JsonObject().put("paMessageLastSendTime", "20180713141000");
            sysConf   = new JsonObject();
            FancyPaNotify sut = new FancyPaNotify(Vertx.vertx(), "logid", sysConf);

            Date nowtime = Util.timeGetDateFromString("20180713141200", "yyyyMMddHHmmss");
            boolean isBigger = sut.isMsgLastSendTimeBigThanSpan(kafkaJson, sysConf, nowtime);
            boolean isSmaller = sut.isMsgLastSendTimeSmallThanSpan(kafkaJson, sysConf, nowtime);
            assertFalse(isBigger);
            assertTrue(isSmaller);

        }
    }


    @RunWith(VertxUnitRunner.class)
    public static class isThisMsgAllowedSendTimes{
        @Test
        public void conf_not_configured_and_allowed_all_the_time() throws Exception{
//            Vertx vertx, String logId, JsonObject kafkaJson, JsonObject sysConf
            JsonObject kafkaJson, sysConf;

            kafkaJson = new JsonObject().put("paNotifyMaxCount", 1000);
            sysConf   = new JsonObject();
            FancyPaNotify sut = new FancyPaNotify(Vertx.vertx(), "logid", sysConf);
            boolean bResult = sut.isThisMsgAllowedSendTimes(kafkaJson);
            assertTrue(bResult);
        }
        @Test
        public void conf_set_zero_and_allowed_all_the_time() throws Exception{
            JsonObject kafkaJson, sysConf;

            kafkaJson = new JsonObject().put("paNotifyMaxCount", 1000);
            sysConf   = new JsonObject().put("paNotifyMaxCount", 0);
            FancyPaNotify sut = new FancyPaNotify(Vertx.vertx(), "logid", sysConf);
            boolean bResult = sut.isThisMsgAllowedSendTimes(kafkaJson);
            assertTrue(bResult);
        }
        @Test
        public void conf_set_10_and_kafka_data_no_expect_true() throws Exception{
            JsonObject kafkaJson, sysConf;

            kafkaJson = new JsonObject();
            sysConf   = new JsonObject().put("paNotifyMaxCount", 10);
            FancyPaNotify sut = new FancyPaNotify(Vertx.vertx(), "logid", sysConf);
            boolean bResult = sut.isThisMsgAllowedSendTimes(kafkaJson);
            assertTrue(bResult);
        }
        @Test
        public void conf_set_10_and_kafka_is_11_expect_false() throws Exception{
            JsonObject kafkaJson, sysConf;

            kafkaJson = new JsonObject().put("paNotifyMaxCount", 11);
            sysConf   = new JsonObject().put("paNotifyMaxCount", 10);
            FancyPaNotify sut = new FancyPaNotify(Vertx.vertx(), "logid", sysConf);
            boolean bResult = sut.isThisMsgAllowedSendTimes(kafkaJson);
            assertFalse(bResult);
        }
        @Test
        public void conf_set_10_and_kafka_is_1_expect_true() throws Exception {
            JsonObject kafkaJson, sysConf;

            kafkaJson = new JsonObject().put("paNotifyMaxCount", 1);
            sysConf = new JsonObject().put("paNotifyMaxCount", 10);
            FancyPaNotify sut = new FancyPaNotify(Vertx.vertx(), "logid", sysConf);
            boolean bResult = sut.isThisMsgAllowedSendTimes(kafkaJson);
            assertTrue(bResult);
        }
        @Test
        public void conf_set_10_and_kafka_is_10_expect_true() throws Exception{
            JsonObject kafkaJson, sysConf;

            kafkaJson = new JsonObject().put("paNotifyMaxCount", 10);
            sysConf = new JsonObject().put("paNotifyMaxCount", 10);
            FancyPaNotify sut = new FancyPaNotify(Vertx.vertx(), "logid", sysConf);
            boolean bResult = sut.isThisMsgAllowedSendTimes(kafkaJson);
            assertTrue(bResult);

        }
    }
}