package ybs.ips.message.service;

import io.vertx.core.Vertx;
import io.vertx.core.json.JsonArray;
import io.vertx.core.json.JsonObject;
import io.vertx.ext.unit.TestContext;
import io.vertx.ext.unit.junit.VertxUnitRunner;
import io.vertx.kafka.client.producer.KafkaProducer;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.junit.Test;
import org.junit.experimental.runners.Enclosed;
import org.junit.runner.RunWith;
import ybs.ips.message.handler.IpsMessageHandler;
import ybs.ips.message.util.Util;

import java.util.Date;
import java.util.Set;
import java.util.concurrent.atomic.AtomicReference;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

/**
 * �����[  �����[�����[    �����[ �������������[
 * �����U  �����U�����U    �����U�����X�T�T�T�T�a
 * ���������������U�����U ���[ �����U�����U  �������[
 * �����X�T�T�����U�����U�������[�����U�����U   �����U
 * �����U  �����U�^�������X�������X�a�^�������������X�a
 * �^�T�a  �^�T�a �^�T�T�a�^�T�T�a  �^�T�T�T�T�T�a
 * Created by huwenguang on 2018/4/27.
 */
@RunWith(Enclosed.class)
public class IpsMessageServiceTest {
    @Test
    public void testReplaceAll() throws Exception {
        String newString = "<hello>";
        String strReg = "<hello>";
        String result = newString.replaceAll(strReg, "world");
        assertEquals("world", result);
    }

    public static class getSepSets{
        @Test
        public void noItem() throws Exception{
            String strWhole;
            Set<String> result;


            String logId = "logId";
            JsonObject sysConf;
            sysConf = new JsonObject();

            IpsMessageService sut = new IpsMessageService(sysConf, logId);

            strWhole = new String(",");
            result = sut.getSepSets(strWhole);
            assertEquals(0, result.size());
            assertTrue(result.isEmpty());

        }

        @Test
        public void moreDelimiter() throws Exception{
            String strWhole;
            Set<String> result;


            String logId = "logId";
            JsonObject sysConf;
            sysConf = new JsonObject();

            IpsMessageService sut = new IpsMessageService(sysConf, logId);

            strWhole = new String("120,");
            result = sut.getSepSets(strWhole);
            assertEquals(1, result.size());
            assertTrue(result.contains("120"));
        }

        @Test
        public void sample() throws Exception{

        }
    }

    public static class replacePatternWithDateValue{
        @Test
        public void normal() throws Exception{
            String strWithPattern, result, expected;
            String logId = "logId";
            JsonObject sysConf,  kafkaJson;
            sysConf = new JsonObject();

            IpsMessageService sut = new IpsMessageService(sysConf, logId);


            String strDate, fmtWhole, fmtToTake;
            result = sut.replacePatternWithDateValue("20180102102030", "YYYYMMDDhhmmss", "YYYY");
            assertEquals("2018", result);

            result = sut.replacePatternWithDateValue("20180102102030", "YYYYMMDDhhmmss", "MM");
            assertEquals("01", result);

            result = sut.replacePatternWithDateValue("20180102102030", "YYYYMMDDhhmmss", "DD");
            assertEquals("02", result);

            result = sut.replacePatternWithDateValue("20180102102030", "YYYYMMDDhhmmss", "hh");
            assertEquals("10", result);

            result = sut.replacePatternWithDateValue("20180102102030", "YYYYMMDDhhmmss", "mm");
            assertEquals("20", result);

            result = sut.replacePatternWithDateValue("20180102102030", "YYYYMMDDhhmmss", "ss");
            assertEquals("30", result);
        }

        @Test
        public void notfoundPattern() throws Exception{
            String strWithPattern, result, expected;
            String logId = "logId";
            JsonObject sysConf,  kafkaJson;
            sysConf = new JsonObject();

            IpsMessageService sut = new IpsMessageService(sysConf, logId);


            String strDate, fmtWhole, fmtToTake;
            result = sut.replacePatternWithDateValue("20180102102030", "YYYYMMDDhhmmss", "abc");
            assertEquals("20180102102030", result);
        }


        @Test
        public void valueIsShortThanPattern1() throws Exception{
            String strWithPattern, result, expected;
            String logId = "logId";
            JsonObject sysConf,  kafkaJson;
            sysConf = new JsonObject();

            IpsMessageService sut = new IpsMessageService(sysConf, logId);


            result = sut.replacePatternWithDateValue("201", "YYYYMMDDhhmmss", "YYYY");
            assertEquals("201", result);
        }

        @Test
        public void valueIsShortThanPattern2() throws Exception{
            String strWithPattern, result, expected;
            String logId = "logId";
            JsonObject sysConf,  kafkaJson;
            sysConf = new JsonObject();

            IpsMessageService sut = new IpsMessageService(sysConf, logId);


            result = sut.replacePatternWithDateValue("2018010", "YYYYMMDDhhmmss", "DD");
            assertEquals("0", result);

            result = sut.replacePatternWithDateValue("2018010", "YYYYMMDDhhmmss", "ss");
            assertEquals("", result);
        }

    }

    public static class replaceDatePattern{

        @Test
        public void normal() throws Exception{
            String strWithPattern, result, expected;
            String logId = "logId";
            JsonObject sysConf,  kafkaJson;
            sysConf = new JsonObject();

            IpsMessageService sut = new IpsMessageService(sysConf, logId);


            String strDate, fmtWhole, fmtToTake;
            strWithPattern = new String("<<mydatekey:YYYYMMDDhhmmss:YYYY>>");
            kafkaJson = new JsonObject().put("mydatekey", "20180102102030");
            result = sut.replaceDatePattern(strWithPattern, kafkaJson);
            assertEquals("2018", result);
        }

        @Test
        public void keyIsNotFound() throws Exception{
            String strWithPattern, result, expected;
            String logId = "logId";
            JsonObject sysConf,  kafkaJson;
            sysConf = new JsonObject();

            IpsMessageService sut = new IpsMessageService(sysConf, logId);


            String strDate, fmtWhole, fmtToTake;
            strWithPattern = new String("<<notexist:YYYYMMDDhhmmss:YYYY>>");
            kafkaJson = new JsonObject().put("mydatekey", "20180102102030");
            result = sut.replaceDatePattern(strWithPattern, kafkaJson);
            assertEquals("", result);
        }

        @Test
        public void patternNotExist() throws Exception{
            String strWithPattern, result, expected;
            String logId = "logId";
            JsonObject sysConf,  kafkaJson;
            sysConf = new JsonObject();

            IpsMessageService sut = new IpsMessageService(sysConf, logId);


            String strDate, fmtWhole, fmtToTake;
            strWithPattern = new String("<<mydatekey:YYYYMMDDhhmmss:abc>>");
            kafkaJson = new JsonObject().put("mydatekey", "20180102102030");
            result = sut.replaceDatePattern(strWithPattern, kafkaJson);
            assertEquals("20180102102030", result);
        }
    }

    public static class replaceNormalPattern{
        @Test
        public void testNormalContainKey() throws Exception{
            String strWithPattern, strResult, expected;
            String logId = "logId";
            JsonObject sysConf,  kafkaJson;
            sysConf = new JsonObject();

            kafkaJson = new JsonObject().put("hello", "world");
            strWithPattern = new String("<hello>");
            IpsMessageService sut = new IpsMessageService(sysConf, logId);
            strResult = sut.replaceNormalPattern(strWithPattern, kafkaJson);
            assertEquals("world", strResult);

            kafkaJson = new JsonObject().put("hello", "world");
            strWithPattern = new String("<hello> abc");
            strResult = sut.replaceNormalPattern(strWithPattern, kafkaJson);
            assertEquals("world abc", strResult);
        }

        @Test
        public void keyNotContained() throws Exception{
            String strWithPattern, strResult, expected;
            String logId = "logId";
            JsonObject sysConf,  kafkaJson;
            sysConf = new JsonObject();
            IpsMessageService sut = new IpsMessageService(sysConf, logId);

            kafkaJson = new JsonObject().put("notexist", "world");
            strWithPattern = new String("<hello>");
            strResult = sut.replaceNormalPattern(strWithPattern, kafkaJson);
            assertEquals("", strResult);

        }
    }

    public static class isNServerMsgTooOld{
        @Test
        public void msg_is_old_expect_true() throws Exception{

            String logId = "logId";
            JsonObject sysConf;
            sysConf = new JsonObject();
            IpsMessageService sut = new IpsMessageService(sysConf, logId);

            Date dtNow = Util.timeGetDateFromString("20180723102000", "yyyyMMddHHmmss");
            String tfdate = "20180720102000";
            boolean bTooOld = sut.isNServerMsgTooOld(dtNow, tfdate);
            assertTrue(bTooOld);

        }

        @Test
        public void msg_not_old_expect_false() throws Exception{

            String logId = "logId";
            JsonObject sysConf;
            sysConf = new JsonObject();
            IpsMessageService sut = new IpsMessageService(sysConf, logId);

            Date dtNow = Util.timeGetDateFromString("20180723102000", "yyyyMMddHHmmss");
            String tfdate = "20180722102000";
            boolean bTooOld = sut.isNServerMsgTooOld(dtNow, tfdate);
            assertFalse(bTooOld);
        }

        @Test
        public void tfdate_could_not_parsed_expect_false() throws Exception{
            String logId = "logId";
            JsonObject sysConf;
            sysConf = new JsonObject();
            IpsMessageService sut = new IpsMessageService(sysConf, logId);

            Date dtNow = Util.timeGetDateFromString("20180723102000", "yyyyMMddHHmmss");
            String tfdate = "";
            boolean bTooOld = sut.isNServerMsgTooOld(dtNow, tfdate);
            assertFalse(bTooOld);
        }
    }

    public static class isPingAnNotification{
        @Test
        public void confNotSet_expect_false() throws Exception{
            String logId = "logId";
            JsonObject sysConf,  kafkaJson, dbConfJson, result;
            sysConf = new JsonObject();
            IpsMessageService sut = new IpsMessageService(sysConf, logId);

            boolean bResult = sut.isPingAnNotification(sysConf, "ksett");
            assertFalse(bResult);
        }
    }

    public static class getWxAppMsgJsonObject{

        @Test
        public void normal() throws Exception{
            String strWithPattern, strResult, expected, msg_template;
            String logId = "logId";
            JsonObject sysConf,  kafkaJson, dbConfJson, result;
            sysConf = new JsonObject();
            IpsMessageService sut = new IpsMessageService(sysConf, logId);


            msg_template = new String("{\"touser\":\"<openid>\",\"template_id\":\"<template_id>\",\"form_id\":\"<tftxcode>\",\"data\":{\"keyword1\":{\"value\":\"<<tfdate:YYYYMMDDhhmmss:MM>>��<<tfdate:YYYYMMDDhhmmss:DD>>��<<tfdate:YYYYMMDDhhmmss:hh>>:<<tfdate:YYYYMMDDhhmmss:mm>>\",\"color\":\"#173177\"},\"keyword2\":{\"value\":\"�װ�������ͨ�޸г�ֵ\",\"color\":\"#173177\"},\"keyword3\":{\"value\":\"����ͨ<teacct>\",\"color\":\"#173177\"},\"keyword4\":{\"value\":\"<tftxmony>Ԫ\",\"color\":\"#173177\"},\"keyword5\":{\"value\":\"<tftxcode>\",\"color\":\"#173177\"}}}");
            dbConfJson = new JsonObject()
                    .put("msg_template", msg_template)
                    .put("template_id", "za463_cwYLcI7qBUvsFYXRbWVvBCqYgOs6qbnvzX21s")
                    ;
            kafkaJson = new JsonObject()
                    .put("openid", "openid")
                    .put("tftxcode", "tftxcode")
                    .put("tfdate", "20180514001122")
                    .put("teacct", "teacct")
                    .put("tftxmony", "100.00")
                    ;
            result = sut.getWxAppMsgJsonObject(dbConfJson, kafkaJson);
            assertEquals("openid", Util.safeGetJsonString(result, "touser", ""));
            System.out.println(result.encodePrettily());


        }
    }

    public static class isMessageSmallApp{
        @Test
        public void notConfigured_expected_false() throws Exception {
            String logId = "logId";
            JsonObject sysConf,  kafkaJson;
            boolean bResult;
            sysConf = new JsonObject();
            kafkaJson = new JsonObject();

            IpsMessageService sut = new IpsMessageService(sysConf, logId);
            bResult = sut.isNoFeeling(sysConf, kafkaJson);
            assertFalse(bResult);


            kafkaJson = new JsonObject().put("tfmccode", "abc");
            bResult = sut.isNoFeeling(sysConf, kafkaJson);
            assertFalse(bResult);
        }


        @Test
        public void Configured_expected_true() throws Exception {
            String logId = "logId";
            JsonObject sysConf,  kafkaJson;
            boolean bResult;
            sysConf = new JsonObject();
            kafkaJson = new JsonObject();

            IpsMessageService sut = new IpsMessageService(sysConf, logId);


            sysConf = new JsonObject().put("smallAppMerc", "abc");
            bResult = sut.isNoFeeling(sysConf, kafkaJson);
            assertFalse(bResult);


            kafkaJson = new JsonObject().put("tfmccode", "abc");
            sysConf = new JsonObject().put("smallAppMerc", "abc");
            bResult = sut.isNoFeeling(sysConf, kafkaJson);
            assertTrue(bResult);
        }

    }

    public static class getSmallAppMerchants{
        @Test
        public void notConfigured_expected_false() throws Exception {
            String logId = "logId";
            JsonObject sysConf,  kafkaJson;
            boolean bResult;
            Set<String> result;

            sysConf = new JsonObject();
            kafkaJson = new JsonObject();

            IpsMessageService sut = new IpsMessageService(sysConf, logId);
            result = sut.getNoFeelingMerchants(sysConf);
            assertTrue(result.isEmpty());
        }
    }

    public static class dbGetWxTemplate{
        @Test
        public void inCache_returnCache() throws Exception{
            JsonObject sysConf = new JsonObject();
            String logId = "logId";
            IpsMessageService sut = new IpsMessageService(sysConf, logId);
            IpsMessageService spy_sut = spy(sut);
        }
    }

    @RunWith(VertxUnitRunner.class)
    public static class safeProcessKafka{
        @Test
        public void throw_exception_process(TestContext context) throws Exception{
            JsonObject sysConf = new JsonObject();
            String logId = "logId";
            IpsMessageService sut = new IpsMessageService(sysConf, logId);
            IpsMessageService spy_sut = spy(sut);

            ConsumerRecord<String, String> msg = mock(ConsumerRecord.class);
            JsonObject kafkaJson = new JsonObject();
            Vertx vertx = Vertx.vertx();
            IpsMessageHandler ipsMessageHandler = mock(IpsMessageHandler.class);
            doCallRealMethod().when(spy_sut).safeProcessKafka(msg, kafkaJson, vertx, ipsMessageHandler);


            doThrow(new RuntimeException("")).when(spy_sut).processKafkaLogic(any(JsonObject.class), eq(vertx), anyString(), eq(ipsMessageHandler));

            spy_sut.safeProcessKafka(msg, kafkaJson, vertx, ipsMessageHandler);

            verify(ipsMessageHandler).handle(eq(kafkaJson), any(JsonObject.class));

        }
    }

    public static class isKafkaMessageAllowedFuncTypeInTopic{

        @Test
        public void isKafkaMessageAllowedFuncTypeInTopic_topicnameConfigEmpty1() throws Exception {

            String strSysConfig = "{ \"funcTypeAllowed\":{ } }";
            JsonObject sysConf = new JsonObject(strSysConfig);
            JsonObject kafkaJson = new JsonObject()
                    .put("tftranstype", "120");

            String strKafkaTopicName = "topicNotExist";

            String logId = "logId";
            IpsMessageService sut = new IpsMessageService(sysConf, logId);
            boolean bResult = sut.isKafkaMessageAllowedFuncTypeInTopic(sysConf, strKafkaTopicName, kafkaJson);
            assertTrue(bResult);
        }


        @Test
        public void isKafkaMessageAllowedFuncTypeInTopic_topicnameConfigEmpty2() throws Exception {

            String strSysConfig = "{ \"mynode\":{ } }";
            JsonObject sysConf = new JsonObject(strSysConfig);
            JsonObject kafkaJson = new JsonObject()
                    .put("tftranstype", "120");

            String strKafkaTopicName = "topicNotExist";

            String logId = "logId";
            IpsMessageService sut = new IpsMessageService(sysConf, logId);
            boolean bResult = sut.isKafkaMessageAllowedFuncTypeInTopic(sysConf, strKafkaTopicName, kafkaJson);
            assertTrue(bResult);
        }

        @Test
        public void isKafkaMessageAllowedFuncTypeInTopic_topicnameNotContained_expect_false() throws Exception {
            String strSysConfig = "{ \"funcTypeAllowed\":{\"topicname1\":\"120,130\"} }";
            JsonObject sysConf = new JsonObject(strSysConfig);
            JsonObject kafkaJson = new JsonObject()
                    .put("tftranstype", "120");

            String strKafkaTopicName = "topicNotExist";

            String logId = "logId";
            IpsMessageService sut = new IpsMessageService(sysConf, logId);
            boolean bResult = sut.isKafkaMessageAllowedFuncTypeInTopic(sysConf, strKafkaTopicName, kafkaJson);
            assertFalse(bResult);
        }

        @Test
        public void isKafkaMessageAllowedFuncTypeInTopic_topicnameContained_funcTypeNotContained() throws Exception {
            String strSysConfig = "{ \"funcTypeAllowed\":{\"topicname1\":\"120,130\"} }";
            JsonObject sysConf = new JsonObject(strSysConfig);
            JsonObject kafkaJson = new JsonObject()
                    .put("tftranstype", "170");

            String strKafkaTopicName = "topicname1";

            String logId = "logId";
            IpsMessageService sut = new IpsMessageService(sysConf, logId);
            boolean bResult = sut.isKafkaMessageAllowedFuncTypeInTopic(sysConf, strKafkaTopicName, kafkaJson);
            assertFalse(bResult);
        }

        @Test
        public void isKafkaMessageAllowedFuncTypeInTopic_topicnameContained_funcTypeContained_expectTrue() throws Exception {

            String strSysConfig = "{ \"funcTypeAllowed\":{\"topicname1\":\"120,130\"} }";
            JsonObject sysConf = new JsonObject(strSysConfig);
            JsonObject kafkaJson = new JsonObject()
                    .put("tftranstype", "120");

            String strKafkaTopicName = "topicname1";

            String logId = "logId";
            IpsMessageService sut = new IpsMessageService(sysConf, logId);
            boolean bResult = sut.isKafkaMessageAllowedFuncTypeInTopic(sysConf, strKafkaTopicName, kafkaJson);
            assertTrue(bResult);
        }
    }



    public static class Function_isKafkaMessageAllowedMccodeInTopic{


        @Test
        public void childJsonEmpty1() throws Exception {

            String strSysConfig = "{ \"mycomment\":{\"topicname1\":\"111222,222333\"} }";
            JsonObject sysConf = new JsonObject(strSysConfig);
            JsonObject kafkaJson = new JsonObject()
                    .put("tfmccode", "000999");

            String strKafkaTopicName = "topicNotExist";

            String logId = "logId";
            IpsMessageService sut = new IpsMessageService(sysConf, logId);
            boolean bResult = sut.isKafkaMessageAllowedMccodeInTopic(sysConf, strKafkaTopicName, kafkaJson);
            assertTrue(bResult);
        }

        @Test
        public void childJsonEmpty2() throws Exception {

            String strSysConfig = "{ \"mccodeAllowed\":{ } }";
            JsonObject sysConf = new JsonObject(strSysConfig);
            JsonObject kafkaJson = new JsonObject()
                    .put("tfmccode", "000999");

            String strKafkaTopicName = "topicNotExist";

            String logId = "logId";
            IpsMessageService sut = new IpsMessageService(sysConf, logId);
            boolean bResult = sut.isKafkaMessageAllowedMccodeInTopic(sysConf, strKafkaTopicName, kafkaJson);
            assertTrue(bResult);
        }


        @Test
        public void topicNameNotContained() throws Exception {

            String strSysConfig = "{ \"mccodeAllowed\":{\"topicname1\":\"111222,222333\"} }";
            JsonObject sysConf = new JsonObject(strSysConfig);
            JsonObject kafkaJson = new JsonObject()
                    .put("tfmccode", "000999");

            String strKafkaTopicName = "topicNotExist";

            String logId = "logId";
            IpsMessageService sut = new IpsMessageService(sysConf, logId);
            boolean bResult = sut.isKafkaMessageAllowedMccodeInTopic(sysConf, strKafkaTopicName, kafkaJson);
            assertFalse(bResult);
        }

        @Test
        public void topicNameContained_mccodeNotContained() throws Exception {

            String strSysConfig = "{ \"mccodeAllowed\":{\"topicname1\":\"111222,222333\"} }";
            JsonObject sysConf = new JsonObject(strSysConfig);
            JsonObject kafkaJson = new JsonObject()
                    .put("tfmccode", "000999");

            String strKafkaTopicName = "topicname1";

            String logId = "logId";
            IpsMessageService sut = new IpsMessageService(sysConf, logId);
            boolean bResult = sut.isKafkaMessageAllowedMccodeInTopic(sysConf, strKafkaTopicName, kafkaJson);
            assertFalse(bResult);
        }

        @Test
        public void topicNameContained_mccodeContained_expectedTrue() throws Exception {

            String strSysConfig = "{ \"mccodeAllowed\":{\"topicname1\":\"111222,222333,000999\"} }";
            JsonObject sysConf = new JsonObject(strSysConfig);
            JsonObject kafkaJson = new JsonObject()
                    .put("tfmccode", "000999");

            String strKafkaTopicName = "topicname1";

            String logId = "logId";
            IpsMessageService sut = new IpsMessageService(sysConf, logId);
            boolean bResult = sut.isKafkaMessageAllowedMccodeInTopic(sysConf, strKafkaTopicName, kafkaJson);
            assertTrue(bResult);
        }

        @Test
        public void topicNameContained_mccodeContained_expectedTrue2() throws Exception {

            String strSysConfig = "{ \"mccodeAllowed\":{\"topicname1\":\"111222,222333,000999\"} }";
            JsonObject sysConf = new JsonObject(strSysConfig);
            JsonObject kafkaJson = new JsonObject()
                    .put("tfmccode", "111222");

            String strKafkaTopicName = "topicname1";

            String logId = "logId";
            IpsMessageService sut = new IpsMessageService(sysConf, logId);
            boolean bResult = sut.isKafkaMessageAllowedMccodeInTopic(sysConf, strKafkaTopicName, kafkaJson);
            assertTrue(bResult);
        }

    }


    public static class test_AtomicReference{
        @Test
        public void notSet() throws Exception {
            AtomicReference<JsonObject> reference = new AtomicReference<>();

            JsonObject joMyGet = reference.get();
            assertNull(joMyGet);
        }

        @Test
        public void setAndGetValue() throws Exception {
            AtomicReference<JsonObject> reference = new AtomicReference<>();

            JsonObject joMyGet = reference.get();
            assertNull(joMyGet);

            reference.set(new JsonObject().put("retcode", "0000"));
            joMyGet = reference.get();
            assertNotNull(joMyGet);
            assertEquals("0000", joMyGet.getString("retcode"));


            reference.set(new JsonObject().put("retcode", "0001"));
            joMyGet = reference.get();
            assertNotNull(joMyGet);
            assertEquals("0001", joMyGet.getString("retcode"));
        }
    }




    public static class test_jsonArray{

        @Test
        public void emptyArrayGetObject() throws Exception {
            JsonArray arrEmpty = new JsonArray();

            assertEquals(0, arrEmpty.size());
            assertTrue(arrEmpty.isEmpty());

            try{
                arrEmpty.getJsonObject(0);
                fail("should throw exception");
            }catch (Exception ex){
            }
        }


        @Test
        public void notEmptyArray() throws Exception {
            JsonArray arrEmpty = new JsonArray();
            arrEmpty.add("apple");

            assertTrue(arrEmpty.size()> 0 );
            assertFalse(arrEmpty.isEmpty());

            String joGet = arrEmpty.getString(0);
            assertNotNull(joGet);
        }


        @Test
        public void indexOutBoundary() throws Exception {
            JsonArray arrEmpty = new JsonArray();
            arrEmpty.add("apple");

            assertTrue(arrEmpty.size()> 0 );
            assertFalse(arrEmpty.isEmpty());

            try{
                String joGet = arrEmpty.getString(1);
                fail("index out of boundary");
            }catch (Exception ex){
            }
        }
    }
}